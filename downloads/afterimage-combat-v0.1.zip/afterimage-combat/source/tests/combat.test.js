import test from 'node:test';
import assert from 'node:assert/strict';
import { createBattle, living, rankOf, availableTargets, hitChance, act, nextTurn, enemyAction, random, SKILLS } from '../src/combat.js';

function turn(s, id, next = 'h4') {
  s.active = id;
  s.queue = [next];
  s.seed = 1;
}

test('starts with four combatants per side and one action slot each', () => {
  const s = createBattle(42);
  assert.equal(living(s, 'hero').length, 4);
  assert.equal(living(s, 'enemy').length, 4);
  assert.equal(s.round, 1);
  assert.equal(new Set([s.active, ...s.queue]).size, 8);
  assert.equal(s.queue.length, 7);
  assert.equal(rankOf(s, 'h1'), 1);
  assert.equal(rankOf(s, 'h4'), 4);
});

test('same seed produces the same turn order and random stream', () => {
  const a = createBattle(7), b = createBattle(7);
  assert.deepEqual(a, b);
  assert.deepEqual(Array.from({ length: 10 }, () => random(a)), Array.from({ length: 10 }, () => random(b)));
});

test('illegal launch rank, target rank, team, and unowned skills cannot mutate a battle', () => {
  const s = createBattle();
  turn(s, 'h3');
  assert.deepEqual(availableTargets(s, 'shot'), ['e2', 'e3', 'e4']);
  const before = structuredClone(s);
  for (const [skill, target] of [['shot', 'e1'], ['shot', 'h2'], ['cleave', 'e1'], ['mend', 'h1'], ['bogus', 'e1']]) {
    assert.equal(act(s, skill, target).ok, false);
    assert.deepEqual(s, before);
  }
  s.order.hero = ['h3', 'h1', 'h2', 'h4'];
  assert.deepEqual(availableTargets(s, 'shot'), []);
});

test('adjacent swap costs one action and affects launch eligibility', () => {
  const s = createBattle();
  turn(s, 'h4', 'h2');
  assert.deepEqual(availableTargets(s, 'move'), ['h3']);
  assert.equal(act(s, 'move', 'h1').ok, false);
  assert.equal(act(s, 'move', 'h3').ok, true);
  assert.equal(s.actions, 1);
  assert.equal(rankOf(s, 'h4'), 3);
  assert.equal(rankOf(s, 'h3'), 4);
  assert.equal(s.active, 'h2');
});

test('push changes enemy formation and front-only attack availability', () => {
  const s = createBattle();
  turn(s, 'h1');
  assert.equal(act(s, 'push', 'e2').ok, true);
  assert.equal(rankOf(s, 'e2'), 3);
  assert.equal(rankOf(s, 'e3'), 2);
});

test('guard redirects damage and applies protection until the guard source next acts', () => {
  const s = createBattle();
  turn(s, 'h1', 'e1');
  act(s, 'cover', 'h2');
  assert.equal(s.units.h2.guardedBy, 'h1');
  const before = s.units.h1.hp;
  turn(s, 'e1');
  act(s, 'hit', 'h2');
  assert.equal(s.units.h2.hp, s.units.h2.maxHp);
  assert.ok(s.units.h1.hp < before);
  assert.ok(before - s.units.h1.hp <= 5);
  s.queue = ['h1'];
  nextTurn(s);
  assert.equal(s.units.h2.guardedBy, null);
  assert.equal(s.units.h1.protection, 0);
});

test('bleed ticks exactly on its owner turn and expires after three applications', () => {
  const s = createBattle();
  turn(s, 'h2');
  act(s, 'cut', 'e1');
  const before = s.units.e1.hp;
  assert.deepEqual(s.units.e1.bleed, [{ amount: 2, turns: 3 }]);
  for (let i = 1; i <= 3; i++) {
    s.queue = ['e1']; nextTurn(s);
    assert.equal(s.units.e1.hp, before - 2 * i);
  }
  assert.deepEqual(s.units.e1.bleed, []);
  s.queue = ['e1']; nextTurn(s);
  assert.equal(s.units.e1.hp, before - 6);
});

test('a combatant killed by bleed never gets an action', () => {
  const s = createBattle();
  s.units.e1.hp = 1;
  s.units.e1.bleed = [{ amount: 2, turns: 3 }];
  s.queue = ['e1', 'h2'];
  nextTurn(s);
  assert.equal(s.units.e1.dead, true);
  assert.equal(s.active, 'h2');
  assert.equal(rankOf(s, 'e2'), 1);
});

test('healing clears all bleed stacks, revives from the door, and cannot exceed max HP', () => {
  const s = createBattle();
  turn(s, 'h4', 'e1');
  s.units.h1.hp = 0; s.units.h1.deathsDoor = true;
  s.units.h1.bleed = [{ amount: 2, turns: 3 }, { amount: 2, turns: 1 }];
  act(s, 'mend', 'h1');
  assert.ok(s.units.h1.hp >= 7);
  assert.equal(s.units.h1.deathsDoor, false);
  assert.deepEqual(s.units.h1.bleed, []);
  turn(s, 'h4', 'e1');
  s.units.h1.hp = s.units.h1.maxHp - 1;
  act(s, 'mend', 'h1');
  assert.equal(s.units.h1.hp, s.units.h1.maxHp);
});

test('zero HP hero survives the first hit and enters Death’s Door', () => {
  const s = createBattle();
  s.units.h1.hp = 1;
  turn(s, 'e1');
  act(s, 'hit', 'h1');
  assert.equal(s.units.h1.hp, 0);
  assert.equal(s.units.h1.deathsDoor, true);
  assert.equal(s.units.h1.dead, false);
});

test('damage at Death’s Door can be survived or cause death, including bleed', () => {
  for (const [seed, dies] of [[1, false], [12345678, true]]) {
    const s = createBattle();
    s.units.h1.hp = 0; s.units.h1.deathsDoor = true;
    s.units.h1.bleed = [{ amount: 2, turns: 1 }];
    s.seed = seed; s.queue = ['h1', 'h2'];
    nextTurn(s);
    assert.equal(s.units.h1.dead, dies, `seed ${seed}`);
    assert.equal(s.active, dies ? 'h2' : 'h1');
  }
});

test('stress 100 applies hit penalty and treatment removes it', () => {
  const s = createBattle();
  s.units.h3.stress = 85;
  turn(s, 'e4', 'h3');
  act(s, 'dread', 'h3');
  assert.equal(s.units.h3.stress, 107);
  assert.equal(hitChance(s, 'shot', 'e3', 'h3'), 81);
  turn(s, 'h4', 'e1');
  act(s, 'solace', 'h3');
  assert.equal(s.units.h3.stress, 83);
  assert.equal(hitChance(s, 'shot', 'e3', 'h3'), 91);
});

test('prototype stress 200 resets to 100 and deals 8 unguarded damage', () => {
  const s = createBattle();
  s.units.h2.stress = 190;
  turn(s, 'e4');
  act(s, 'dread', 'h2');
  assert.equal(s.units.h2.stress, 100);
  assert.equal(s.units.h2.hp, s.units.h2.maxHp - 8);
});

test('mark boosts two successful attacks and is consumed only by hits', () => {
  const s = createBattle();
  turn(s, 'h3'); act(s, 'mark', 'e4');
  assert.equal(s.units.e4.marked, 2);
  turn(s, 'h3');
  s.seed = 1800; // First random draw exceeds the 93% hit chance.
  act(s, 'shot', 'e4');
  assert.equal(s.lastAction.kind, 'miss');
  assert.equal(s.units.e4.marked, 2);
  for (let i = 1; i >= 0; i--) {
    turn(s, 'h3');
    s.units.e4.hp = s.units.e4.maxHp = 100;
    const before = s.units.e4.hp;
    act(s, 'shot', 'e4');
    assert.ok(before - s.units.e4.hp >= 10);
    assert.equal(s.units.e4.marked, i);
  }
});

test('killing the last enemy ends the battle and rejects further actions', () => {
  const s = createBattle();
  ['e1', 'e2', 'e3'].forEach(id => { s.units[id].dead = true; });
  s.units.e4.hp = 1;
  turn(s, 'h1');
  act(s, 'cleave', 'e4');
  assert.equal(s.result, 'victory');
  assert.equal(s.active, null);
  const before = structuredClone(s);
  assert.equal(act(s, 'wait', 'h1').ok, false);
  assert.deepEqual(s, before);
});

test('losing the last hero to bleed ends the battle with defeat', () => {
  const s = createBattle();
  ['h2', 'h3', 'h4'].forEach(id => { s.units[id].dead = true; });
  s.units.h1.hp = 0; s.units.h1.deathsDoor = true;
  s.units.h1.bleed = [{ amount: 2, turns: 1 }];
  s.seed = 12345678; s.queue = ['h1'];
  nextTurn(s);
  assert.equal(s.result, 'defeat');
  assert.equal(s.active, null);
});

function tacticalAction(s) {
  const actor = s.units[s.active];
  const hurt = living(s, 'hero').sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0];
  if (actor.skills.includes('mend') && hurt.hp < hurt.maxHp * .65 && availableTargets(s, 'mend').includes(hurt.id)) return ['mend', hurt.id];
  const pressured = living(s, 'hero').sort((a, b) => b.stress - a.stress)[0];
  if (actor.skills.includes('solace') && pressured.stress >= 75 && availableTargets(s, 'solace').includes(pressured.id)) return ['solace', pressured.id];
  const options = actor.skills.filter(id => SKILLS[id].damage).flatMap(id => availableTargets(s, id).map(target => ({ id, target, score: (SKILLS[id].damage[0] + SKILLS[id].damage[1]) / 2 + (SKILLS[id].bleed || 0) * 2 + (s.units[target].hp < 10 ? 12 : 0) + (target === 'e4' ? 5 : 0) })));
  options.sort((a, b) => b.score - a.score);
  return options.length ? [options[0].id, options[0].target] : ['wait', actor.id];
}

test('100 seeded full battles terminate, respect health bounds, and allow a winning strategy', () => {
  let victories = 0;
  for (let seed = 1; seed <= 100; seed++) {
    const s = createBattle(seed);
    while (!s.result && s.actions < 800) {
      assert.ok(!s.units[s.active].dead, 'dead combatant cannot act');
      if (s.units[s.active].side === 'enemy') assert.equal(enemyAction(s).ok, true);
      else assert.equal(act(s, ...tacticalAction(s)).ok, true);
      for (const u of Object.values(s.units)) {
        assert.ok(u.hp >= 0 && u.hp <= u.maxHp);
        assert.ok(u.stress >= 0 && u.stress < 200);
      }
    }
    assert.ok(s.result, `seed ${seed} must terminate`);
    if (s.result === 'victory') victories++;
  }
  assert.ok(victories >= 80, `expected a viable strategy; ${victories}/100 victories`);
});

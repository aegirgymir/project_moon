import './style.css';
import { createBattle, SKILLS, HEROES, living, rankOf, availableTargets, hitChance, act, enemyAction } from './combat.js';
import { icon, figure, alley } from './art.js';

const app = document.querySelector('#app');
let battle = createBattle();
let selectedSkill = null, selectedTarget = null, inspected = null;
let enemyTimer = null, animationTimer = null, sound = false, fast = false, audioContext;
let generation = 0, notice = '', modal = null, animatedAction = 0;
const esc = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const active = () => battle.units[battle.active];
const playerTurn = () => active()?.side === 'hero' && !battle.result;
const dots = (ranks, cls = '') => `<span class="rank-dots ${cls}" aria-label="위치 ${ranks.join(', ')}">${[1, 2, 3, 4].map(i => `<i class="${ranks.includes(i) ? 'on' : ''}"></i>`).join('')}</span>`;

function playTone(kind) {
  if (!sound) return;
  try {
    audioContext ||= new AudioContext();
    if (audioContext.state === 'suspended') audioContext.resume();
    const osc = audioContext.createOscillator(), gain = audioContext.createGain();
    osc.type = kind === 'heal' ? 'sine' : 'triangle';
    osc.frequency.setValueAtTime(kind === 'heal' ? 420 : kind === 'stress' ? 110 : 160, audioContext.currentTime);
    osc.frequency.exponentialRampToValueAtTime(kind === 'heal' ? 650 : 45, audioContext.currentTime + .18);
    gain.gain.setValueAtTime(.055, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + .24);
    osc.connect(gain); gain.connect(audioContext.destination); osc.start(); osc.stop(audioContext.currentTime + .25);
  } catch { /* Sound is optional; the battle never depends on audio permissions. */ }
}

function selectDefaults() {
  notice = '';
  if (!playerTurn()) { selectedSkill = null; selectedTarget = null; return; }
  inspected = battle.active;
  const actor = active();
  selectedSkill = actor.skills.find(id => SKILLS[id].damage && availableTargets(battle, id).length) || actor.skills.find(id => availableTargets(battle, id).length) || 'brace';
  selectedTarget = availableTargets(battle, selectedSkill)[0] || null;
}

function statusTags(u) {
  return [
    u.bleed.length ? `<span class="tag bleed" title="${u.bleed.map(b => `${b.amount} 피해 · ${b.turns}회`).join(' / ')}">${icon('drop', 11)} ${u.bleed.reduce((n, b) => n + b.amount, 0)}</span>` : '',
    u.marked ? `<span class="tag mark" title="다음 ${u.marked}회 공격 피해 +40%">${icon('crosshair', 11)} 표식 ${u.marked}</span>` : '',
    u.guardedBy && !battle.units[u.guardedBy].dead ? `<span class="tag protection" title="보호자: ${battle.units[u.guardedBy].name}">${icon('shield', 11)} 보호</span>` : '',
    u.deathsDoor ? '<span class="tag bleed">빈사</span>' : '',
    u.stress >= 100 ? '<span class="tag pressure">동요</span>' : '',
  ].join('');
}

function unitCard(u) {
  const targetable = selectedSkill && availableTargets(battle, selectedSkill).includes(u.id) && playerTurn();
  const chosen = selectedTarget === u.id && targetable;
  const isActive = battle.active === u.id;
  const last = battle.lastAction;
  const showFloat = last?.target === u.id && animatedAction === last.serial;
  return `<button class="unit ${u.side} ${isActive ? 'active-unit' : ''} ${targetable ? 'targetable' : ''} ${chosen ? 'chosen-target' : ''} ${showFloat ? `impact-${last.kind}` : ''}" data-unit="${u.id}" aria-label="${u.name}, ${rankOf(battle, u.id)}열, 체력 ${u.hp}/${u.maxHp}${targetable ? ', 대상 선택 가능' : ''}" aria-pressed="${chosen}">
    <span class="unit-target-label">${chosen ? '선택한 대상' : targetable ? '대상 선택' : isActive ? '행동 중' : ''}</span>
    <span class="figure-wrap">${figure(u.look, u.id)}${showFloat ? `<span class="floating ${last.kind}">${esc(last.value)}</span>` : ''}</span>
    <span class="unit-data"><span class="unit-name">${esc(u.name)}</span><span class="hp-line"><b>${u.hp}</b><span>/ ${u.maxHp}</span></span><span class="health-bar ${u.hp / u.maxHp < .3 ? 'low' : ''}"><i style="width:${u.hp / u.maxHp * 100}%"></i></span>${u.side === 'hero' ? `<span class="stress-bar" title="스트레스 ${u.stress}/200"><i style="width:${Math.min(100, u.stress / 2)}%"></i></span>` : '<span class="enemy-rule"></span>'}<span class="unit-status">${statusTags(u)}</span><span class="rank-number">${String(rankOf(battle, u.id)).padStart(2, '0')}</span></span>
  </button>`;
}

function turnOrder() {
  const ids = [battle.active, ...battle.queue].filter(id => id && !battle.units[id].dead);
  return `<div class="turn-order"><span class="turn-caption">${icon('clock', 14)} 행동 순서</span><div class="turn-chips">${ids.map((id, i) => { const u = battle.units[id]; return `<span class="turn-chip ${u.side} ${i === 0 ? 'current' : ''}" title="${u.name} · 기본 속도 ${u.speed}"><b>${i === 0 ? 'NOW' : String(i + 1).padStart(2, '0')}</b><span>${u.name}</span></span>${i < ids.length - 1 ? '<span class="queue-sep">›</span>' : ''}`; }).join('') || '<span class="queue-finished">전투 종료</span>'}</div><span class="roll-note">매 라운드 속도 + 1~8</span></div>`;
}

function actorPanel() {
  const actor = playerTurn() ? active() : battle.units[inspected] || living(battle, 'hero')[0];
  if (!actor) return '<div class="actor-panel empty-panel">돌아오지 못한 이들을 기억하며.</div>';
  return `<section class="actor-panel"><div class="section-label">${playerTurn() ? '현재 행동 해결사' : battle.result ? '작전 기록' : '해결사 정보'} <span>${String(rankOf(battle, actor.id)).padStart(2, '0')}열</span></div><div class="actor-info"><div class="portrait">${figure(actor.look, `portrait-${actor.id}`)}</div><div><span class="role-label">${esc(actor.role)}</span><h2>${actor.name}<span>해결사</span></h2><p class="actor-title">${actor.title || ''}</p></div></div><div class="actor-stats"><span>체력 <b>${actor.hp}<small> / ${actor.maxHp}</small></b></span><span>속도 <b>${actor.speed - (actor.stress >= 100 ? 2 : 0)}</b></span><span>회피 <b>${actor.dodge}<small>%</small></b></span></div><div class="pressure-meter"><span>스트레스 <b>${actor.stress} <small>/ 200</small></b></span><div><i style="width:${actor.stress / 2 * 100}%"></i><em></em></div><p>${actor.stress >= 100 ? '동요 · 명중 −10 / 속도 −2' : '100: 동요 · 200: 붕괴 후 체력 8 감소'}</p></div><p class="quote">“${actor.quote || '골목은 아무것도 약속하지 않는다.'}”</p></section>`;
}

function commandPanel() {
  if (battle.result) {
    const survivors = living(battle, 'hero').length;
    return `<section class="command-panel result-panel ${battle.result}"><span class="section-label">OPERATION ${battle.result === 'victory' ? 'COMPLETE' : 'FAILED'}</span>${icon(battle.result === 'victory' ? 'flag' : 'skull', 36)}<h2>${battle.result === 'victory' ? '골목에 다시 정적이 흐른다.' : '이번 의뢰는 여기까지.'}</h2><p>${battle.round} 라운드 · 해결사 ${survivors}명 생존 · ${battle.actions}회 행동</p><button class="primary-button" data-action="restart">${icon('reset', 16)} 다시 도전</button></section>`;
  }
  if (!playerTurn()) return `<section class="command-panel thinking"><span class="section-label">ENEMY TURN</span><div class="enemy-thinking">${icon('eye', 36)}<h2>${active()?.name || '조직원'}의 행동</h2><p>태세를 유지하고 다음 차례를 기다리세요.</p><span class="thinking-dots"><i></i><i></i><i></i></span></div></section>`;
  const actor = active(), skill = SKILLS[selectedSkill];
  return `<section class="command-panel"><div class="section-label">행동 선택 <span>기술 선택 → 대상 선택 → 실행</span></div><div class="skill-list">${actor.skills.map((id, i) => { const sk = SKILLS[id], usable = availableTargets(battle, id).length > 0; return `<button class="skill ${selectedSkill === id ? 'selected' : ''}" data-skill="${id}" ${usable ? '' : 'disabled'} title="${esc(sk.desc)}${usable ? '' : ' · 현재 위치에서 사용 불가'}"><span class="skill-number">${i + 1}</span><span class="skill-symbol">${icon(sk.icon, 27)}</span><b>${sk.name}</b><span class="skill-ranks">${dots(sk.from)}<span>›</span>${dots(sk.to, sk.side ? 'friendly' : 'hostile')}</span>${!usable ? '<span class="rank-lock">위치 제한</span>' : ''}</button>`; }).join('')}</div><div class="skill-detail"><span class="detail-title">${icon(skill?.icon || 'shield', 16)} <b>${skill?.name || '기술을 선택하세요'}</b>${skill?.damage ? `<span class="damage-range">피해 ${skill.damage.join('–')}</span>` : ''}</span><p>${skill?.desc || ''}</p></div><div class="utility-actions">${['move', 'brace', 'wait'].map(id => `<button data-skill="${id}" class="utility ${selectedSkill === id ? 'selected' : ''}" ${availableTargets(battle, id).length ? '' : 'disabled'} title="${SKILLS[id].desc}">${icon(SKILLS[id].icon, 15)} ${SKILLS[id].name}<kbd>${{ move: 'M', brace: 'G', wait: 'W' }[id]}</kbd></button>`).join('')}</div></section>`;
}

function targetPanel() {
  const u = battle.units[selectedTarget];
  if (!u || !playerTurn()) return `<section class="target-panel"><div class="section-label">${battle.result ? '작전 종료' : '전술 메모'}</div><span class="target-empty-icon">${icon('city', 36)}</span><p class="tactical-note">후열의 위협을 먼저 끊어내세요.<br>살아남는 것도 실력입니다.</p><span class="small-note">해결사와 장소는 창작 설정입니다.</span></section>`;
  const skill = SKILLS[selectedSkill], isHostile = u.side === 'enemy';
  return `<section class="target-panel"><div class="section-label">선택한 대상 <span class="${isHostile ? 'red-text' : 'green-text'}">${isHostile ? '적대' : '아군'}</span></div><h3>${u.name}</h3><p class="target-role">${u.role} · ${rankOf(battle, u.id)}열</p><div class="target-stats"><span>체력 <b>${u.hp} / ${u.maxHp}</b></span>${skill.damage ? `<span>명중 확률 <b class="gold-text">${hitChance(battle, selectedSkill, u.id)}%</b></span><span>치명타 <b>10%</b></span>` : `<span>${skill.heal ? '회복량' : skill.relief ? '스트레스 감소' : '효과'} <b>${skill.heal ? skill.heal.join('–') : skill.relief ? `−${skill.relief}` : skill.effect === 'guard' ? '피해 −40%' : skill.effect === 'mark' ? '피해 +40% × 2회' : '위치 교환'}</b></span>`}</div><div class="target-status">${statusTags(u) || '<span>부여된 상태 없음</span>'}</div><button class="primary-button execute" data-action="execute" ${availableTargets(battle, selectedSkill).includes(u.id) ? '' : 'disabled'}>${icon('arrow', 17)} ${skill.name}<kbd>↵</kbd></button></section>`;
}

function journal() {
  return `<aside class="journal"><div class="journal-top"><div class="section-label">현장 기록 <span class="live-dot"></span></div><span class="journal-code">FIELD LOG / 001</span></div><div class="journal-entries" role="log" aria-live="polite" aria-label="전투 기록">${battle.logs.slice(-35).map(entry => `<div class="log-entry ${entry.type}">${entry.type === 'round' ? `<span class="log-round">ROUND ${String(entry.round).padStart(2, '0')}</span>` : `<span class="log-marker">${String(entry.round).padStart(2, '0')}</span>`}<p>${esc(entry.text)}</p></div>`).join('')}</div><div class="journal-bottom"><span class="stamp">잔향 사무소</span><p>“계약은 끝까지.<br>목숨은 그 다음.”</p><span>AFTERIMAGE OFFICE</span></div></aside>`;
}

function modalContent() {
  if (!modal) return '';
  const title = modal === 'guide' ? '돌아오기 위한 지침' : modal === 'restart' ? '의뢰를 다시 시작할까요?' : '도시의 기록';
  const body = modal === 'restart' ? '<p>진행 중인 전투를 끝내고 새로 시작합니다. 같은 초기 조건으로 전술을 다시 시험할 수 있습니다.</p><button class="primary-button" data-action="confirm-restart">전투 다시 시작</button>' : modal === 'guide' ? `<p class="modal-intro">기술을 선택하고 빛나는 대상을 누른 뒤, 실행하세요.</p><div class="guide-grid"><article><b>01 / 위치가 전술이다</b><p>1열은 적과 가장 가까운 자리입니다. 기술 아래 밝은 점은 사용 가능한 아군 위치, 붉은 점은 공격할 적 위치입니다. 이동은 인접 아군과 교환하며 행동을 소모합니다.</p></article><article><b>02 / 행동은 한 번씩</b><p>매 라운드 속도 + 1~8로 순서를 결정합니다. 기술, 이동, 방어, 대기 중 하나를 사용하세요. 적은 자동으로 행동합니다.</p></article><article><b>03 / 몸과 마음을 돌본다</b><p>출혈은 자기 차례 시작에 피해를 줍니다. 윤서의 응급 처치로 해제하세요. 스트레스 100에서 명중 −10·속도 −2, 200에서 체력 8 감소 후 100으로 돌아갑니다.</p></article><article><b>04 / 끝까지 살아남는다</b><p>체력 0의 해결사는 죽음의 문턱에 섭니다. 이후 피해마다 33% 사망 위험이 있으며 치료로 벗어납니다. 적을 모두 쓰러뜨리면 승리합니다.</p></article></div><div class="guide-shortcuts"><kbd>1</kbd><kbd>2</kbd><kbd>3</kbd> 기술 <kbd>←</kbd><kbd>→</kbd> 대상 <kbd>↵</kbd> 실행 <kbd>M</kbd> 이동 <kbd>G</kbd> 방어 <kbd>W</kbd> 대기</div><p class="modal-note">다키스트 던전 1편의 위치 기반 전투에서 착안했습니다. 현재 수치와 정신적 붕괴 규칙은 이 프로토타입의 독자 규칙입니다.</p>` : `<p class="modal-intro">배경의 용어와 새로 만든 게임 설정을 구분합니다.</p><dl class="lore-list"><dt>도시 · 구획</dt><dd>작품들의 주요 무대인 거대 도시. 구획 안에는 둥지와 뒷골목이 구분되어 있습니다.</dd><dt>날개 · 특이점</dt><dd>날개는 구획을 지배하는 거대 기업이며, 특이점이라는 독자 기술을 기반으로 합니다.</dd><dt>둥지 · 뒷골목</dt><dd>둥지는 날개의 관리와 보호를 받는 중심부. 뒷골목에도 거주지, 상점, 학교와 일터가 있습니다.</dd><dt>해결사 · 조직</dt><dd>해결사는 의뢰를 처리하는 직업입니다. 조직은 도시의 여러 집단을 가리키는 폭넓은 용어입니다.</dd></dl><p class="source-note">위 항목은 공개 보관본의 《림버스 컴퍼니》 단테의 노트 KR·EN을 대조했습니다. 동일 원전의 언어 대조이며, 독립적인 공식 출처 검증은 아닙니다.</p><div class="original-note"><b>이번 전투의 창작 설정</b><p>잔향 사무소, 강현·서린·이도·윤서, 제7 배수로, 적 조직원, 의뢰 내용과 모든 전투 수치는 창작입니다. 정사 속 특정 구역이나 시대를 확정하지 않았습니다. 스트레스는 뒤틀림 또는 E.G.O 발현을 뜻하지 않습니다.</p></div><p class="modal-note">자세한 근거·한계·추가 확인 항목은 저장소의 docs/RESEARCH.md, 전투 규칙은 docs/COMBAT.md에 기록했습니다.</p>`;
  return `<dialog open class="modal-dialog" aria-labelledby="modal-title"><div class="modal-kicker">AFTERIMAGE OFFICE / ARCHIVE</div><button class="modal-close icon-button" data-action="close-modal" aria-label="닫기">${icon('close')}</button><h2 id="modal-title">${title}</h2>${body}<button class="modal-done" data-action="close-modal">${modal === 'guide' ? '전투로 돌아가기' : '닫기'} ${icon('arrow', 14)}</button></dialog>`;
}

function render() {
  const oldFocus = document.activeElement?.dataset;
  app.innerHTML = `<header class="topbar"><a class="brand" href="#" aria-label="골목의 잔향">${icon('city', 30)}<span>잔향<span>AFTERIMAGE OFFICE</span></span></a><div class="topbar-center"><span class="topbar-rule"></span>도시는 잠들지 않는다<span class="topbar-rule"></span></div><nav aria-label="게임 메뉴"><button data-action="lore">${icon('book', 15)} 도시의 기록</button><button data-action="guide">${icon('eye', 15)} 전투 지침</button><button class="icon-button" data-action="sound" aria-label="${sound ? '효과음 끄기' : '효과음 켜기'}" title="효과음 ${sound ? '켜짐' : '꺼짐'}" aria-pressed="${sound}">${icon(sound ? 'volume' : 'mute', 18)}</button><span class="version-label">PROTOTYPE 0.1</span></nav></header>
  <main><section class="mission-header"><div><div class="eyebrow"><span class="gold-dash"></span> BACKSTREETS / COMBAT STUDY</div><h1>골목의 잔향<span>전투 기록 001</span></h1><p>비가 그치기 전에, 이 골목을 벗어나야 한다.</p></div><div class="mission-details"><div><span>의뢰 구분</span><b>배수로 통행 확보</b></div><div><span>작전 지역</span><b>뒷골목 · 제7 배수로</b></div><div class="difficulty"><span>위험 수준</span><b><i></i><i></i><i class="off"></i> 보통</b></div></div></section>
  <div class="battle-grid"><div class="battle-main"><section class="arena" aria-label="전투 현장"><div class="arena-heading"><span>${icon('flag', 15)} 제7 배수로 <em>RAIN-SOAKED PASSAGE</em></span><div><span class="battle-status ${battle.result ? '' : 'in-progress'}">${battle.result === 'victory' ? '위협 제거' : battle.result === 'defeat' ? '작전 실패' : '교전 중'}</span><span class="round-number">ROUND <b>${String(battle.round).padStart(2, '0')}</b></span></div></div>${turnOrder()}<div class="battlefield">${alley()}<div class="scene-vignette"></div><div class="scene-caption"><span>비인가 통행 구역</span><span>잔류 인원 · ${living(battle, 'hero').length} / 4</span></div><div class="rosters"><div class="roster heroes">${living(battle, 'hero').reverse().map(unitCard).join('')}${!living(battle, 'hero').length ? '<span class="empty-roster">응답 없음</span>' : ''}</div><div class="versus"><span></span><b>VS</b><span></span></div><div class="roster enemies">${living(battle, 'enemy').map(unitCard).join('')}${!living(battle, 'enemy').length ? '<span class="empty-roster">구역 확보</span>' : ''}</div></div><div class="formation-caption"><span>후열 <i>←</i> <b>아군</b> <i>→</i> 전열</span><span>전열 <i>←</i> <b>적군</b> <i>→</i> 후열</span></div></div><div class="battle-hint"><span>${icon(playerTurn() ? 'crosshair' : 'clock', 13)} ${notice || (battle.result ? '현장 기록을 확인하고 다시 도전할 수 있습니다.' : playerTurn() ? `${active().name}의 차례입니다. 기술과 대상을 선택하세요.` : `${active()?.name || '적'}의 움직임을 관찰하는 중…`)}</span><button data-action="fast" aria-pressed="${fast}" title="적 행동 대기 시간을 줄입니다">${fast ? '빠르게 2×' : '보통 속도 1×'}</button></div></section><div class="command-deck">${actorPanel()}${commandPanel()}${targetPanel()}</div><div class="below-battle"><span>${icon('shield', 13)} 조작: 기술 선택 → 빛나는 대상 → 실행 <span class="keyboard-help">/ <kbd>1</kbd>–<kbd>3</kbd> 기술 <kbd>↵</kbd> 실행</span></span><button data-action="restart">${icon('reset', 13)} 전투 초기화</button></div></div>${journal()}</div><footer><span>PROJECT MOON 세계관 기반 비공식 팬 프로토타입 <i>·</i> 인물·장소·시각 자료는 창작</span><span>전투부터, 한 걸음씩. <b>v0.1</b></span></footer></main>${modal ? `<div class="modal-backdrop">${modalContent()}</div>` : ''}`;
  const entries = document.querySelector('.journal-entries');
  if (entries) entries.scrollTop = entries.scrollHeight;
  if (oldFocus?.skill) document.querySelector(`[data-skill="${oldFocus.skill}"]`)?.focus({ preventScroll: true });
  if (modal) { const dialog = document.querySelector('dialog'); if (!dialog.dataset.focused) dialog.querySelector('button')?.focus({ preventScroll: true }); }
}

function schedule() {
  clearTimeout(enemyTimer);
  if (!battle.result && active()?.side === 'enemy' && !modal) {
    const currentGeneration = generation;
    enemyTimer = setTimeout(() => {
      if (generation !== currentGeneration || modal) return;
      enemyAction(battle);
      afterAction();
    }, fast ? 350 : 1050);
  }
}

function afterAction() {
  clearTimeout(animationTimer);
  animatedAction = battle.lastAction?.serial || 0;
  playTone(battle.lastAction?.kind);
  selectDefaults(); render(); schedule();
  const currentGeneration = generation;
  animationTimer = setTimeout(() => {
    if (generation !== currentGeneration) return;
    animatedAction = 0;
    document.querySelectorAll('.floating').forEach(el => el.remove());
  }, 950);
}

function restart() {
  clearTimeout(enemyTimer); clearTimeout(animationTimer); generation++;
  battle = createBattle(); modal = null; animatedAction = 0;
  selectDefaults(); render(); schedule();
}

function execute() {
  if (!playerTurn() || modal) return;
  const result = act(battle, selectedSkill, selectedTarget);
  if (!result.ok) { notice = result.reason; render(); return; }
  afterAction();
}

function chooseSkill(id) {
  if (!playerTurn() || !availableTargets(battle, id).length) return;
  selectedSkill = id;
  const targets = availableTargets(battle, id);
  if (!targets.includes(selectedTarget)) selectedTarget = targets[0];
  notice = ''; render();
}

app.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (!button || button.disabled) return;
  if (button.dataset.skill) chooseSkill(button.dataset.skill);
  if (button.dataset.unit) {
    const id = button.dataset.unit;
    if (playerTurn() && availableTargets(battle, selectedSkill).includes(id)) selectedTarget = id;
    else if (battle.units[id].side === 'hero' && !playerTurn()) inspected = id;
    render();
  }
  switch (button.dataset.action) {
    case 'execute': execute(); break;
    case 'restart': if (battle.result || !battle.actions) restart(); else { modal = 'restart'; clearTimeout(enemyTimer); render(); } break;
    case 'confirm-restart': restart(); break;
    case 'guide': case 'lore': modal = button.dataset.action; clearTimeout(enemyTimer); render(); break;
    case 'close-modal': modal = null; render(); schedule(); break;
    case 'sound': sound = !sound; playTone('heal'); render(); break;
    case 'fast': fast = !fast; render(); schedule(); break;
  }
});
app.addEventListener('click', event => {
  if (event.target.classList.contains('modal-backdrop')) { modal = null; render(); schedule(); }
});
document.addEventListener('keydown', event => {
  if (modal) {
    if (event.key === 'Escape') { modal = null; render(); schedule(); }
    if (event.key === 'Tab') {
      const buttons = [...document.querySelectorAll('dialog button')];
      if (event.shiftKey && document.activeElement === buttons[0]) { event.preventDefault(); buttons.at(-1).focus(); }
      else if (!event.shiftKey && document.activeElement === buttons.at(-1)) { event.preventDefault(); buttons[0].focus(); }
    }
    return;
  }
  if (!playerTurn()) return;
  if (/^[123]$/.test(event.key)) { event.preventDefault(); chooseSkill(active().skills[Number(event.key) - 1]); }
  const utility = { m: 'move', g: 'brace', w: 'wait' }[event.key.toLowerCase()];
  if (utility) { event.preventDefault(); chooseSkill(utility); }
  // Respect a focused button's native activation; elsewhere Enter executes the selected action.
  if (event.key === 'Enter' && (document.activeElement?.tagName !== 'BUTTON' || document.activeElement?.dataset.skill || document.activeElement?.dataset.unit)) { event.preventDefault(); execute(); }
  if (['ArrowLeft', 'ArrowRight'].includes(event.key)) {
    event.preventDefault();
    const targets = availableTargets(battle, selectedSkill);
    const current = targets.indexOf(selectedTarget), direction = event.key === 'ArrowRight' ? 1 : -1;
    selectedTarget = targets[(current + direction + targets.length) % targets.length]; render();
  }
});

selectDefaults(); render(); schedule();

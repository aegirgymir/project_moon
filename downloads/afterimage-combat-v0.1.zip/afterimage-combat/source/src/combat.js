// Standalone battle rules. No DOM, timer, or network dependencies.
export const SKILLS = {
  cleave: { name: '묵직한 일격', icon: 'sword', from: [1, 2], to: [1, 2], damage: [7, 11], accuracy: 95, desc: '전열의 적에게 강한 참격을 가한다.' },
  cover: { name: '엄호 태세', icon: 'shield', from: [1, 2, 3], to: [1, 2, 3, 4], side: 'ally', effect: 'guard', desc: '다음 자기 차례까지 아군의 피해를 대신 받는다. 받는 피해 −40%.' },
  push: { name: '돌파', icon: 'burst', from: [1, 2], to: [1, 2], damage: [4, 7], accuracy: 95, push: 1, desc: '적을 공격하고 한 칸 뒤로 밀어낸다.' },
  cut: { name: '깊게 베기', icon: 'sword', from: [1, 2, 3], to: [1, 2], damage: [5, 8], accuracy: 95, bleed: 2, desc: '출혈 2 부여 · 대상의 차례 시작마다 피해, 3회.' },
  pierce: { name: '틈새 찌르기', icon: 'crosshair', from: [2, 3], to: [2, 3, 4], damage: [6, 10], accuracy: 95, desc: '적의 후열까지 닿는 정밀한 찌르기.' },
  steady: { name: '호흡 가다듬기', icon: 'spark', from: [1, 2, 3, 4], to: [1, 2, 3, 4], side: 'self', relief: 20, desc: '자신의 스트레스 20 감소.' },
  shot: { name: '조준 사격', icon: 'crosshair', from: [2, 3, 4], to: [2, 3, 4], damage: [7, 11], accuracy: 95, desc: '후열을 견제한다. 표식 대상에게 피해 +40%.' },
  mark: { name: '약점 포착', icon: 'eye', from: [2, 3, 4], to: [1, 2, 3, 4], effect: 'mark', desc: '표식 부여 · 다음 2회의 공격 피해 +40%.' },
  knife: { name: '예비 단검', icon: 'sword', from: [1, 2, 3, 4], to: [1, 2], damage: [3, 6], accuracy: 95, desc: '어느 위치에서도 사용할 수 있는 근접 공격.' },
  mend: { name: '응급 처치', icon: 'medical', from: [3, 4], to: [1, 2, 3, 4], side: 'ally', heal: [7, 11], cure: true, desc: '체력을 회복하고 출혈을 제거한다. 빈사 상태에서 벗어날 수 있다.' },
  solace: { name: '현실 감각', icon: 'spark', from: [2, 3, 4], to: [1, 2, 3, 4], side: 'ally', relief: 24, desc: '아군 스트레스 24 감소. 100 미만이면 동요가 해소된다.' },
  hit: { name: '둔기 강타', from: [1, 2], to: [1, 2], damage: [5, 8], accuracy: 90 },
  hook: { name: '녹슨 갈고리', from: [1, 2, 3], to: [1, 2, 3], damage: [3, 6], accuracy: 90, bleed: 2 },
  harass: { name: '견제 사격', from: [2, 3, 4], to: [2, 3, 4], damage: [4, 7], accuracy: 90 },
  dread: { name: '불길한 속삭임', from: [1, 2, 3, 4], to: [1, 2, 3, 4], stress: 22 },
  brace: { name: '방어', icon: 'shield', from: [1, 2, 3, 4], to: [1, 2, 3, 4], side: 'self', effect: 'guard', desc: '다음 자기 차례까지 받는 피해 −40%.' },
  move: { name: '위치 이동', icon: 'move', from: [1, 2, 3, 4], to: [1, 2, 3, 4], side: 'ally', effect: 'move', desc: '인접 아군과 자리를 교환한다. 행동을 소모한다.' },
  wait: { name: '대기', icon: 'clock', from: [1, 2, 3, 4], to: [1, 2, 3, 4], side: 'self', relief: 4, desc: '행동을 마치고 스트레스 4 감소.' },
};

export const HEROES = [
  { id: 'h1', name: '강현', role: '방어 담당', title: '버티는 자', hp: 38, speed: 3, dodge: 3, skills: ['cleave', 'cover', 'push'], look: 'guard', quote: '내 뒤에 서. 아직 버틸 만하니까.' },
  { id: 'h2', name: '서린', role: '근접 담당', title: '골목의 칼날', hp: 30, speed: 6, dodge: 7, skills: ['cut', 'pierce', 'steady'], look: 'blade', quote: '들어갈 틈은 반드시 있어.' },
  { id: 'h3', name: '이도', role: '사격 담당', title: '조용한 조준', hp: 27, speed: 8, dodge: 5, skills: ['shot', 'mark', 'knife'], look: 'gunner', quote: '한 발이면 충분해야 할 텐데.' },
  { id: 'h4', name: '윤서', role: '지원 담당', title: '돌아갈 이유', hp: 29, speed: 5, dodge: 4, skills: ['mend', 'solace', 'knife'], look: 'medic', quote: '살아서 돌아가야 보수도 받지.' },
];
export const ENEMIES = [
  { id: 'e1', name: '골목 앞잡이', role: '전열 · 타격', hp: 31, speed: 2, dodge: 0, skills: ['hit', 'dread'], look: 'brute' },
  { id: 'e2', name: '갈고리잡이', role: '전열 · 출혈', hp: 26, speed: 4, dodge: 3, skills: ['hook', 'dread'], look: 'hook' },
  { id: 'e3', name: '망보는 자', role: '후열 · 사격', hp: 24, speed: 6, dodge: 4, skills: ['harass', 'dread'], look: 'watcher' },
  { id: 'e4', name: '속삭이는 자', role: '후열 · 압박', hp: 25, speed: 3, dodge: 2, skills: ['dread'], look: 'whisper' },
];

export function random(state) {
  state.seed = (Math.imul(1664525, state.seed) + 1013904223) >>> 0;
  return state.seed / 4294967296;
}
const roll = (s, min, max) => min + Math.floor(random(s) * (max - min + 1));
export const living = (s, side) => s.order[side].map(id => s.units[id]).filter(u => !u.dead);
export const rankOf = (s, id) => living(s, s.units[id].side).findIndex(u => u.id === id) + 1;
const log = (s, text, type = 'normal') => { s.logs.push({ id: ++s.serial, round: s.round, text, type }); };

export function createBattle(seed = 20261017) {
  const s = { seed: seed >>> 0, round: 0, units: {}, order: { hero: [], enemy: [] }, queue: [], active: null, result: null, logs: [], serial: 0, lastAction: null, actions: 0 };
  for (const [side, roster] of [['hero', HEROES], ['enemy', ENEMIES]]) {
    roster.forEach(u => {
      s.units[u.id] = { ...u, side, maxHp: u.hp, stress: 0, bleed: [], marked: 0, guardedBy: null, protection: 0, dead: false, deathsDoor: false };
      s.order[side].push(u.id);
    });
  }
  log(s, '배수로 입구에서 길을 막는 조직원들과 조우했다.', 'system');
  nextTurn(s);
  return s;
}

function finish(s) {
  if (!living(s, 'enemy').length) s.result = 'victory';
  else if (!living(s, 'hero').length) s.result = 'defeat';
  if (s.result) {
    s.active = null;
    s.queue = [];
    log(s, s.result === 'victory' ? '위협 제거. 전원 상태를 확인하고 철수한다.' : '작전 실패. 사무소와의 연락이 끊겼다.', s.result);
  }
  return Boolean(s.result);
}

function changeStress(s, u, delta) {
  if (u.side !== 'hero' || u.dead) return;
  const before = u.stress;
  u.stress = Math.max(0, Math.min(200, u.stress + delta));
  if (before < 100 && u.stress >= 100) log(s, `${u.name} 동요! 명중 −10, 속도 −2.`, 'stress');
  if (before >= 100 && u.stress < 100) log(s, `${u.name}, 다시 집중하기 시작한다.`, 'heal');
  if (u.stress >= 200) {
    // Prototype-only breakdown. This is deliberately not Distortion or E.G.O.
    u.stress = 100;
    log(s, `${u.name}, 정신적 붕괴로 체력 8 감소.`, 'stress');
    damage(s, u, 8, true);
  }
}

function kill(s, u) {
  u.dead = true;
  u.hp = 0;
  u.guardedBy = null;
  log(s, `${u.name} ${u.side === 'hero' ? '사망' : '격퇴'}.`, 'damage');
  if (u.side === 'hero') living(s, 'hero').forEach(ally => changeStress(s, ally, 12));
}

function damage(s, target, amount, bypassGuard = false) {
  let u = target;
  if (!bypassGuard && u.guardedBy && !s.units[u.guardedBy].dead) {
    const protector = s.units[u.guardedBy];
    if (protector.id !== u.id) log(s, `${protector.name}, ${u.name} 대신 공격을 받았다.`, 'system');
    u = protector;
  }
  const dealt = Math.max(1, Math.round(amount * (bypassGuard ? 1 : 1 - u.protection)));
  if (u.side === 'hero' && u.hp === 0) {
    if (random(s) < 0.67) log(s, `${u.name}, 죽음의 문턱에서 버텼다.`, 'stress');
    else kill(s, u);
  } else {
    u.hp = Math.max(0, u.hp - dealt);
    if (u.hp === 0) {
      if (u.side === 'enemy') kill(s, u);
      else {
        u.deathsDoor = true;
        log(s, `${u.name}, 죽음의 문턱! 추가 피해에 사망 위험.`, 'stress');
        changeStress(s, u, 10);
      }
    }
  }
  return { target: u, dealt };
}

export function nextTurn(s) {
  if (finish(s)) return;
  while (!s.result) {
    if (!s.queue.length) {
      s.round++;
      const initiatives = [...living(s, 'hero'), ...living(s, 'enemy')].map(u => ({ id: u.id, initiative: u.speed - (u.stress >= 100 ? 2 : 0) + roll(s, 1, 8), tie: random(s) }));
      initiatives.sort((a, b) => b.initiative - a.initiative || a.tie - b.tie);
      s.queue = initiatives.map(i => i.id);
      log(s, `라운드 ${s.round} · 행동 순서를 다시 결정한다.`, 'round');
    }
    const u = s.units[s.queue.shift()];
    if (u.dead) continue;
    // Guard lasts until the protector's next turn begins.
    Object.values(s.units).forEach(x => { if (x.guardedBy === u.id) x.guardedBy = null; });
    u.protection = 0;
    if (u.bleed.length) {
      const total = u.bleed.reduce((sum, b) => sum + b.amount, 0);
      log(s, `${u.name}, 출혈 피해 ${total}.`, 'damage');
      damage(s, u, total, true);
      u.bleed.forEach(b => b.turns--);
      u.bleed = u.bleed.filter(b => b.turns > 0);
      if (finish(s)) return;
      if (u.dead) continue;
    }
    s.active = u.id;
    return;
  }
}

export function availableTargets(s, skillId, actorId = s.active) {
  if (!actorId || s.result) return [];
  const actor = s.units[actorId], skill = SKILLS[skillId];
  if (!actor || actor.dead || !skill || !skill.from.includes(rankOf(s, actor.id))) return [];
  if (!actor.skills.includes(skillId) && !['brace', 'move', 'wait'].includes(skillId)) return [];
  if (skill.side === 'self') return [actor.id];
  const team = skill.side === 'ally' ? actor.side : actor.side === 'hero' ? 'enemy' : 'hero';
  return living(s, team).filter(u => {
    if (!skill.to.includes(rankOf(s, u.id))) return false;
    if (skill.effect === 'move') return u.id !== actor.id && Math.abs(rankOf(s, u.id) - rankOf(s, actor.id)) === 1;
    return true;
  }).map(u => u.id);
}

export function hitChance(s, skillId, targetId, actorId = s.active) {
  const skill = SKILLS[skillId], actor = s.units[actorId], target = s.units[targetId];
  if (!skill?.damage) return 100;
  return Math.min(100, Math.max(5, skill.accuracy - target.dodge - (actor.stress >= 100 ? 10 : 0)));
}

export function act(s, skillId, targetId) {
  if (!availableTargets(s, skillId).includes(targetId)) return { ok: false, reason: '현재 위치에서 선택할 수 없는 대상입니다.' };
  const actor = s.units[s.active], target = s.units[targetId], skill = SKILLS[skillId];
  s.actions++;
  let value = '', kind = 'support', actual = target.id;
  log(s, `${actor.name} → ${target.name} · ${skill.name}`, 'action');
  if (skill.damage) {
    if (random(s) * 100 >= hitChance(s, skillId, targetId)) {
      value = '빗나감'; kind = 'miss'; log(s, `${target.name}, 공격을 피했다.`, 'miss');
    } else {
      const critical = random(s) < 0.1;
      let amount = roll(s, ...skill.damage);
      if (critical) amount = Math.round(skill.damage[1] * 1.5);
      if (target.marked > 0) { amount = Math.round(amount * 1.4); target.marked--; }
      const hit = damage(s, target, amount);
      actual = hit.target.id;
      value = `${critical ? '치명타 ' : '−'}${hit.dealt}`;
      kind = critical ? 'critical' : 'damage';
      log(s, `${hit.target.name}, ${critical ? '치명타! ' : ''}피해 ${hit.dealt}.`, kind);
      if (actor.side === 'hero' && critical) changeStress(s, actor, -5);
      if (hit.target.side === 'hero') changeStress(s, hit.target, critical ? 7 : 3);
      if (!hit.target.dead && skill.bleed) {
        hit.target.bleed.push({ amount: skill.bleed, turns: 3 });
        log(s, `${hit.target.name}에게 출혈 ${skill.bleed} 부여 (3회).`, 'damage');
      }
      if (!target.dead && skill.push && hit.target.id === target.id) {
        const order = s.order[target.side], current = order.indexOf(target.id);
        const next = living(s, target.side)[rankOf(s, target.id)];
        if (next) { const other = order.indexOf(next.id); [order[current], order[other]] = [order[other], order[current]]; log(s, `${target.name}, 한 칸 밀려났다.`, 'system'); }
      }
    }
  }
  if (skill.heal) {
    const before = target.hp;
    target.hp = Math.min(target.maxHp, target.hp + roll(s, ...skill.heal));
    target.deathsDoor = target.hp === 0;
    if (skill.cure) target.bleed = [];
    value = `+${target.hp - before}`; kind = 'heal';
    log(s, `${target.name}, 체력 ${target.hp - before} 회복 · 출혈 제거.`, 'heal');
  }
  if (skill.relief) {
    const before = target.stress;
    changeStress(s, target, -skill.relief);
    value = `압박 −${before - target.stress}`; kind = 'heal';
    log(s, `${target.name}, 스트레스 ${before - target.stress} 감소.`, 'heal');
  }
  if (skill.stress) {
    changeStress(s, target, skill.stress);
    value = `압박 +${skill.stress}`; kind = 'stress';
    log(s, `${target.name}, 스트레스 ${skill.stress} 증가.`, 'stress');
  }
  if (skill.effect === 'guard') {
    target.guardedBy = actor.id;
    actor.protection = 0.4;
    actor.guardedBy = actor.id;
    value = '보호'; log(s, `${actor.name}, 다음 자기 차례까지 ${target.name} 보호.`, 'system');
  }
  if (skill.effect === 'mark') { target.marked = 2; value = '표식'; log(s, `${target.name}의 약점 포착.`, 'system'); }
  if (skill.effect === 'move') {
    const order = s.order[actor.side], a = order.indexOf(actor.id), b = order.indexOf(target.id);
    [order[a], order[b]] = [order[b], order[a]];
    value = '위치 교환'; log(s, `${actor.name}, ${target.name}와 위치 교환.`, 'system');
  }
  s.lastAction = { actor: actor.id, target: actual, skill: skillId, value, kind, serial: s.actions };
  if (!finish(s)) nextTurn(s);
  return { ok: true };
}

export function enemyAction(s) {
  const actor = s.units[s.active];
  if (!actor || actor.side !== 'enemy' || s.result) return null;
  const usable = actor.skills.filter(id => availableTargets(s, id).length);
  // Front fighters attack when they can. They use pressure when forced out of position.
  const attack = usable.find(id => SKILLS[id].damage);
  const skill = attack && random(s) < 0.85 ? attack : usable[usable.length - 1];
  if (!skill) return act(s, 'wait', actor.id);
  const targets = availableTargets(s, skill);
  const target = targets[roll(s, 0, targets.length - 1)];
  return act(s, skill, target);
}

export function icon(name, size = 24) {
  const paths = {
    sword: '<path d="m5 19 4-4m-2-3 5 5m-2-4L20 3l1 5-9 9M3 21l3-3"/>',
    shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="M12 7v9m-4-5h8"/>',
    burst: '<path d="m12 2 2 7 7-4-4 7 5 3-8 1-2 6-3-7-7 1 5-5-3-6 7 4Z"/>',
    crosshair: '<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 1v5m0 12v5M1 12h5m12 0h5"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    medical: '<path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6Z"/>',
    spark: '<path d="m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3Z"/><path d="m20 2 1 2 2 1-2 1-1 2-1-2-2-1 2-1Z"/>',
    move: '<path d="M3 12h18M7 8l-4 4 4 4m10-8 4 4-4 4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
    book: '<path d="M12 5C8 2 3 4 3 4v15s5-2 9 1c4-3 9-1 9-1V4s-5-2-9 1Zm0 0v15"/>',
    reset: '<path d="M3 10a9 9 0 1 1 1 8M3 4v6h6"/>',
    volume: '<path d="m11 4-6 5H2v6h3l6 5Zm4 4a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
    mute: '<path d="m11 4-6 5H2v6h3l6 5Zm5 5 6 6m0-6-6 6"/>',
    arrow: '<path d="M3 12h18m-6-6 6 6-6 6"/>',
    skull: '<path d="M5 15a9 9 0 1 1 14 0v5H5Zm4 5v-4m6 4v-4"/><circle cx="8" cy="10" r="1.5"/><circle cx="16" cy="10" r="1.5"/>',
    drop: '<path d="M12 2s-7 8-7 13a7 7 0 0 0 14 0c0-5-7-13-7-13Z"/>',
    chevron: '<path d="m9 5 7 7-7 7"/>',
    close: '<path d="m5 5 14 14M5 19 19 5"/>',
    city: '<path d="M3 21V7h6v14m0-10h6v10m0-18h6v18M1 21h22M5 10h1m-1 4h1m11-8h2m-2 4h2"/>',
    flag: '<path d="M5 22V3m0 1c5-4 9 4 15 0v10c-6 4-10-4-15 0"/>',
  };
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.sword}</svg>`;
}

export function figure(look, id = look) {
  const enemy = ['brute', 'hook', 'watcher', 'whisper'].includes(look);
  const palette = {
    guard: ['#465154', '#aeb3a5', '#a18a5e'], blade: ['#3c4448', '#aaa9a0', '#9d5a4c'],
    gunner: ['#52605a', '#a0a89b', '#b9a477'], medic: ['#78817b', '#c7c7b5', '#ad765c'],
    brute: ['#554440', '#9a8170', '#a95643'], hook: ['#564c45', '#a79b85', '#986047'],
    watcher: ['#454a44', '#96988b', '#a94d3b'], whisper: ['#493d3e', '#a19788', '#9b4d46'],
  }[look];
  const [coat, light, accent] = palette;
  const head = look === 'guard' || look === 'brute'
    ? '<path d="m54 40 4-17 18-4 14 13-2 25-9 9-20-9Z" fill="#a09582"/><path d="m55 40 7-14 15 2 11 10-2-17-13-6-19 9Z" fill="#1a2021"/><path d="m58 44 12 1m6-1 8-2" stroke="#272b28" stroke-width="3"/>'
    : '<path d="m58 36 7-16 18 2 10 14-4 21-13 9-15-10Z" fill="#a79e8b"/><path d="m55 40 7-23 19-5 15 17-3 19-8-17-10 8-3-10-9 19Z" fill="#1c2221"/><path d="m70 44 7-2m5 2 6-1" stroke="#262b29" stroke-width="2"/>';
  const weapon = {
    guard: '<path d="m31 103-18 65 27 19 22-76Z" fill="#3a4646" stroke="#9a9b89" stroke-width="2"/><path d="m32 122-8 39 13 10 12-43Z" fill="#65716b"/><path d="m98 115 15 34 7-3-10-42Z" fill="#555c57"/><path d="m116 144 18 44" stroke="#aaa797" stroke-width="6"/>',
    blade: '<path d="m102 106 25 36 9-5-18-42Z" fill="#343b3b"/><path d="m117 136 20 17" stroke="#9d674c" stroke-width="5"/><path d="m129 145 16 37 3 30-9-22-18-39Z" fill="#cac8ae"/><path d="M42 132 8 178" stroke="#bcb9a0" stroke-width="3"/>',
    gunner: '<path d="m89 84 29 13 8 16-10 6-38-16Z" fill="#4d5a55"/><path d="m111 102 41-4 4 9-19 3-4 15-8 1-2-16-14 1Z" fill="#151e1e" stroke="#7c8980" stroke-width="1.5"/><path d="m149 99 7-1" stroke="#c9b880" stroke-width="2"/>',
    medic: '<path d="m36 108-7 41 14 4 14-40Z" fill="#808a7f"/><path d="m21 147 34 2 5 36-42-2Z" fill="#3c4944" stroke="#939c89"/><path d="M31 146v-7h15v8" stroke="#9b9d89" fill="none" stroke-width="3"/><path d="M31 159h13v5h-4v8h-5v-8h-4Z" fill="#c2b89b"/>',
    brute: '<path d="m108 103 26 17-5 21-20-19Z" fill="#5c4e43"/><path d="m125 126 18 61" stroke="#322c28" stroke-width="8"/><path d="m132 165 16-5 10 32-16 5Z" fill="#8a8170"/><path d="m130 169 22-4m-18 16 22-4" stroke="#383b35" stroke-width="3"/>',
    hook: '<path d="m105 100 24 26-7 15-27-26Z" fill="#665747"/><path d="m125 130 14 40q18 24 5 32-13 5-15-10" fill="none" stroke="#a59b85" stroke-width="5"/><path d="M33 123 17 168" stroke="#43433a" stroke-width="9"/>',
    watcher: '<path d="m96 84 23 16-10 15-29-13Z" fill="#545b4c"/><path d="m108 103 43 2 2 8-28 1-5 15-9-2 3-15-10-1Z" fill="#202823" stroke="#9c9279"/><path d="m54 26 29-9 11 10 6 10-51 3Z" fill="#2a322d"/>',
    whisper: '<path d="m53 23 22-16 22 20 9 45-20-15-28 6-13 13Z" fill="#3a3032"/><path d="m64 31 21-3 5 25-16 10-13-14Z" fill="#ada392"/><path d="m65 45 22 1m-19 5 15 2" stroke="#665a4e" stroke-width="2"/><path d="m25 115 15 39 19-7-15-38Z" fill="#574a45"/><path d="m30 125 21 1 1 30-20 1Z" fill="#a3977c"/><path d="m34 132 13 1m-12 5 11 1m-10 5 8 1" stroke="#504b40"/>',
  }[look];
  return `<svg class="figure figure-${look}" viewBox="0 0 165 250" preserveAspectRatio="xMidYMax meet" aria-hidden="true"><defs><linearGradient id="coat-${id}" x2="1" y2="1"><stop stop-color="${coat}"/><stop offset="1" stop-color="#1c2423"/></linearGradient><filter id="shadow-${id}"><feDropShadow dx="0" dy="5" stdDeviation="3" flood-opacity=".6"/></filter></defs><g filter="url(#shadow-${id})"><ellipse cx="78" cy="234" rx="50" ry="7" fill="#080e0e" opacity=".65"/><path d="m55 152-7 71 20 4 13-60 6 59 22-2-10-74Z" fill="#1b2423"/><path d="m47 222-9 11 28 2 3-13m17 0 1 11 31 1-10-14" fill="#101918" stroke="#667069"/><path d="m58 64-20 17-10 40 20 7-7 51 29-8 9-39 11 44 29 7-13-62 18-8-15-39-22-12Z" fill="url(#coat-${id})" stroke="#15201f" stroke-width="2"/><path d="m60 65 13 22 14-23-5 52Z" fill="${light}"/><path d="m58 65-9 16 17 12-9 15 16 24-1-45m16-23 12 18-15 12 11 12-12 28" fill="#26312f" stroke="${light}" stroke-opacity=".35"/><path d="m74 84 5-1 2 32-6 9-3-9Z" fill="${accent}"/><path d="m48 137 57 1" stroke="#17201e" stroke-width="6"/><path d="m76 135 10 1v5H76Z" fill="#948b6b"/><path d="m48 155 13-2m33 3 14 5M57 183l-3 28m43-26 5 28" stroke="${light}" stroke-opacity=".25" stroke-width="2"/>${head}${weapon}<path d="m60 60 13 8 14-8-1 9-13 9-14-10Z" fill="${enemy ? accent : '#8d8c76'}"/>${look === 'medic' ? '<path d="M46 91h12v5h-4v8h-4v-8h-4Z" fill="#d4c5a2"/>' : ''}<path d="m39 86-5 20m77-17 6 13" stroke="${light}" opacity=".4" stroke-width="2"/></g></svg>`;
}

export function alley() {
  const windows = Array.from({ length: 80 }, (_, i) => {
    const x = 25 + (i * 73) % 1200, y = 15 + (i * 37) % 205;
    return `<rect x="${x}" y="${y}" width="${i % 3 ? 5 : 11}" height="${i % 2 ? 13 : 7}" fill="${i % 5 ? '#668577' : '#c2a06b'}" opacity="${i % 3 ? '.25' : '.5'}"/>`;
  }).join('');
  const rain = Array.from({ length: 100 }, (_, i) => `<path d="m${(i * 113) % 1300} ${(i * 41) % 430} -5 22"/>`).join('');
  return `<svg class="alley-art" viewBox="0 0 1300 450" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="sky" x2="0" y2="1"><stop stop-color="#1c3433"/><stop offset="1" stop-color="#4e5d4c"/></linearGradient><linearGradient id="mist" x2="0" y2="1"><stop stop-color="#91a08b" stop-opacity="0"/><stop offset=".8" stop-color="#7b8d79" stop-opacity=".2"/><stop offset="1" stop-color="#131e1c"/></linearGradient><radialGradient id="lamp"><stop stop-color="#d6bd82" stop-opacity=".25"/><stop offset="1" stop-color="#d6bd82" stop-opacity="0"/></radialGradient></defs><rect width="1300" height="450" fill="url(#sky)"/><path d="M0 0h145v267h45V50h80v213h43V0h80v224h52V79h75v181h43V30h68v200h29V0h86v257h32V95h52v160h40V0h84v248h52V59h78v227h37V0h159v450H0Z" fill="#192c2c"/>${windows}<path d="M0 0h200v240l-26 22v92H0Zm1300 0h-232v260l50 35v59h182Z" fill="#111f20"/><path d="M20 0v297h138V39H20m1110-39v302h168" stroke="#45524a" stroke-width="3" fill="none"/><path d="M201 49h124m-129 30h127m677-3h112M233 0v270m-2-152h85m705 29h47M51 0v272m78-248v226" stroke="#354640" stroke-width="5" fill="none"/><path d="M0 18q520 100 1300 17M0 44q530 110 1300 33M280 0q240 230 700 0" stroke="#112021" stroke-width="3" fill="none"/><rect x="28" y="95" width="125" height="51" fill="#1b2d2c" stroke="#596457"/><text x="40" y="118" fill="#a39b76" font-size="14" letter-spacing="8">수선 공방</text><text x="43" y="135" fill="#758477" font-size="8" letter-spacing="5">REPAIR SHOP</text><rect x="1083" y="83" width="43" height="150" fill="#483b30" stroke="#75634b"/><text x="1104" y="113" fill="#b29c71" font-size="18" text-anchor="middle">전<tspan x="1104" dy="27">당</tspan><tspan x="1104" dy="27">포</tspan></text><path d="M364 0v83m-15 0h30" stroke="#1d2b27" stroke-width="5"/><circle cx="364" cy="97" r="100" fill="url(#lamp)"/><path d="m348 83-10 16h50l-12-16Z" fill="#a39166"/><path d="m345 100 37 1" stroke="#d9c28b" stroke-width="3"/><rect x="563" y="202" width="177" height="119" fill="#152523"/><path d="M558 198h188m-176 10h163m-163 8h163m-163 8h163m-163 8h163m-163 8h163m-163 8h163m-163 8h163m-163 8h163m-163 8h163m-163 8h163" stroke="#344a40" stroke-width="3"/><text x="650" y="190" text-anchor="middle" fill="#8b947a" font-size="12" letter-spacing="6">제 7 배 수 로</text><path d="M0 336h1300v114H0Z" fill="#1e2c26"/><path d="M563 324 365 450m370-126 239 126M0 360h1300M0 401h1300" stroke="#6c7b62" opacity=".18"/><path d="m20 382 165-9 120 10m658-14 250 11m-745 45 175-6 110 7m-200-37 200-3" stroke="#a3aa88" opacity=".15" stroke-width="3"/><rect width="1300" height="450" fill="url(#mist)"/><g stroke="#bac6ad" stroke-width=".7" opacity=".12">${rain}</g><path d="M0 328h134v-64H43v-40H0m1300 100h-120v-64h120" fill="#192722"/><rect x="72" y="255" width="70" height="78" fill="#2c382d" stroke="#4d5740"/><path d="m75 261 62 65m-61 0 61-65" stroke="#566044" opacity=".4"/></svg>`;
}

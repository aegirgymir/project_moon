# Project context

- This repository is a Korean browser combat prototype, “골목의 잔향”. It uses the City setting from Project Moon and takes rank-based tactical inspiration from Darkest Dungeon **1**, not 2.
- Before adding lore, read `docs/RESEARCH.md`. It records what was actually read, source confidence, Korean/English wording differences, and blocked sources. Do not turn a community mirror into an official source, count two translations of the same original as independent confirmation, or claim unvisited websites were verified.
- Persist new research findings and corrections in `docs/RESEARCH.md`; conversation memory alone is insufficient.
- `docs/COMBAT.md` documents the prototype’s own rules. Its stress thresholds do not cause canonical Distortion or E.G.O. Characters, office, passage, enemies, and numbers are original prototype content.
- Keep combat rules in `src/combat.js` independent of the DOM, timers, and browser APIs. Game randomness must use the seeded random function. UI code and enemy scheduling live in `src/main.js`.
- Run `npm test` and `npm run build` for combat changes. `python scripts/browser_smoke.py` runs an optional real Chromium interaction test against the running server; it requires Python Playwright and Chromium.
- Node 24 is available. Use `npm ci --cache /workspace/.npm-cache` in this cloud machine to avoid writing package caches outside writable roots.
- The cloud task is already isolated. Work in the existing `/workspace/project_moon` checkout; do not create another Git worktree unless the user requests one.
- Do not commit generated `node_modules`, `dist`, screenshots, research clones, or downloaded original game assets. Keep temporary research outside the checkout. Do not overwrite unrelated user work.

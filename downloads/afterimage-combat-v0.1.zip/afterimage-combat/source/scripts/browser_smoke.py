"""Real Chromium smoke test using only the public UI; no injected game state.

Start `npm run dev -- --port 5173 --strictPort` before running this script.
Requires Python Playwright and a Chromium binary (CHROMIUM_PATH can override it).
"""
import json
import os
from pathlib import Path
from playwright.sync_api import sync_playwright

ARTIFACTS = Path(__file__).resolve().parents[1] / '.artifacts'
ARTIFACTS.mkdir(exist_ok=True)

with sync_playwright() as p:
    browser = p.chromium.launch(
        executable_path=os.environ.get('CHROMIUM_PATH', '/usr/bin/chromium'),
        headless=True, args=['--no-sandbox'],
    )
    page = browser.new_page(viewport={'width': 1440, 'height': 1000})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    standalone_path = os.environ.get('GAME_HTML_PATH')
    if standalone_path:
        # Cloud Chromium blocks file:// navigation by policy. Render the exact
        # downloaded document with networking disabled to verify its autonomy.
        page.context.set_offline(True)
        page.set_content(Path(standalone_path).read_text(encoding='utf-8'), wait_until='load')
    else:
        response = page.goto(os.environ.get('GAME_URL', 'http://127.0.0.1:5173'), wait_until='networkidle')
        assert response.status == 200
    assert page.locator('[data-unit]').count() == 8
    page.wait_for_selector('[data-action="execute"]')
    page.screenshot(path=str(ARTIFACTS / 'desktop.png'), full_page=True)

    # Instructions, archive, focus trap, and pause/resume.
    page.locator('[data-action="guide"]').click()
    assert page.locator('dialog').is_visible()
    assert '33%' in page.locator('dialog').inner_text()
    page.keyboard.press('Escape')
    assert page.locator('dialog').count() == 0
    page.locator('[data-action="lore"]').click()
    assert '독립적인 공식 출처 검증은 아닙니다' in page.locator('dialog').inner_text()
    page.locator('[data-action="close-modal"]').first.click()

    # Keyboard selects a skill, switches its target, and executes a real attack.
    page.keyboard.press('1')
    page.keyboard.press('ArrowRight')
    page.keyboard.press('Enter')
    page.wait_for_function("document.querySelectorAll('.log-entry.action').length >= 1")
    page.locator('[data-action="restart"]').click()
    assert page.locator('dialog').is_visible()
    page.locator('[data-action="confirm-restart"]').click()
    assert page.locator('.log-entry.action').count() == 0

    # Check common widths for overflow and touch target interaction.
    for width in [360, 390, 768, 1024, 1440]:
        page.set_viewport_size({'width': width, 'height': 844})
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), width
    page.set_viewport_size({'width': 390, 'height': 844})
    page.locator('[data-skill="mark"]').click()
    page.locator('[data-unit="e4"]').click()
    assert '속삭이는 자' in page.locator('.target-panel h3').inner_text()
    page.screenshot(path=str(ARTIFACTS / 'mobile.png'), full_page=True)
    page.set_viewport_size({'width': 1440, 'height': 1000})
    page.locator('[data-action="restart"]').click()

    page.locator('[data-action="sound"]').click()
    assert page.locator('[data-action="sound"]').get_attribute('aria-pressed') == 'true'
    page.locator('[data-action="sound"]').click()
    page.locator('[data-action="fast"]').click()

    # Complete the encounter through actual buttons. Prioritize stress dealers,
    # apply bleed up front, and heal critically injured allies.
    player_actions = 0
    for _ in range(300):
        if page.locator('.result-panel').count():
            break
        if not page.locator('.skill-list').count():
            page.wait_for_timeout(100)
            continue
        skills = page.locator('.skill-list button:enabled').evaluate_all('(els) => els.map(e => e.dataset.skill)')
        heroes = page.locator('.unit.hero').evaluate_all("""els => els.map(e => ({
            id: e.dataset.unit,
            hp: Number(e.querySelector('.hp-line b').textContent),
            max: Number(e.querySelector('.hp-line span').textContent.replace('/', '').trim())
        }))""")
        hurt = sorted(heroes, key=lambda h: h['hp'] / h['max'])[0]
        target = None
        if 'mend' in skills and hurt['hp'] < hurt['max'] * .65:
            skill, target = 'mend', hurt['id']
        else:
            skill = next((s for s in ['shot', 'cut', 'cleave', 'pierce', 'knife'] if s in skills), skills[0])
        page.locator(f'[data-skill="{skill}"]').click()
        targets = page.locator('.unit.targetable').evaluate_all('(els) => els.map(e => e.dataset.unit)')
        if target not in targets:
            target = next((t for t in ['e4', 'e3', 'e2', 'e1'] if t in targets), targets[0])
        page.locator(f'[data-unit="{target}"]').click()
        page.locator('[data-action="execute"]').click()
        player_actions += 1
    assert page.locator('.result-panel.victory').count() == 1, page.locator('.journal-entries').inner_text()
    result_text = page.locator('.result-panel').inner_text()
    page.screenshot(path=str(ARTIFACTS / 'victory.png'), full_page=True)
    page.locator('.result-panel [data-action="restart"]').click()
    assert page.locator('[data-unit]').count() == 8
    assert page.locator('.round-number b').inner_text() == '01'
    assert not errors, errors
    print(json.dumps({'status': 'passed', 'browser_errors': errors, 'widths_tested': [360, 390, 768, 1024, 1440], 'player_actions_to_victory': player_actions, 'result': result_text}, ensure_ascii=False))
    browser.close()

import { build } from 'vite';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, '.artifacts', 'downloads');
await mkdir(output, { recursive: true });

// Bundle as a classic script so the downloaded HTML also works via file://.
// Keep this separate from Vite's normal production build.
const result = await build({
  root,
  configFile: false,
  logLevel: 'warn',
  build: {
    write: false,
    minify: true,
    cssCodeSplit: false,
    lib: { entry: path.join(root, 'src', 'main.js'), name: 'AfterimageGame', formats: ['iife'] },
  },
});
const files = (Array.isArray(result) ? result : [result]).flatMap(r => r.output);
const js = files.filter(f => f.type === 'chunk').map(f => f.code).join('\n');
const css = files.filter(f => f.type === 'asset' && f.fileName.endsWith('.css')).map(f => String(f.source)).join('\n');
if (!js || !css) throw new Error('Standalone bundle must contain both JavaScript and CSS.');
const favicon = await readFile(path.join(root, 'public', 'favicon.svg'), 'utf8');
let html = await readFile(path.join(root, 'index.html'), 'utf8');
html = html.replace('href="/favicon.svg"', `href="data:image/svg+xml,${encodeURIComponent(favicon)}"`);
html = html.replace('</head>', `<style>${css}</style>\n  </head>`);
html = html.replace('<script type="module" src="/src/main.js"></script>', `<script>${js.replace(/<\/script/gi, '<\\/script')}</script>`);
await writeFile(path.join(output, 'game.html'), html, 'utf8');

const instructions = `골목의 잔향 — 전투 프로토타입 v0.1

1. ZIP을 먼저 압축 해제하세요.
2. play 폴더의 game.html을 Chrome, Edge, Firefox 또는 Safari로 여세요.
3. 별도 설치나 인터넷 연결 없이 플레이할 수 있습니다.

기술 카드 → 빛나는 대상 → 금색 실행 버튼
1~3: 기술 / 좌우 방향키: 대상 / Enter: 실행 / M: 이동 / G: 방어 / W: 대기

브라우저 새로고침 시 전투가 처음부터 시작됩니다.
진행 상태 저장과 탐험·사무소 운영은 아직 구현하지 않았습니다.

source/에는 수정 가능한 소스와 개발용 README가 있습니다.
source/docs/RESEARCH.md: 세계관·출처·검증 한계
source/docs/COMBAT.md: 실제 전투 규칙

Project Moon 세계관을 바탕으로 한 비공식 팬 프로토타입입니다.
인물·장소·시각 자료와 전투 수치는 창작입니다.
`;
await writeFile(path.join(output, 'START-HERE.txt'), instructions, 'utf8');

// Use Python's standard library for portable ZIP generation; do not ship caches,
// Git metadata, installed dependencies, or environment-specific credentials.
execFileSync('python', ['-c', `
import pathlib, sys, zipfile
root, output = map(pathlib.Path, sys.argv[1:])
root_files = {'.gitignore', 'AGENTS.md', 'README.md', 'index.html', 'package.json', 'package-lock.json'}
source_dirs = {'src', 'public', 'docs', 'scripts', 'tests'}
with zipfile.ZipFile(output / 'afterimage-combat-v0.1.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(output / 'game.html', 'afterimage-combat/play/game.html')
    archive.write(output / 'START-HERE.txt', 'afterimage-combat/START-HERE.txt')
    candidates = [root / name for name in root_files]
    for name in source_dirs:
        candidates.extend((root / name).rglob('*'))
    for file in sorted(candidates):
        rel = file.relative_to(root)
        if '__pycache__' in rel.parts or not file.is_file() or file.is_symlink():
            continue
        archive.write(file, 'afterimage-combat/source/' + rel.as_posix())
with zipfile.ZipFile(output / 'afterimage-combat-v0.1.zip') as archive:
    error = archive.testzip()
    if error:
        raise RuntimeError('ZIP integrity check failed: ' + error)
    print('ZIP integrity: passed (' + str(len(archive.namelist())) + ' files)')
`, root, output], { stdio: 'inherit' });
console.log(`Standalone game and ZIP written to ${output}`);

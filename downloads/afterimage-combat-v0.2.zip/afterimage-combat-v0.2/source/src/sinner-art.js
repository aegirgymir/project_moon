import { SINNERS } from './sinners.js';

// Original, articulated SVG fan illustrations. No remote assets are loaded.
const appearance = {
  yisang: { hair: '#252830', shine: '#52545b', eye: '#695a54', coat: '#c5c4b8', lining: '#8d918a', white: true,
    front: 'M70 57 71 37 84 22 110 24 127 41 128 64 116 50 110 38 100 56 94 36 83 61 78 47Z',
    back: 'M73 39 86 22 109 20 126 36 132 67 118 79 113 45Z' },
  faust: { hair: '#dce5df', shine: '#f5f3e5', eye: '#a7b4c0', coat: '#2c3138', lining: '#814e49',
    front: 'M68 65 68 40Q76 18 100 22Q124 20 133 43L130 84 117 76 121 49 109 42 105 67 98 42 88 63 85 43 76 79Z',
    back: 'M69 48Q72 19 101 20Q132 22 133 52L137 102 119 93 103 112 82 95 65 103Z' },
  don: { hair: '#cfa24b', shine: '#f0cd73', eye: '#e8b540', coat: '#323337', lining: '#9d4a35', short: true,
    front: 'M67 56 70 36 84 25 108 22 126 37 129 67 118 78 116 45 106 63 102 38 91 61 87 38 77 77 70 72Z',
    back: 'M70 42 81 25 107 20 126 35 133 73 124 86 113 72 79 83 65 71Z' },
  ryoshu: { hair: '#24232a', shine: '#66504f', eye: '#b8473d', coat: '#2b2a30', lining: '#943e36',
    front: 'M67 63 70 37 82 24 110 23 129 44 128 79 118 76 116 45 106 55 102 36 89 58 84 39 77 81 68 81Z',
    back: 'M69 38 83 23 109 21 127 35 133 84 116 89 77 86 65 81Z' },
  meursault: { hair: '#3a414b', shine: '#6b7580', eye: '#6e85a0', coat: '#30373e', lining: '#53677b', broad: true,
    front: 'M69 51 71 34 85 24 108 24 124 35 128 57 119 44 113 43 107 33 103 44 93 33 86 47 79 42 75 59Z',
    back: 'M71 42 80 28 110 22 126 34 128 63 118 65 80 60Z' },
  honglu: { hair: '#202b30', shine: '#426b70', eye: '#66bbae', coat: '#2b3339', lining: '#599388',
    front: 'M68 59 73 34 94 23 115 30 129 50 126 72 115 52 110 37 105 65 99 39 87 61 82 45 75 76Z',
    back: 'M76 30Q46 34 58 101L44 151 67 159 81 104 95 68 119 79 136 71 127 40 109 24Z' },
  heathcliff: { hair: '#4c3a32', shine: '#8d6c50', eye: '#b191a2', coat: '#413b3b', lining: '#6c4b74', broad: true,
    front: 'M64 59 71 44 64 38 82 35 78 23 95 29 105 19 112 29 125 27 126 39 139 47 129 56 130 70 117 57 111 39 101 56 95 36 87 55 76 45 75 73Z',
    back: 'M72 40 87 25 109 24 126 36 133 64 121 78 78 69Z' },
  ishmael: { hair: '#bd6034', shine: '#edab5d', eye: '#70967a', coat: '#bbc0ad', lining: '#936746', white: true,
    front: 'M64 62 72 36 86 25 109 22 129 42 131 70 121 85 116 47 111 38 99 60 93 39 80 64 77 85 66 80Z',
    back: 'M75 31Q53 35 57 70L47 95 54 113 43 139 57 151 46 173 72 162 77 191 98 163 112 174 134 159 144 141 136 122 147 101 135 81 135 47 115 24Z' },
  rodion: { hair: '#6b4738', shine: '#ae7b56', eye: '#c5a569', coat: '#443337', lining: '#ab6152',
    front: 'M67 64 71 39 87 25 109 25 129 44 128 76 117 79 116 44 109 34 102 59 95 38 82 62 78 82 68 86Z',
    back: 'M72 39Q74 22 102 22Q129 25 134 54L141 141 122 173 115 129 95 149 77 162 63 142 69 99 61 80Z' },
  sinclair: { hair: '#c8b36a', shine: '#eddea1', eye: '#95ad70', coat: '#343831', lining: '#6a7350',
    front: 'M68 57 73 37 86 26 110 25 128 42 127 66 118 53 112 39 102 62 97 39 86 58 83 42 75 70Z',
    back: 'M73 37 88 24 112 25 128 43 130 67 117 73 77 68Z' },
  outis: { hair: '#5b5b53', shine: '#9a9c87', eye: '#9aab68', coat: '#343b31', lining: '#797c4c',
    front: 'M67 59 73 35 91 25 113 28 130 45 128 75 116 75 116 43 106 49 102 36 90 61 87 41 76 75Z',
    back: 'M73 37 89 24 113 27 131 42 134 82 119 88 79 82 66 76Z' },
  gregor: { hair: '#5a4835', shine: '#9c8260', eye: '#9b9a68', coat: '#3c3b30', lining: '#87754c',
    front: 'M69 56 74 36 89 25 111 27 129 46 128 72 119 63 114 40 103 56 100 39 88 60 83 43 76 74Z',
    back: 'M76 34Q59 24 55 51L54 80 44 106 64 108 74 82 82 59 118 76 132 68 126 38 108 25Z' },
};

function weapon(kind) {
  const steel = '#b4beb7', edge = '#e2dfc5', dark = '#292c2d', red = '#a34b3e';
  const pieces = {
    dagger: `<path d="m139 164 9 7 27-38 5-26-17 17Z" fill="${steel}"/><path d="m144 166 22-33 10-21" stroke="${edge}"/><path d="m132 169 15 9m-9-7-10 15" stroke="${dark}" stroke-width="5"/>`,
    greatsword: `<path d="m143 165 7 3 35-115-2-31-18 25Z" fill="${steel}" stroke="${dark}" stroke-width="2"/><path d="m147 164 29-110 7-27" stroke="${edge}"/><path d="m130 165 30 8m-16-6-8 28" stroke="${red}" stroke-width="6"/><path d="m168 76 9 3m-13 9 9 3m-13 9 9 3" stroke="#655e53"/>`,
    lance: `<path d="m127 223 53-179" stroke="#8b6e42" stroke-width="7"/><path d="m129 222 50-178" stroke="#d2bb7a" stroke-width="2"/><path d="m176 55 4-24 15-26-2 32-13 21Z" fill="${edge}" stroke="${dark}" stroke-width="2"/><path d="m166 79 21 6m-25 6 20 6" stroke="#aa5043" stroke-width="5"/><path d="m166 92-13 26 13-10 3 14 4-28Z" fill="${red}"/>`,
    katana: `<path d="m142 167 5 6q34-55 39-106-19 57-44 100Z" fill="${steel}" stroke="${edge}"/><path d="m134 171 16 7m-9-5-14 28" stroke="#9a4d3d" stroke-width="5"/><path d="M47 132 19 242" stroke="#3a3031" stroke-width="8"/><path d="m46 133-22 91" stroke="#8c4e43" stroke-width="2"/>`,
    fist: `<path d="m122 147 21-8 18 10-2 26-21 13-15-10Z" fill="#777f83" stroke="${dark}" stroke-width="3"/><path d="m138 149 16 6m-20 5 19 6m-17 4 14 5" stroke="#c7c7b5" stroke-width="3"/><path d="m41 143-13 12 2 25 20 9 11-15-5-26Z" fill="#69747a" stroke="${dark}" stroke-width="3"/>`,
    glaive: `<path d="m128 245 49-180" stroke="#7e684d" stroke-width="6"/><path d="m175 77 9-49q29 32 6 63l-13-3 8-21Z" fill="${steel}" stroke="${edge}"/><path d="m173 89 16 6-10 3-9-1Z" fill="#a99965"/><path d="m176 98-5 39-7-12-4 10 11-40Z" fill="#599385"/>`,
    bat: `<path d="m136 178 7 3 39-110q4-20-6-23-9-2-13 16Z" fill="#6d5044" stroke="${dark}" stroke-width="2"/><path d="m158 106 14 6m-17 5 13 5m-16 5 12 5" stroke="#918e7f" stroke-width="4"/><path d="m175 61-21 71" stroke="#aa8b70" stroke-width="2"/>`,
    mace: `<path d="m139 183 21-64" stroke="#8c7b5c" stroke-width="7"/><path d="m148 125 20 7 8-31-21-7Z" fill="#9a9c8d" stroke="${dark}" stroke-width="2"/><path d="m155 99 11 31m-16-20 22 6" stroke="#d3d0ae" stroke-width="3"/><path d="m44 132-23 20 2 56 24 12 26-27-6-51Z" fill="#667876" stroke="#a7b6a1" stroke-width="3"/><path d="m45 141-13 17 3 42 13 7 15-19-4-39Z" fill="#374c4b"/><path d="m44 151 5 41m-14-19 23 2" stroke="#a7a783" stroke-width="3"/>`,
    axe: `<path d="m131 229 43-155" stroke="#907049" stroke-width="7"/><path d="m174 77 9-39 14 9-3 14q26 17-2 45l-16-12 8-12Z" fill="${steel}" stroke="${dark}" stroke-width="2"/><path d="m192 65q20 16 1 35" fill="none" stroke="${edge}" stroke-width="2"/><path d="m170 88 12 4" stroke="#b8664a" stroke-width="6"/>`,
    halberd: `<path d="m125 248 54-185" stroke="#797053" stroke-width="6"/><path d="m177 77 6-47 10-21 3 24-9 40Z" fill="${steel}" stroke="${edge}"/><path d="m180 52 25 6-5 31-12-3-3-17-10 1Z" fill="${steel}" stroke="${dark}"/><path d="m178 80-15-12 4 20 9 4Z" fill="#8f9b8c"/>`,
    sabre: `<path d="m141 169 7 5 38-91 2-21-12 18Z" fill="${steel}" stroke="${edge}"/><path d="m135 169 17 9q-4 16-15 10" fill="none" stroke="#b4a76e" stroke-width="4"/><path d="m141 175-9 22" stroke="#4c4034" stroke-width="5"/>`,
    insect: `<path d="m123 117 24 11 5 32 16 16-10 20-22-12-9-20-11-24Z" fill="#7c7542" stroke="#242d26" stroke-width="3"/><path d="m139 139 11 5m-11 3 13 6m-11 3 12 6m-7 6 16 7" stroke="#aca65b" stroke-width="3"/><path d="m160 181 24-12-7 24-17 13-9-17Z" fill="#a7a86b" stroke="#35402e" stroke-width="2"/><path d="m160 191 12-5m-31-60 15-7-4 16m-13 21 19-1-7 11" fill="#777d46" stroke="#283225" stroke-width="2"/>`,
  };
  return pieces[kind];
}

export function sinnerFigure(key, id = key) {
  const sinner = SINNERS.find(s => s.key === key);
  if (!sinner) return '';
  const p = appearance[key], uid = `sinner-${id}`, coat = p.coat;
  const long = !p.short, white = p.white;
  const details = [
    key === 'don' ? '<path d="m67 124 8 2-2 11-8-3Z" fill="#e5bd58"/><circle cx="72" cy="115" r="4" fill="#c79c53"/><path d="m71 101 7 4-4 7-6-4Z" fill="#a94e3b"/>' : '',
    key === 'ryoshu' ? '<path d="m91 88 14 1 5 21-23 1Z" fill="#a6433a"/><path d="m84 99 26 10" stroke="#d08159" stroke-width="2"/>' : '',
    key === 'ishmael' ? '<path d="m71 38q28-11 54 7" fill="none" stroke="#d7d7c2" stroke-width="5"/><path d="m127 46 11 15 7-5-14-14" fill="#d8d6bf"/><path d="M55 107q-20 18-11 48" fill="none" stroke="#ba995c" stroke-width="7"/>' : '',
    key === 'honglu' ? '<path d="m72 44-7 19" stroke="#7aa095" stroke-width="4"/><circle cx="72" cy="77" r="3" fill="#bdbd9a"/>' : '',
    key === 'heathcliff' ? '<path d="m119 48-9 20" stroke="#ab7664" stroke-width="1.3"/><path d="m81 103 29-1-4 34-18 11Z" fill="#69556c"/>' : '',
    key === 'outis' ? '<path d="m58 106 15 3-2 5-14-3Zm60-1 14 5-3 6-14-5Z" fill="#a8a67e"/><path d="M112 130h13m-13 5h13m-13 5h10" stroke="#b1aa76" stroke-width="2"/>' : '',
    key === 'gregor' ? '<g fill="none" stroke="#8d8e72" stroke-width="1.6"><rect x="80" y="54" width="15" height="11" rx="3"/><rect x="103" y="55" width="15" height="11" rx="3"/><path d="M95 59h8m-23-2-5-1"/></g><path d="m90 77 11 2 12-3-4 9-12 3-9-5" fill="#70543f"/><path d="m112 78 12 2" stroke="#dacb9c" stroke-width="2"/><path d="m125 79 3-1" stroke="#cc7250" stroke-width="2"/>' : '',
    key === 'yisang' ? '<path d="m53 109 16 2-5 8-9-3Zm1 12 12 3-7 7-7-3Z" fill="#a69a78"/>' : '',
  ].join('');
  return `<svg class="figure sinner-figure figure-${key}" data-sinner-art="${key}" viewBox="0 0 210 325" preserveAspectRatio="xMidYMax meet" aria-hidden="true"><defs><linearGradient id="${uid}-coat" x1="0" x2="1" y2="1"><stop stop-color="${coat}"/><stop offset="1" stop-color="${white ? '#747e7b' : '#171e21'}"/></linearGradient><linearGradient id="${uid}-hair" x2="1" y2="1"><stop stop-color="${p.shine}"/><stop offset=".5" stop-color="${p.hair}"/><stop offset="1" stop-color="${p.hair}"/></linearGradient></defs><ellipse cx="101" cy="309" rx="61" ry="8" fill="#080e0e" opacity=".55"/><g class="rig-body" stroke-linejoin="round"><g class="rig-leg rig-leg-left"><path d="m78 181-13 111 22 2 18-104Z" fill="#252a2c" stroke="#10181b" stroke-width="2"/><path d="m68 288-10 13 29 1 2-14" fill="#161c1e" stroke="#6d746d" stroke-width="1.5"/><path d="m79 211-6 62" stroke="#657069" opacity=".4" stroke-width="2"/></g><g class="rig-leg rig-leg-right"><path d="m100 185 7 108 23-3-8-112Z" fill="#303334" stroke="#11191b" stroke-width="2"/><path d="m106 287 1 15 35-1-13-14" fill="#171d20" stroke="#6d746d" stroke-width="1.5"/><path d="m118 213 5 60" stroke="#72766b" opacity=".3" stroke-width="2"/></g><path class="rig-hair-back" d="${p.back}" fill="url(#${uid}-hair)" stroke="#172025" stroke-width="2"/><path class="rig-coattail" d="m64 139-21 ${long ? '103' : '45'} 39-12 17-39 13 40 38 16-18-${long ? '110' : '55'}Z" fill="${p.lining}" stroke="#151c20" stroke-width="2"/><path d="m78 92-23 16-10 38 19 9-5 49 31-8 11-34 9 36 26 10-8-62 11-28-23-23Z" fill="url(#${uid}-coat)" stroke="#172024" stroke-width="2"/><path d="m82 93 17 17 14-17-8 69-22-7Z" fill="${white ? '#333a3c' : '#c2c4b8'}"/><path d="m91 107 8 2 4 37-7 12-5-13Z" fill="#a14c40" stroke="#682c29"/><path d="m80 93-8 17 13 15-9 13 17 27 3-53m17-18 9 17-13 15 12 13-16 29" fill="${white ? '#d4d1bc' : '#282d32'}" stroke="${white ? '#6e7872' : '#73746b'}" stroke-width="1"/><path d="m64 169 65 5" stroke="#1c2426" stroke-width="7"/><path d="m93 169 12 1v7H93Z" fill="#a79565"/><path d="M67 151h15m32 3h11m-58 31 13-2m37 3 10 4" stroke="${white ? '#68746e' : '#74756a'}" stroke-width="1.3"/><g class="rig-arm rig-arm-left"><path d="m57 110-12 6-9 42 16 18 11-12-12-12 15-28Z" fill="${coat}" stroke="#182126" stroke-width="2"/><path d="m47 166 8 5 9-3 5 7-9 11-12-6Z" fill="#b7a78d" stroke="#555650"/></g><g class="rig-arm rig-arm-right"><path d="m122 108 14 6 16 36-11 25-13-6 10-20-20-27Z" fill="${coat}" stroke="#182126" stroke-width="2"/><path d="m136 163 10 1 8 8-6 11-12-6-3-7Z" fill="#c1b096" stroke="#53534d"/></g><g class="rig-head"><path d="m80 48 40 1-1 25-15 16-17-7-10-20Z" fill="#d2bda1" stroke="#3b4140" stroke-width="1.5"/><path d="m80 54 11 18 14 8 15-12-13 18-17-5-10-16Z" fill="#a79a88"/><path d="m88 82 4 11 9 9 11-9-2-11" fill="#b3a18c" stroke="#454a45"/><path d="m82 56 13-1m10 1 12 2" stroke="#2d3437" stroke-width="2"/><path d="m85 59 9 1m13 0 9 1" stroke="${p.eye}" stroke-width="3"/><path d="m99 60-3 10 5 1m-7 7 12-1" fill="none" stroke="#735e54" stroke-width="1.2"/><path d="${p.front}" fill="url(#${uid}-hair)" stroke="#1b2326" stroke-width="1.6"/><path d="m82 36 9-6 16 1" fill="none" stroke="${p.shine}" stroke-width="2" opacity=".7"/>${details}</g><path d="m64 115 11 2-1 20-13-3Z" fill="#8d4237" stroke="#b68163"/><text x="67" y="130" fill="#e2caa0" font-size="8" font-family="monospace">${sinner.number}</text><g class="rig-weapon">${weapon(sinner.weapon)}</g><path d="m52 117-5 27m80-26 10 25m-75 61-6 28m71-25 7 34" stroke="${white ? '#d5d1b8' : '#747c72'}" stroke-width="1.5" opacity=".55"/></g></svg>`;
}

# Project context

- This repository is a Korean browser combat prototype, “골목의 잔향”. It uses the City setting from Project Moon and takes rank-based tactical inspiration from Darkest Dungeon **1**, not 2.
- Before adding lore, read `docs/RESEARCH.md`. It records what was actually read, source confidence, Korean/English wording differences, and blocked sources. Do not turn a community mirror into an official source, count two translations of the same original as independent confirmation, or claim unvisited websites were verified.
- Persist new research findings and corrections in `docs/RESEARCH.md`; conversation memory alone is insufficient.
- `docs/COMBAT.md` documents the prototype’s own rules. Its stress thresholds do not cause canonical Distortion or E.G.O. v0.2 uses the twelve Limbus Company Sinners with original SVG fan illustrations; abilities, tactical roles, dialogue, stats, passage, and enemies are adaptations. Official character names must not be described as original inventions.
- Keep combat rules in `src/combat.js` independent of the DOM, timers, and browser APIs. Game randomness must use the seeded random function. UI code and enemy scheduling live in `src/main.js`.
- Run `npm test` and `npm run build` for combat changes. `python scripts/browser_smoke.py` runs an optional real Chromium interaction test against the running server; it requires Python Playwright and Chromium.
- Node 24 is available. Use `npm ci --cache /workspace/.npm-cache` in this cloud machine to avoid writing package caches outside writable roots.
- The cloud task is already isolated. Work in the existing `/workspace/project_moon` checkout; do not create another Git worktree unless the user requests one.
- Do not commit generated `node_modules`, `dist`, screenshots, research clones, or downloaded original game assets. Keep temporary research outside the checkout. Do not overwrite unrelated user work.

- Current version is 0.2.0 (UI/release label v0.2). `npm run package` creates versioned standalone HTML and a source/documentation ZIP under `.artifacts/downloads/v0.2/`; preserve v0.1 artifacts.
- Cinematics only present an already-resolved action. Never apply damage, spend an extra turn, or draw RNG while playing/skipping a shot. Input and enemy scheduling must wait until the shot ends. Restart must cancel both timers. Respect reduced motion.
- Download links through `sandbox:` do not work in this chat. The user authorized publishing versioned downloads to the existing GitHub repository. Use a separate `downloads/combat-v0.2` branch and verify remote bytes. Keep the development checkout/index and v0.1 branch unchanged when publishing.

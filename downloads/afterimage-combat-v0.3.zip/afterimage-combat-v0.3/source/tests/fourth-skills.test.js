import test from 'node:test';
import assert from 'node:assert/strict';
import { createBattle, availableTargets, act, nextTurn, getSkill } from '../src/combat.js';
import { SINNERS, DEFAULT_PARTY } from '../src/sinners.js';
import { describeAction } from '../src/cinematic.js';

function prepare(actor) {
  const s = createBattle();
  s.active = actor; s.queue = [actor === 'h4' ? 'h2' : 'h4']; s.seed = 1;
  return s;
}

test('fourth guard skill reaches middle ranks and is limited by actor position and ownership', () => {
  const s = prepare('h1');
  assert.deepEqual(availableTargets(s, 'reach_strike'), ['e2', 'e3']);
  assert.equal(act(s, 'reach_strike', 'e4').ok, false);
  s.order.hero = ['h2', 'h3', 'h1', 'h4'];
  assert.deepEqual(availableTargets(s, 'reach_strike'), ['e2', 'e3']);
  assert.equal(act(s, 'reach_strike', 'e3').ok, true);
  assert.ok(s.units.e3.hp < s.units.e3.maxHp);
  const fourthRank = prepare('h1');
  fourthRank.order.hero = ['h2', 'h3', 'h4', 'h1'];
  assert.deepEqual(availableTargets(fourthRank, 'reach_strike'), []);
  assert.deepEqual(availableTargets(prepare('h3'), 'reach_strike'), []);
});

test('expose marks only a successful hit and cannot mark a defeated target', () => {
  const s = prepare('h2');
  act(s, 'expose', 'e3');
  assert.equal(s.units.e3.marked, 2);
  assert.ok(s.units.e3.hp < s.units.e3.maxHp);
  const miss = prepare('h2'); miss.seed = 1800;
  act(miss, 'expose', 'e3');
  assert.equal(miss.lastAction.kind, 'miss');
  assert.equal(miss.units.e3.marked, 0);
  const lethal = prepare('h2'); lethal.units.e3.hp = 1;
  act(lethal, 'expose', 'e3');
  assert.equal(lethal.units.e3.dead, true);
  assert.equal(lethal.units.e3.marked, 0);
});

test('expose applies its on-hit mark to an actual protector, not the protected unit', () => {
  const s = prepare('h2');
  s.units.e2.guardedBy = 'e1'; s.units.e1.protection = .4;
  act(s, 'expose', 'e2');
  assert.equal(s.units.e1.marked, 2);
  assert.equal(s.units.e2.marked, 0);
  assert.equal(describeAction(s).target.id, 'e1');
});

test('fourth reach skill adds one bleed damage for exactly three target turns', () => {
  const s = prepare('h3');
  act(s, 'bleed_strike', 'e3');
  assert.deepEqual(s.units.e3.bleed, [{ amount: 1, turns: 3 }]);
  const hp = s.units.e3.hp;
  s.units.e3.protection = .8;
  for (let i = 1; i <= 3; i++) {
    s.queue = ['e3']; nextTurn(s);
    assert.equal(s.units.e3.hp, hp - i);
  }
  assert.deepEqual(s.units.e3.bleed, []);
});

test('self treatment works in the front, cures bleed and Death’s Door, and rejects ally targets', () => {
  const s = prepare('h4');
  s.order.hero = ['h4', 'h1', 'h2', 'h3'];
  s.units.h4.hp = 0; s.units.h4.deathsDoor = true;
  s.units.h4.bleed = [{ amount: 2, turns: 3 }];
  assert.deepEqual(availableTargets(s, 'stabilize'), ['h4']);
  const before = structuredClone(s);
  assert.equal(act(s, 'stabilize', 'h1').ok, false);
  assert.deepEqual(s, before);
  assert.equal(act(s, 'stabilize', 'h4').ok, true);
  assert.ok(s.units.h4.hp >= 4 && s.units.h4.hp <= 6);
  assert.equal(s.units.h4.deathsDoor, false);
  assert.deepEqual(s.units.h4.bleed, []);
  const shot = describeAction(s);
  assert.equal(shot.self, true);
  assert.equal(shot.pose, 'support');
});

test('all twelve sinners can execute their fourth skill in a recommended position', () => {
  const slot = { reach_strike: 0, expose: 1, bleed_strike: 2, stabilize: 3 };
  for (const sinner of SINNERS) {
    const skill = sinner.skills[3], index = slot[skill], party = [...DEFAULT_PARTY];
    party[index] = sinner.key;
    const s = createBattle(1, party), actor = `h${index + 1}`;
    s.active = actor; s.queue = [actor === 'h4' ? 'h2' : 'h4']; s.seed = 1;
    const target = skill === 'stabilize' ? actor : 'e3';
    assert.ok(availableTargets(s, skill).includes(target), sinner.name);
    assert.equal(act(s, skill, target).ok, true);
    assert.equal(s.actions, 1);
    assert.equal(describeAction(s).name, getSkill(skill, s.units[actor]).name);
  }
});

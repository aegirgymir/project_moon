# 도시 × 위치 기반 전투 — 조사 기록

조사일: 2026-10-17. 범위: 전투 프로토타입에 필요한 배경 용어와 **다키스트 던전 1편**의 전투 구조. 후속 작업에서도 이 문서를 읽고 근거와 창작을 구분한다.

## 조사 결과를 읽는 방법

- **원문 대조**: 공개 보관본에서 실제 텍스트 또는 데이터를 열어 확인했다. 보관 주체가 개발사라는 뜻은 아니다.
- **언어 대조**: 동일 항목의 KR·EN이 일치한다. 같은 원전의 번역이므로 독립된 두 출처의 검증은 아니다.
- **보조 근거**: 팬 제작 자료의 설명이나 구현으로 확인했다. 원본 게임 실행이나 공식 자료 검증을 대신하지 않는다.
- **검증 대기**: 이번 환경에서 직접 확인하지 못했다. 확정 설정으로 게임에 넣지 않는다.
- **창작/각색**: 이 게임을 위해 만든 내용. 원작의 설정이나 수치로 설명하지 않는다.

공식 사이트·Steam·위키는 환경의 HTTPS 프록시에서 `403 Forbidden`을 반환했다. 따라서 **세계관 전체에 대한 독립적인 공식 출처 교차검증이 끝났다고 주장할 수 없다.** 아래는 실제로 읽은 공개 자료에 한정한 결과다. 네트워크 허용 도메인은 환경 설정 초안에 추가했으며, 초안 저장만으로 실행 환경의 정책이 바뀌지는 않는다.

## 실제로 확인한 자료

### S1. 림버스 컴퍼니 단테의 노트 — 공개 게임 텍스트 보관본

[LocalizeLimbusCompany/LocalizeLimbusCompany](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany), 확인 커밋 `231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a`.

이 저장소는 커뮤니티 현지화 프로젝트다. 개발사 운영 공식 사이트로 취급하지 않는다. KR·EN 디렉터리의 텍스트를 비교했으며, 번역 패키지·아트·전체 대사 파일을 게임에 복사하지 않았다.

- [KR 기본 노트](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/StoryTheaterDanteNoteDetail.json), [EN 기본 노트](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/EN/StoryTheaterDanteNoteDetail.json): 둥지 9, 날개 10, 뒷골목 16, 해결사 18, 조직 23.
- [KR 2](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/StoryTheaterDanteNoteDetail_2.json), 같은 경로 EN: E.G.O 39, 해결사 급수·특색 44.
- [KR 3](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/StoryTheaterDanteNoteDetail_3.json), 같은 경로 EN: E.G.O 53·59, 특이점 60.
- [KR 5](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/StoryTheaterDanteNoteDetail_5.json): 사무소 82, 공방 86. KR 원문 확인, 이번 조사에서 EN 대조는 하지 않음.
- [KR 6](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/StoryTheaterDanteNoteDetail_6.json): 뒤틀림 96, 환상체와의 구별 98·99. KR 원문 확인.
- [KR 10](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/StoryTheaterDanteNoteDetail_10.json): 뒷골목의 밤 147. KR 원문 확인.
- [KR 11](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/StoryTheaterDanteNoteDetail_11.json): 머리 153, 특색 161. KR 원문 확인.
- [KR 13](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/StoryTheaterDanteNoteDetail_13.json): 개인 E.G.O 178. KR 원문 확인. 구체적인 인물의 사건은 스포일러이므로 게임에 반영하지 않음.

이 노트는 **작중 화자인 단테의 관찰·추정**을 포함한다. ‘아마’, ‘같다’, ‘추측’이 있는 문장을 전지적 설명으로 바꾸지 않는다. 서로 다른 시대의 회사 상태나 후반부 정보를 한 시점에 섞지 않는다.

### S2. 다키스트 던전 영웅 기술 데이터의 공개 변환본

[dzerrenner/darkest](https://github.com/dzerrenner/darkest), 확인 커밋 `0d34db16cc9b87f4144649cb69366f90a747d383`.

[highwayman.json](https://github.com/dzerrenner/darkest/blob/0d34db16cc9b87f4144649cb69366f90a747d383/dist/data/heroes/highwayman.json)의 `launch`, `target`, `move`, `atk`, `crit`, `dmg`를 실제로 확인했다. 예를 들어 Pistol Shot의 사용 위치는 `432`, 대상 위치는 `234`; Wicked Slice는 사용 `321`, 대상 `12`로 기록되어 있다. 이것은 **위치 제약을 서로 따로 다루는 설계의 근거**이며, 최신 버전 수치의 보증은 아니다. 오래된 팬 변환본이라 현재 밸런스를 그대로 복제하지 않았다.

### S3. 별도 팬 시뮬레이터의 전투 규칙 조사 노트

[bluefireF5ran/darkest-dungeon-rl-sim](https://github.com/bluefireF5ran/darkest-dungeon-rl-sim), 확인 HEAD `05b1f02b4c186880ef739050c7bda2d9b5218c4b`.

[WIKI_MECHANICS.md](https://github.com/bluefireF5ran/darkest-dungeon-rl-sim/blob/05b1f02b4c186880ef739050c7bda2d9b5218c4b/docs/WIKI_MECHANICS.md) 및 README를 읽었다. 위키에서 추출했다는 설명과 원본 게임 데이터가 우선이라는 주의가 있다. **위키 자체를 직접 읽은 것으로 세지 않는다.** 원본 게임 파일·수치의 모든 항목을 별도로 검증한 것은 아니다. 이 자료의 소스 코드나 텍스트를 게임 구현으로 복사하지 않았다.

### 제외한 자료

`misterwtheface-oss/dd-design-companion`도 README와 WIKI_CONTEXT를 열어 보았지만, **DD1 오버홀 모드 설계용** 자료였다. 모드 밸런스를 원작 규칙으로 잘못 받아들이지 않도록 최종 근거에서 제외했다.

## 도시: 전투 개발에 사용할 배경

도시는 고도 기술과 거대 기업, 생계와 폭력이 공존하는 작품들의 주요 무대다. 이번 전투는 그중 **뒷골목의 해결사 의뢰**라는 작은 단위에 집중한다. 특정 날개의 특이점이나 원작 등장인물의 능력을 임의로 사용하지 않아도 시작할 수 있다.

| 용어 | 이번 조사에서 확인한 뜻 | 근거·판정 | 구현에 미치는 영향 |
|---|---|---|---|
| 도시 / City, 구획 / District | 구획으로 나뉘며 구획 안에 둥지와 뒷골목이 구별됨 | S1 9, KR·EN 대조 | 특정 구획 번호를 확정하지 않음 |
| 둥지 / Nest | 날개의 관리·보호를 받는 중심 지역 | S1 9·10, KR·EN 대조 | 둥지 전체를 안전한 낙원으로 단정하지 않음 |
| 뒷골목 / Backstreets | 둥지 밖의 생활권. 거주·상업·교육 시설도 존재 | S1 16, KR·EN 대조 | 비 내리는 주거·상업 골목으로 표현 |
| 날개 / Wing | 구획을 사실상 지배하며 높은 기술을 가진 거대 기업 | S1 10, KR·EN 대조 | 특정 날개를 현존 악역으로 지정하지 않음 |
| 특이점 / Singularity | 날개 고유의 핵심 기술 | S1 10·60, KR·EN 대조 | 치료 기술에 임의로 특정 특이점 이름을 붙이지 않음 |
| 깃털 / Feather | KR은 ‘날개에 사는 사람’, EN은 ‘날개에서 일하는 사람’으로 서술 | S1 10, **표현 차이 발견** | 모든 둥지 거주민을 깃털이라 단정하지 않고 보류 |
| 해결사 / Fixer | 도시의 다양한 의뢰를 처리하는 유상 직업 | S1 18, KR·EN 대조 | 4명의 창작 해결사를 지휘 |
| 해결사 급수 | 9급이 낮고 1급이 높음. 특색이라는 별도 분류도 존재 | S1 44, KR·EN 대조 | 전투 능력치와 등급을 같은 숫자로 환산하지 않음. 현재 UI에는 급수 없음 |
| 특색 / Color | 특색과 고유 색의 호칭이 존재 | S1 44, KR·EN; 161 KR | 단순한 자동 승급 ‘0급’으로 취급하지 않음 |
| 사무소 / Office | 해결사가 소속될 수 있는 집단이며 분야가 다양함 | S1 82, KR 확인 | 잔향 사무소는 창작 조직 |
| 공방 / Workshop | 장비·도구를 제작, 개조, 판매하는 해결사 집단 | S1 86, KR 확인 | 배경의 수선 공방 간판은 창작 |
| 조직 / Syndicate | 도시의 다양한 집단을 가리키는 폭넓은 용어 | S1 23, KR·EN 대조 | 이름 없는 창작 적 조직원 사용 |
| 머리 / Head | 금기를 어긴 대상에 대한 처벌 권력이 서술됨 | S1 153, KR 확인 | 이번 사건에 직접 개입하지 않음. 화자의 불확실한 소재지 추정은 확정하지 않음 |
| 뒷골목의 밤 / 청소부 | 노트는 새벽 3:13부터 80분간의 활동을 서술 | S1 147, KR 확인 | **이번 전투는 해당 시간으로 지정하지 않음**. 청소부도 등장하지 않음 |
| 환상체 / Abnormality | 뒤틀림·일반 괴물과 구분되는 존재 | S1 98·99, KR 확인 | 현재는 인간 조직원만 등장 |
| 뒤틀림 / Distortion | 사람의 변모 현상. 극단적 감정과 관련되지만 단순한 조건으로 환원되지 않음 | S1 96, KR 확인 | 스트레스 100/200이 자동 뒤틀림을 발생시키지 않음 |
| E.G.O | 환상체 관련 장비·사용과 개인의 발현을 구분할 필요가 있음 | S1 39·53·59 KR·EN, 178 KR | 미구현. ‘스트레스가 높으면 자동 획득’ 규칙을 넣지 않음 |

### 확인을 마치지 않은 항목

26개 구획의 전체 명단·지도, A/B/C사의 역할과 머리의 상세 조직, 하나 협회의 심사 규정, 각 협회의 정확한 관할, 다섯 손가락의 규율, 금기의 전체 목록, 화폐 단위와 총기 규제·가격, 원작 사건들의 상세 연표는 이번 근거만으로 확정하지 않았다. 다음에 필요할 때 공식 자료 또는 원본 게임의 해당 대사와 독립적인 보조 출처를 확인한다. 이 목록은 잘못된 정보라는 뜻이 아니라 **이번 작업에서 검증하지 않았다는 뜻**이다.

## 다키스트 던전 1편: 전투 개요와 채택 범위

DD1의 중요한 전술은 ‘무엇을 공격할까’뿐 아니라 ‘어디에 서서, 어느 위치에 닿는 기술을 쓰며, 체력과 스트레스를 언제 회복할까’에 있다. 속도가 높은 적의 후열 행동을 끊고, 이동으로 무력화된 기술을 복구하는 선택이 의미가 있다. DD2의 토큰·관계·행동 순서를 DD1의 규칙으로 섞지 않는다.

| 항목 | 참고작에서 확인한 개념 | 근거 | 이번 구현 |
|---|---|---|---|
| 대형 | 양측 1~4열, 1열이 전열. 사용 위치와 대상 위치를 각각 제한 | S2 기술 데이터 + S3 Ranks | 채택. 전원 1칸 크기 |
| 라운드 | 보통 각 전투원이 라운드당 한 차례 행동 | S3 Combat core | 채택. 특수 다회 행동 없음 |
| 속도 | 라운드마다 SPD + 1d8 | S3 Initiative | 채택. 동률은 난수로 처리하는 독자 규칙 |
| 기술 | 공격·치료·상태 부여·이동 등으로 한 행동을 선택 | S2 + S3 | 초기 v0.1은 고정 3기술, v0.3은 수감자별 4기술. 공통 이동·방어·대기는 별도 |
| 명중 | 명중·회피와 확률 판정 | S2 `atk` + S3 Accuracy | 단순화. 숨은 +5나 연속 빗나감 보정 없음 |
| 치명타 | 최대 피해의 150%라는 설명 | S3 Crit | 공격 치명타 10%, 최대 피해 ×1.5 반올림. 치료 치명타 없음 |
| 지속 피해 | 출혈·중독은 대상의 차례 시작에 발생, 방어 감소를 무시 | S3 DoT | 출혈만 구현. 중독·저항·치명타의 지속 연장 없음 |
| 보호 | 보호자가 공격을 대신 받음 | S3 Guard | 다음 보호자 차례까지 피해 대리 수신·보호자 피해 −40% |
| 스트레스 | 0~200. 100에서 정신붕괴(affliction) 또는 기상(virtue) 판정, 200에서 심장마비라는 설명 | S3 Stress | **독자 각색**. 100 동요, 200 체력 8 감소·100으로 복귀. 원작의 심장마비 구현이 아님 |
| 죽음의 문턱 | 아군은 0 HP에서 곧바로 죽지 않으며 추가 피해에 사망 위험 | S3 Death’s Door | 기본 생존 67%, 추가 피해마다 판정. 치료로 회복. 회복 후 페널티 없음 |
| 표식 | 일부 기술과의 피해 시너지 | S3 Mark | **독자 각색**. 모든 공격의 피해 +40%, 명중 시 2회 소모 |
| 시체 | 적 사망 후에도 위치를 점유하는 시체가 존재 | S3 Corpses | 생략. 사망한 유닛은 제거되고 즉시 전열로 압축 |
| 장기 관리 | 탐험·조명·장신구·특성·성장과 전투가 연동 | S3, 일반 개요 | 이번 범위에서 제외 |

S2와 S3에서 **사용 열/대상 열 분리, 위치에 따른 기술 선택**은 일치한다. SPD+1d8·스트레스 임계치 등의 세부 수치는 이번에 S3의 보조 근거만 확보했으므로 ‘독립적으로 완전 검증된 원작 수치’로 표시하지 않는다. 프로토타입은 아래 별도 규칙 문서와 테스트가 실제 기준이다.

## 검증 중 발견한 혼동과 처리

1. **깃털의 범위**: KR·EN의 표현이 완전히 같지 않다. 일반화하지 않았다.
2. **뒷골목=텅 빈 무법 폐허**: 노트에는 음식점·주거·학교가 나온다. 생활 공간이 있는 골목으로 그렸다. 모든 질서와 규제가 사라졌다고 서술하지 않았다.
3. **스트레스=뒤틀림 확정**: 노트 자체가 추가 조건의 존재를 의문으로 남긴다. 전투의 스트레스 수치와 세계관의 변모 현상을 분리했다.
4. **E.G.O의 단일 취급**: 환상체 관련 사용과 개인 발현을 혼합하지 않았다. 프로토타입에서는 보류했다.
5. **다키스트 던전의 모드 수치=원작**: 오버홀 설계 도구를 원작 근거에서 제외했다.
6. **원작 200 스트레스=현재 붕괴 규칙**: 서로 다르다. 현재 체력 8 감소는 창작 규칙이라고 화면과 문서에 명시했다.
7. **같은 원전의 두 번역=독립 교차검증**: 그렇지 않다. 언어 대조와 독립 출처 대조를 구분했다.

## 다음 조사에서 직접 확인할 출처

다음 URL들은 이번 환경에서 **직접 확인하지 못한 후속 확인 대상**이다. 아래 링크를 달았다는 사실을 열람의 증거로 사용하지 않는다.

- [Project Moon 공식 사이트](https://projectmoon.studio/), [Limbus Company 공식 사이트](https://limbuscompany.com/).
- [다키스트 던전 Steam 공식 소개](https://store.steampowered.com/app/262060/Darkest_Dungeon/), [로보토미 코퍼레이션 Steam 공식 소개](https://store.steampowered.com/app/568220/).
- [다키스트 던전 커뮤니티 위키](https://darkestdungeon.wiki.gg/), [림버스 컴퍼니 커뮤니티 위키](https://limbuscompany.wiki.gg/).

공식 소개는 장르와 전반적 배경의 근거이고, 상세 전투 공식은 게임의 원본 데이터와 실제 플레이를 우선해 확인해야 한다. 커뮤니티 위키도 정오표와 버전 차이가 있을 수 있다.

## v0.1의 창작 요소 (이전 버전 기록)

‘골목의 잔향’, ‘잔향 사무소’, 강현·서린·이도·윤서, 제7 배수로와 통행 확보 의뢰, 네 적의 이름·외형·능력은 이 프로토타입을 위한 창작이다. 이미지·아이콘·배경은 코드로 그린 SVG이며, 원작 이미지·음원·대사를 게임 자산으로 사용하지 않았다. 공식 게임 또는 공식 설정의 일부라고 주장하지 않는다.

영구적인 대화 기억을 전제로 하지 않는다. 향후 작업의 기억은 이 문서, `COMBAT.md`, 루트 `AGENTS.md`에 저장한다.

## v0.2 수감자 교체 기록 — 2026-10-18

v0.2부터 기존 창작 해결사 네 명을 《림버스 컴퍼니》의 수감자들로 교체했다. 기본 편성은 전열부터 돈키호테·료슈·이상·파우스트이고, 12명 중 4명을 골라 편성할 수 있다. 앞 절의 v0.1 인물 설명은 이전 버전의 기록이다.

동일 공개 보관본의 다음 파일을 직접 읽고 인격 ID `10101`~`11201`의 한국어·영어 이름을 대조했다. 공식 사이트는 재시도에서도 HTTPS 프록시 403으로 열람하지 못했다. 독립적인 공식 확인으로 취급하지 않는다.

- [KR Personalities.json](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/Personalities.json)
- [EN Personalities.json](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/EN/Personalities.json)
- [KR Characters.json](https://github.com/LocalizeLimbusCompany/LocalizeLimbusCompany/blob/231a8bcfc347273e7769b70ebc4f9f3e2fecaa5a/KR/Characters.json)

대조한 이름은 이상/Yi Sang, 파우스트/Faust, 돈키호테/Don Quixote, 료슈/Ryōshū, 뫼르소/Meursault, 홍루/Hong Lu, 히스클리프/Heathcliff, 이스마엘/Ishmael, 로쟈/Rodion, 싱클레어/Sinclair, 오티스/Outis, 그레고르/Gregor다. 데이터 내부의 연속 인덱스와 복장에 표시하는 수감자 번호는 별개이며 `Characters.json`의 ID를 그대로 의상 번호로 사용하지 않았다.

일러스트는 단검을 든 이상의 흰 외투, 파우스트의 밝은 머리와 대검, 돈키호테의 금발과 랜스, 료슈의 짙은 단발과 도검 등 널리 알려진 특징을 바탕으로 코드를 작성한 **독자적인 SVG 팬 일러스트**다. 공식 일러스트·스프라이트를 추출하거나 재배포한 것이 아니며, 세부 복식·색감까지 공식 자료와 대조했다고 주장하지 않는다.

기술명·짧은 대사·전열/지원 역할·체력·속도는 이 게임에 맞춰 만든 각색이다. 예를 들어 파우스트의 회복, 이상의 원거리 단검, 그레고르의 응급 지원은 원작 기본 인격의 실제 기술 재현이 아니다. E.G.O·뒤틀림·부활 계약을 새 규칙으로 구현하지 않았다.

다키스트 던전의 행동 중 확대 연출은 공격자·대상 분리, 확대, 배경 어둡게 하기, 동작 후 복귀라는 표현 방식으로 참고했으며, 원작의 이미지·동영상·음원이나 연출 코드를 가져오지 않았다.

## v0.3 모델·스킬 변경 기록 — 2026-10-18

사용자의 요청에 따라 12명의 모델을 큰 머리와 짧은 팔다리의 SD 비율, 3/4 방향 얼굴, 굵은 외곽선, 셀 명암과 분절 동작이 있는 2D 팬 모델로 재구성했다. 《림버스 컴퍼니》 전투 모델의 분위기를 참고한 독자 그림이며, 공식 스프라이트·Spine 데이터·일러스트를 추출하거나 정확히 복제했다고 주장하지 않는다.

스트레스 아래의 캐릭터 대사와 `quote` 데이터 필드는 제거했다. 각 수감자의 고유 스킬을 네 개로 확장했고, 추가 기술은 전열의 중열 공격·근접의 표식 공격·중후열의 출혈 공격·지원의 자가 치료로 각색했다. 원작의 네 번째 기본 스킬이나 새 정사 능력을 발견한 것이 아니다. 이름과 효과의 기준은 `COMBAT.md`와 `src/combat.js`, `src/sinners.js`다.

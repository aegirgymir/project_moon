import { getSkill } from './combat.js';

export const SHOT_DURATION = { normal: 1180, fast: 560, reduced: 140 };

export function describeAction(state, { fast = false, reduced = false } = {}) {
  const action = state.lastAction;
  if (!action) return null;
  const actor = state.units[action.actor], target = state.units[action.target];
  const skill = getSkill(action.skill, actor);
  let pose = 'support';
  if (skill.damage) {
    const weapon = actor.weapon || { brute: 'bat', hook: 'katana', watcher: 'gun', whisper: 'spell' }[actor.look];
    pose = ['lance', 'dagger', 'sabre', 'halberd'].includes(weapon) && action.skill !== 'cut' ? 'thrust'
      : weapon === 'gun' ? 'shoot'
      : ['bat', 'mace', 'fist', 'insect', 'axe', 'greatsword'].includes(weapon) ? 'strike' : 'slash';
  } else if (action.skill === 'move') pose = 'move';
  else if (skill.effect === 'guard') pose = 'guard';
  else if (skill.stress) pose = 'dread';
  else if (skill.effect === 'mark') pose = 'mark';
  return {
    ...action, actor: { ...actor }, target: { ...target }, name: skill.name, pose,
    reaction: action.kind === 'miss' ? 'dodge' : skill.damage ? 'hurt' : 'receive',
    friendly: actor.side === target.side,
    self: actor.id === target.id,
    duration: reduced ? SHOT_DURATION.reduced : fast ? SHOT_DURATION.fast : SHOT_DURATION.normal,
    reduced,
  };
}

import { SINNERS } from './sinners.js';

// Original articulated, side-facing SD fan models. No remote assets are loaded.
const appearance = {
  yisang: { hair: '#252830', shine: '#52545b', eye: '#695a54', coat: '#c5c4b8', lining: '#8d918a', white: true,
    front: 'M67 61Q63 41 76 29L86 21 104 18 123 28Q136 39 131 62L120 76 120 46Q114 42 107 35L103 58 96 43 87 66 83 44 74 72Z',
    back: 'M73 39 86 22 109 20 126 36 132 67 118 79 113 45Z' },
  faust: { hair: '#dce5df', shine: '#f5f3e5', eye: '#a7b4c0', coat: '#2c3138', lining: '#814e49',
    front: 'M65 67Q60 39 77 27Q88 18 104 21Q129 20 136 45L133 88 120 83 120 48 111 39 106 66 101 44 91 65 86 42Q76 59 76 87L67 83Z',
    back: 'M70 47Q64 19 100 19Q136 16 138 53L139 82Q148 106 134 127L124 112 115 137 99 120 88 133 80 111 67 122 64 91Z' },
  don: { hair: '#cfa24b', shine: '#f0cd73', eye: '#e8b540', coat: '#323337', lining: '#9d4a35', short: true,
    front: 'M64 59Q59 39 77 28Q90 17 108 23Q130 27 132 49L129 79 116 89 118 48 110 37 103 63 99 42 89 64 84 43Q76 60 77 84L67 78Z',
    back: 'M67 45Q64 22 99 20Q133 20 136 52L135 78 122 92 111 80 95 89 82 81 72 89 62 73Z' },
  ryoshu: { hair: '#24232a', shine: '#66504f', eye: '#b8473d', coat: '#2b2a30', lining: '#943e36',
    front: 'M64 67Q62 37 77 27Q97 17 115 26Q132 32 133 55L132 86 118 87 118 46 109 36 105 57 98 40 89 60 84 41 77 85 65 88Z',
    back: 'M67 42Q68 17 103 20Q130 20 135 46L138 90Q118 99 101 89Q80 98 62 88Z' },
  meursault: { hair: '#3a414b', shine: '#6b7580', eye: '#6e85a0', coat: '#30373e', lining: '#53677b', broad: true,
    front: 'M69 51 71 34 85 24 108 24 124 35 128 57 119 44 113 43 107 33 103 44 93 33 86 47 79 42 75 59Z',
    back: 'M71 42 80 28 110 22 126 34 128 63 118 65 80 60Z' },
  honglu: { hair: '#202b30', shine: '#426b70', eye: '#66bbae', coat: '#2b3339', lining: '#599388',
    front: 'M68 59 73 34 94 23 115 30 129 50 126 72 115 52 110 37 105 65 99 39 87 61 82 45 75 76Z',
    back: 'M76 30Q43 20 49 61Q59 101 46 126Q36 145 51 166L70 151Q86 117 79 90L95 68 119 79 136 71 127 40 109 24Z' },
  heathcliff: { hair: '#4c3a32', shine: '#8d6c50', eye: '#b191a2', coat: '#413b3b', lining: '#6c4b74', broad: true,
    front: 'M64 59 71 44 64 38 82 35 78 23 95 29 105 19 112 29 125 27 126 39 139 47 129 56 130 70 117 57 111 39 101 56 95 36 87 55 76 45 75 73Z',
    back: 'M72 40 87 25 109 24 126 36 133 64 121 78 78 69Z' },
  ishmael: { hair: '#bd6034', shine: '#edab5d', eye: '#70967a', coat: '#bbc0ad', lining: '#936746', white: true,
    front: 'M64 62 72 36 86 25 109 22 129 42 131 70 121 85 116 47 111 38 99 60 93 39 80 64 77 85 66 80Z',
    back: 'M75 31Q49 28 53 63Q42 81 51 99Q39 116 47 131Q37 151 49 164L45 180 70 168 77 187 96 167 113 180Q143 170 142 149Q154 132 143 118Q157 102 139 81Q150 41 117 24Z' },
  rodion: { hair: '#6b4738', shine: '#ae7b56', eye: '#c5a569', coat: '#443337', lining: '#ab6152',
    front: 'M67 64 71 39 87 25 109 25 129 44 128 76 117 79 116 44 109 34 102 59 95 38 82 62 78 82 68 86Z',
    back: 'M72 39Q74 17 103 21Q136 21 138 55Q133 86 143 114Q152 148 125 176L115 145Q92 176 73 166L66 145Q52 137 63 109Q70 91 62 73Z' },
  sinclair: { hair: '#c8b36a', shine: '#eddea1', eye: '#95ad70', coat: '#343831', lining: '#6a7350',
    front: 'M68 57 73 37 86 26 110 25 128 42 127 66 118 53 112 39 102 62 97 39 86 58 83 42 75 70Z',
    back: 'M73 37 88 24 112 25 128 43 130 67 117 73 77 68Z' },
  outis: { hair: '#5b5b53', shine: '#9a9c87', eye: '#9aab68', coat: '#343b31', lining: '#797c4c',
    front: 'M67 59 73 35 91 25 113 28 130 45 128 75 116 75 116 43 106 49 102 36 90 61 87 41 76 75Z',
    back: 'M73 37 89 24 113 27 131 42 134 82 119 88 79 82 66 76Z' },
  gregor: { hair: '#5a4835', shine: '#9c8260', eye: '#9b9a68', coat: '#3c3b30', lining: '#87754c',
    front: 'M69 56 74 36 89 25 111 27 129 46 128 72 119 63 114 40 103 56 100 39 88 60 83 43 76 74Z',
    back: 'M76 34Q59 24 55 51L54 80 44 106 64 108 74 82 82 59 118 76 132 68 126 38 108 25Z' },
};

function weapon(kind) {
  const steel = '#b4beb7', edge = '#e2dfc5', dark = '#292c2d', red = '#a34b3e';
  const pieces = {
    dagger: `<path d="m139 164 9 7 27-38 5-26-17 17Z" fill="${steel}"/><path d="m144 166 22-33 10-21" stroke="${edge}"/><path d="m132 169 15 9m-9-7-10 15" stroke="${dark}" stroke-width="5"/>`,
    greatsword: `<path d="m143 165 7 3 35-115-2-31-18 25Z" fill="${steel}" stroke="${dark}" stroke-width="2"/><path d="m147 164 29-110 7-27" stroke="${edge}"/><path d="m130 165 30 8m-16-6-8 28" stroke="${red}" stroke-width="6"/><path d="m168 76 9 3m-13 9 9 3m-13 9 9 3" stroke="#655e53"/>`,
    lance: `<path d="m127 223 53-179" stroke="#8b6e42" stroke-width="7"/><path d="m129 222 50-178" stroke="#d2bb7a" stroke-width="2"/><path d="m176 55 4-24 15-26-2 32-13 21Z" fill="${edge}" stroke="${dark}" stroke-width="2"/><path d="m166 79 21 6m-25 6 20 6" stroke="#aa5043" stroke-width="5"/><path d="m166 92-13 26 13-10 3 14 4-28Z" fill="${red}"/>`,
    katana: `<path d="m142 167 5 6q34-55 39-106-19 57-44 100Z" fill="${steel}" stroke="${edge}"/><path d="m134 171 16 7m-9-5-14 28" stroke="#9a4d3d" stroke-width="5"/><path d="M47 132 19 242" stroke="#3a3031" stroke-width="8"/><path d="m46 133-22 91" stroke="#8c4e43" stroke-width="2"/>`,
    fist: `<path d="m122 147 21-8 18 10-2 26-21 13-15-10Z" fill="#777f83" stroke="${dark}" stroke-width="3"/><path d="m138 149 16 6m-20 5 19 6m-17 4 14 5" stroke="#c7c7b5" stroke-width="3"/><path d="m41 143-13 12 2 25 20 9 11-15-5-26Z" fill="#69747a" stroke="${dark}" stroke-width="3"/>`,
    glaive: `<path d="m128 245 49-180" stroke="#7e684d" stroke-width="6"/><path d="m175 77 9-49q29 32 6 63l-13-3 8-21Z" fill="${steel}" stroke="${edge}"/><path d="m173 89 16 6-10 3-9-1Z" fill="#a99965"/><path d="m176 98-5 39-7-12-4 10 11-40Z" fill="#599385"/>`,
    bat: `<path d="m136 178 7 3 39-110q4-20-6-23-9-2-13 16Z" fill="#6d5044" stroke="${dark}" stroke-width="2"/><path d="m158 106 14 6m-17 5 13 5m-16 5 12 5" stroke="#918e7f" stroke-width="4"/><path d="m175 61-21 71" stroke="#aa8b70" stroke-width="2"/>`,
    mace: `<path d="m139 183 21-64" stroke="#8c7b5c" stroke-width="7"/><path d="m148 125 20 7 8-31-21-7Z" fill="#9a9c8d" stroke="${dark}" stroke-width="2"/><path d="m155 99 11 31m-16-20 22 6" stroke="#d3d0ae" stroke-width="3"/><path d="m44 132-23 20 2 56 24 12 26-27-6-51Z" fill="#667876" stroke="#a7b6a1" stroke-width="3"/><path d="m45 141-13 17 3 42 13 7 15-19-4-39Z" fill="#374c4b"/><path d="m44 151 5 41m-14-19 23 2" stroke="#a7a783" stroke-width="3"/>`,
    axe: `<path d="m131 229 43-155" stroke="#907049" stroke-width="7"/><path d="m174 77 9-39 14 9-3 14q26 17-2 45l-16-12 8-12Z" fill="${steel}" stroke="${dark}" stroke-width="2"/><path d="m192 65q20 16 1 35" fill="none" stroke="${edge}" stroke-width="2"/><path d="m170 88 12 4" stroke="#b8664a" stroke-width="6"/>`,
    halberd: `<path d="m125 248 54-185" stroke="#797053" stroke-width="6"/><path d="m177 77 6-47 10-21 3 24-9 40Z" fill="${steel}" stroke="${edge}"/><path d="m180 52 25 6-5 31-12-3-3-17-10 1Z" fill="${steel}" stroke="${dark}"/><path d="m178 80-15-12 4 20 9 4Z" fill="#8f9b8c"/>`,
    sabre: `<path d="m141 169 7 5 38-91 2-21-12 18Z" fill="${steel}" stroke="${edge}"/><path d="m135 169 17 9q-4 16-15 10" fill="none" stroke="#b4a76e" stroke-width="4"/><path d="m141 175-9 22" stroke="#4c4034" stroke-width="5"/>`,
    insect: `<path d="m123 117 24 11 5 32 16 16-10 20-22-12-9-20-11-24Z" fill="#7c7542" stroke="#242d26" stroke-width="3"/><path d="m139 139 11 5m-11 3 13 6m-11 3 12 6m-7 6 16 7" stroke="#aca65b" stroke-width="3"/><path d="m160 181 24-12-7 24-17 13-9-17Z" fill="#a7a86b" stroke="#35402e" stroke-width="2"/><path d="m160 191 12-5m-31-60 15-7-4 16m-13 21 19-1-7 11" fill="#777d46" stroke="#283225" stroke-width="2"/>`,
  };
  return pieces[kind];
}

function face(key, p, uid) {
  const bright = ['don', 'sinclair', 'honglu'].includes(key);
  const stern = ['ryoshu', 'outis', 'meursault', 'heathcliff'].includes(key);
  const lower = key === 'yisang' || key === 'gregor';
  const eyeTop = bright ? 55 : stern ? 59 : 57;
  const eyeBottom = bright ? 69 : stern ? 66 : 68;
  const eyeShape = `M81 ${eyeTop + 2}Q89 ${eyeTop - 2} 98 ${eyeTop + 3}Q94 ${eyeBottom + 1} 85 ${eyeBottom - 1}Z`;
  return `<path d="M77 43Q91 33 114 41L125 53 124 71Q118 85 106 91Q89 88 80 77L73 63Z" fill="#dec4a6" stroke="#171c23" stroke-width="2"/>
    <path d="M77 56Q82 72 95 79L108 84 124 69Q120 86 106 91Q88 88 79 75Z" fill="#b38c78"/>
    <path d="M120 54 124 71 117 78 114 71Z" fill="#ead2b3"/>
    <path d="M75 56Q65 49 67 61Q68 71 77 70" fill="#c8a58c" stroke="#20232b" stroke-width="1.8"/>
    <path class="model-eye-white" d="${eyeShape}" fill="#e9dfc8"/>
    <clipPath id="${uid}-eye"><path d="${eyeShape}"/></clipPath>
    <g clip-path="url(#${uid}-eye)"><ellipse cx="91" cy="${eyeTop + 7}" rx="4.4" ry="7" fill="${p.eye}"/><ellipse cx="92" cy="${eyeTop + 7}" rx="2" ry="5.5" fill="#29222b"/><circle cx="90" cy="${eyeTop + 3}" r="1.6" fill="#fff9e3"/></g>
    <path d="M106 ${eyeTop + 2}Q114 ${eyeTop - 1} 120 ${eyeTop + 1}Q120 ${eyeBottom - 1} 111 ${eyeBottom - 2}Z" fill="#ded4c2"/>
    <ellipse cx="115" cy="${eyeTop + 5}" rx="3.1" ry="${bright ? 5 : 3.5}" fill="${p.eye}"/><path d="M116 ${eyeTop + 2}v6" stroke="#28232a" stroke-width="1.5"/><circle cx="114" cy="${eyeTop + 2}" r="1" fill="#fff9df"/>
    <path d="M80 ${eyeTop + 2}Q89 ${eyeTop - 2} 98 ${eyeTop + 3}m8-1 14-1" fill="none" stroke="#25212b" stroke-width="2"/>
    <path d="M80 ${eyeTop - 3}Q88 ${stern ? eyeTop - 4 : eyeTop - 7} 98 ${eyeTop - 2}m8-1 14-2" fill="none" stroke="#3b3031" stroke-width="1.8"/>
    ${lower ? '<path d="m82 73 13 1m15-1 8-1" stroke="#8b6e69" stroke-width="1.2"/>' : ''}
    <path d="m104 64 2 8 4 1m-12 9 11-1" fill="none" stroke="#806053" stroke-width="1.2" stroke-linecap="round"/>
    ${bright ? '<path d="m99 81 7 2 6-3" fill="none" stroke="#72504c" stroke-width="1.1"/>' : ''}
    <path d="${p.front}" fill="url(#${uid}-hair)" stroke="#151920" stroke-width="2"/>
    <path d="M77 40Q82 29 96 27m9 1 13 9M74 48l-3 18m49-18 6 14" fill="none" stroke="${p.shine}" stroke-width="1.7" opacity=".72"/>
    ${key === 'ryoshu' ? '<path d="m124 41 3 34" stroke="#9d3c3f" stroke-width="2"/>' : ''}
    ${key === 'ishmael' ? '<path d="M70 37q31-12 56 10" stroke="#eadfbf" stroke-width="5" fill="none"/><path d="m128 47 11 19 7-5-13-17Z" fill="#e8dcbf"/>' : ''}
    ${key === 'honglu' ? '<path d="m72 38-7 25" stroke="#729e95" stroke-width="4"/><circle cx="73" cy="77" r="2.8" fill="#c5cb99"/>' : ''}
    ${key === 'heathcliff' ? '<path d="m118 46-7 25" stroke="#9e685c" stroke-width="1.3"/>' : ''}
    ${key === 'gregor' ? '<g fill="none" stroke="#454536" stroke-width="1.6"><rect x="78" y="53" width="22" height="17" rx="4"/><rect x="105" y="52" width="19" height="16" rx="4"/><path d="M100 59h5m-27-1-5-2"/></g><path d="m87 82 12 3 14-4-5 9-10 3-10-4Z" fill="#78523e"/><path d="m112 82 12 2" stroke="#e3cca1" stroke-width="2"/><path d="m124 84 3-1" stroke="#c96d4f" stroke-width="2"/>' : ''}`.replace(/^\+/gm, '');
}

export function sinnerFigure(key, id = key) {
  const sinner = SINNERS.find(s => s.key === key);
  if (!sinner) return '';
  const p = appearance[key], uid = `sinner-${id}`, white = p.white;
  const coat = p.coat, long = !p.short;
  const bodyShape = p.broad ? 'M76 117 54 132 56 174 65 207 96 215 131 207 143 159 131 127 114 116Z' : 'M80 117 61 132 65 172 68 206 98 216 127 206 136 157 124 127 113 117Z';
  const details = [
    key === 'don' ? '<circle cx="79" cy="139" r="4" fill="#d9b65e"/><path d="m69 151 8 1-2 8-7-2Z" fill="#ce943f"/><path d="m81 152 6 3-3 7-6-3Z" fill="#9d463b"/>' : '',
    key === 'ryoshu' ? '<path d="m93 115 18-2 7 20-29 6Z" fill="#923335"/><path d="m91 121 24 5" stroke="#c66b4c" stroke-width="2"/>' : '',
    key === 'heathcliff' ? '<path d="m90 130 26-4-4 46-17 10Z" fill="#6e516f"/>' : '',
    key === 'outis' ? '<path d="m61 133 14 3-2 6-15-3m65-7 14 5-3 6-14-5" fill="#9c9b72"/><path d="M116 153h12m-12 5h12m-12 5h10" stroke="#b3a87b" stroke-width="2"/>' : '',
    key === 'ishmael' ? '<path d="M70 127Q43 129 54 168" fill="none" stroke="#bca370" stroke-width="6"/><path d="M70 127Q47 131 55 168" fill="none" stroke="#725a3d" stroke-width="1.5"/>' : '',
    key === 'yisang' ? '<path d="m67 140 13 2-3 8-11-4m-1 7 12 3-7 6-8-3" fill="#9e8e6c"/>' : '',
  ].join('');
  return `<svg class="figure sinner-figure figure-${key}" data-sinner-art="${key}" data-model-style="sd-v0.3" viewBox="0 0 225 320" preserveAspectRatio="xMidYMax meet" aria-hidden="true"><defs>
    <linearGradient id="${uid}-coat" x1="0" x2="1" y2="1"><stop stop-color="${coat}"/><stop offset=".48" stop-color="${coat}"/><stop offset=".49" stop-color="${white ? '#858b87' : '#161d25'}"/><stop offset="1" stop-color="${white ? '#858b87' : '#161d25'}"/></linearGradient>
    <linearGradient id="${uid}-hair" x2=".5" y2="1"><stop stop-color="${p.shine}"/><stop offset=".32" stop-color="${p.hair}"/><stop offset="1" stop-color="${p.hair}"/></linearGradient>
    </defs><ellipse cx="105" cy="302" rx="61" ry="9" fill="#080b10" opacity=".7"/>
    <g class="rig-body" stroke-linejoin="round" stroke-linecap="round">
      <g class="rig-leg rig-leg-left"><path d="M78 202 70 243 61 269 84 276 103 217Z" fill="#292a30" stroke="#10131a" stroke-width="3"/><path d="m61 259 27 7-1 28-42 1 2-11 13-7Z" fill="#24272b" stroke="#0d131b" stroke-width="3"/><path d="m52 289 33-1" stroke="#74746b" stroke-width="2"/><path d="m64 267 16 4m-19 2 15 4m-17 1 15 3" stroke="#90816a" stroke-width="1.5"/></g>
      <g class="rig-leg rig-leg-right"><path d="m103 207 7 42 10 25 23-8-15-62Z" fill="#38383b" stroke="#12151d" stroke-width="3"/><path d="m115 261 28-3 5 22 14 7-2 9-44-1Z" fill="#25282d" stroke="#10151d" stroke-width="3"/><path d="m120 290 36 1" stroke="#858175" stroke-width="2"/><path d="m122 268 14-2m-12 8 14-2m-10 8 13-2" stroke="#9a8a74" stroke-width="1.5"/></g>
      <g transform="translate(-14 -15) scale(1.32)"><path class="rig-hair-back" d="${p.back}" fill="url(#${uid}-hair)" stroke="#111720" stroke-width="2.5"/></g>
      <path class="rig-coattail" d="M69 175 46 ${long ? '242' : '207'} 81 226 103 202 121 230 150 ${long ? '244' : '211'} 130 176Z" fill="${p.lining}" stroke="#11161e" stroke-width="3"/>
      <path d="${bodyShape}" fill="url(#${uid}-coat)" stroke="#10141d" stroke-width="3.2"/>
      <path d="m87 121 15 13 13-15-5 57-19 13-3-42Z" fill="${white ? '#31373c' : '#ccc6b7'}" stroke="#2a2d32" stroke-width="1.4"/>
      <path d="m99 134 8 1 4 33-8 12-8-10Z" fill="#ad4038" stroke="#4c2023" stroke-width="1.5"/>
      <path d="m84 121-11 17 14 13-9 13 20 25 1-54m15-15 12 17-14 15 13 14-16 26" fill="${white ? '#d4cfc0' : '#292d35'}" stroke="${white ? '#4d5654' : '#727069'}" stroke-width="1.4"/>
      <path d="m67 192 62 2" stroke="#1b1d26" stroke-width="8"/><path d="m98 189 13 1v9H98Z" fill="#b29c68" stroke="#3d382d" stroke-width="1.4"/>
      <path d="m71 172 11 1m35 1 10 1m-52 32 12-2m29 3 10 4" stroke="${white ? '#4f5d59' : '#8b8173'}" stroke-width="1.2"/>
      <g class="rig-arm rig-arm-left"><path d="m65 129-14 5-12 36 15 26 15-8-13-18 17-25Z" fill="${coat}" stroke="#141923" stroke-width="3"/><path d="m54 181 13 5 6 10-7 10-15-9-6-8Z" fill="#c5a88b" stroke="#191f25" stroke-width="2"/><path d="m52 194 7 5m-3-11 7 6" stroke="#8e6c58" stroke-width="1.3"/></g>
      <g class="rig-arm rig-arm-right"><path d="m127 130 15 6 18 31-10 21-18-6 10-14-23-24Z" fill="${coat}" stroke="#111821" stroke-width="3"/><path d="m138 177 12 1 9 10-9 14-17-9-2-7Z" fill="#d2b294" stroke="#141c25" stroke-width="2"/><path d="m141 183 8 5m-11 2 8 6" stroke="#99765d" stroke-width="1.2"/></g>
      ${details}<path d="m58 146 14 3-3 22-16-5Z" fill="#a93830" stroke="#2c2226" stroke-width="1.8"/><text x="58" y="162" fill="#edcf9d" font-size="9" font-family="monospace" font-weight="bold">${sinner.number}</text>
      <g class="rig-head"><g transform="translate(-14 -15) scale(1.32)">${face(key, p, uid)}</g></g>
      <g class="rig-weapon"><g transform="translate(-9 4) scale(1.08)">${weapon(sinner.weapon)}</g></g>
      <path d="m62 134-11 27m82-23 13 22" stroke="${white ? '#f0e7d1' : '#938978'}" stroke-width="1.8" opacity=".7"/>
    </g></svg>`.replace(/^\+/gm, '');
}

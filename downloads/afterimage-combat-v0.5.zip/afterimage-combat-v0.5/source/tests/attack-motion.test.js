import test from 'node:test';
import assert from 'node:assert/strict';
import { validateMotion, motionFrameAt, motionLayers } from '../src/attack-motion.js';

// Timing/geometry fixtures only; these are not original game attack frames.
function fixture() {
  return {
    scale: .5, images: { prepare: 'fixture-prepare', hit: 'fixture-hit' },
    clip: { fps: 20, sprites: {
      prepare: { w: 100, h: 200, px: 30, py: 180 },
      hit: { w: 240, h: 120, px: 40, py: 110 },
    }, frames: [
      { f: 0, d: 3, ops: [['prepare', 0, 0, 0, 1, 1, 1]] },
      { f: 3, d: 1, ops: [['hit', 10, -20, 0, 1, 1, 1]] },
      { f: 4, d: 4, ops: [['prepare', 0, 0, 1, .5, 2, 1]] },
    ] },
  };
}

test('original frame holds are preserved through windup, impact and recovery', () => {
  const motion = fixture(), before = structuredClone(motion);
  assert.equal(validateMotion(motion), 400);
  for (const [progress, frame] of [[-1, 0], [0, 0], [.3749, 0], [.375, 3], [.4999, 3], [.5, 4], [1, 4], [2, 4]]) {
    assert.equal(motionFrameAt(motion, progress).f, frame);
  }
  assert.deepEqual(motion, before, 'sampling must not mutate clip data');
});

test('different image dimensions share a pivot; flips, alpha and layer order survive', () => {
  const motion = fixture();
  const initial = motionLayers(motion, motionFrameAt(motion, 0))[0];
  assert.equal(initial.x + 30 * .5, 112.5);
  assert.equal(initial.y + 180 * .5, 340);
  const impact = motionLayers(motion, motionFrameAt(motion, .4))[0];
  assert.equal(impact.x + 40 * .5, 117.5);
  assert.equal(impact.y + 110 * .5, 330);
  const flipped = motionLayers(motion, motionFrameAt(motion, 1))[0];
  assert.equal(flipped.transform, 'scale(-1 1)');
  assert.equal(-flipped.x - 30 * .5 * 2, 112.5);
  assert.equal(flipped.opacity, .5);
  const layers = motionLayers(motion, { ops: [motion.clip.frames[1].ops[0], motion.clip.frames[0].ops[0]] });
  assert.deepEqual(layers.map(x => x.id), ['hit', 'prepare']);
});

test('incomplete timelines, missing assets and non-finite transforms are rejected', () => {
  const changes = [
    m => { m.clip.fps = 0; }, m => { m.scale = Infinity; },
    m => { m.clip.frames[1].f = 4; }, m => { m.clip.frames[1].d = 0; },
    m => { delete m.images.hit; }, m => { delete m.clip.sprites.hit; },
    m => { m.clip.frames[0].ops[0][1] = NaN; },
    m => { m.clip.frames[0].ops[0][4] = 2; },
  ];
  for (const change of changes) { const motion = fixture(); change(motion); assert.throws(() => validateMotion(motion)); }
});

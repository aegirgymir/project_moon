import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { SINNERS } from '../src/sinners.js';
import { LCB_NATIVE_MOTIONS } from '../src/lcb-native-motions.js';
import { motionsForShot, motionImpact } from '../src/lcb-motions.js';
import { validateMotion, motionLayers } from '../src/attack-motion.js';
import { getSkill } from '../src/combat.js';

const manifest = JSON.parse(readFileSync(new URL('../src/assets/lcb-motion/manifest.json', import.meta.url)));
test('all 36 original base attacks have real changing sprites and unchanged source bytes', () => {
  assert.equal(manifest.clips.filter(c => c.name.startsWith('s')).length, 36);
  assert.equal(Object.keys(LCB_NATIVE_MOTIONS).length, 96);
  for (const record of manifest.clips) {
    const data = readFileSync(new URL(`../src/assets/lcb-motion/${record.file}`, import.meta.url));
    assert.equal(createHash('sha256').update(data).digest('hex'), record.sha256);
    const motion = LCB_NATIVE_MOTIONS[`${record.identity}-${record.name}`];
    assert.ok(validateMotion(motion) > 0);
    if (record.name.startsWith('s')) {
      assert.ok(motion.clip.frames.length >= 3);
      assert.ok(new Set(motion.clip.frames.flatMap(f => f.ops.map(o => o[0]))).size >= 2);
      assert.ok(motionImpact(motion) > 0 && motionImpact(motion) < 1);
    }
    for (const frame of motion.clip.frames) {
      for (const layer of motionLayers(motion, frame)) {
        assert.ok([layer.x, layer.y, layer.width, layer.height].every(Number.isFinite));
        assert.ok(layer.width > 0 && layer.height > 0);
      }
    }
  }
  for (const record of Object.values(manifest.sprites)) {
    const data = readFileSync(new URL(`../src/assets/lcb-motion/sprites/${record.file}`, import.meta.url));
    assert.equal(data.length, record.bytes);
    assert.equal(createHash('sha256').update(data).digest('hex'), record.sha256);
  }
});

test('each damaging prototype skill maps to its own sinner and preserves game rules', () => {
  const target = { side: 'enemy' };
  for (const [index, actor] of SINNERS.entries()) {
    for (const skill of actor.skills) {
      const shot = { actor, target, skill, serial: 3, friendly: false, reduced: false, reaction: 'hurt' };
      const before = structuredClone(shot);
      const motion = motionsForShot(shot).actor;
      assert.equal(motion.identity, `${101 + index}01`);
      assert.ok(getSkill(skill, actor).damage ? /^s[123]$/.test(motion.kind) : motion.kind === 'guard');
      assert.deepEqual(shot, before);
      assert.equal(motionsForShot({ ...shot, reduced: true }).actor, null);
    }
  }
  const enemy = { side: 'enemy', look: 'brute' }, hero = { ...SINNERS[0], side: 'hero' };
  assert.equal(motionsForShot({ actor: enemy, target: hero, skill: 'hit', serial: 1, reaction: 'hurt' }).target.kind, 'damaged');
  assert.equal(motionsForShot({ actor: enemy, target: hero, skill: 'hit', serial: 1, reaction: 'dodge' }).target.kind, 'evade');
});

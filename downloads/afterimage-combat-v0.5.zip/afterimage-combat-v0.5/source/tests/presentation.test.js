import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { SINNERS, DEFAULT_PARTY, createParty, VERSION } from '../src/sinners.js';
import { createBattle, act, getSkill } from '../src/combat.js';
import { describeAction, SHOT_DURATION } from '../src/cinematic.js';
import { figure } from '../src/art.js';
import { LCB_SPRITES } from '../src/lcb-sprites.js';

test('each default identity uses the unchanged archived sprite for its sinner', () => {
  const manifest = JSON.parse(readFileSync(new URL('../src/assets/lcb/manifest.json', import.meta.url)));
  assert.equal(manifest.commit, '4b6cb07b3a2608a2f4c59dfe08ce1a41bc16d7c0');
  assert.equal(manifest.assets.length, SINNERS.length);
  for (const [index, sinner] of SINNERS.entries()) {
    const asset = manifest.assets.find(a => a.key === sinner.key);
    assert.equal(asset.identity, `${101 + index}01`);
    assert.equal(LCB_SPRITES[sinner.key].identity, asset.identity);
    const bytes = readFileSync(new URL(`../src/assets/lcb/${asset.file}`, import.meta.url));
    assert.equal(bytes.length, asset.bytes);
    assert.equal(createHash('sha256').update(bytes).digest('hex'), asset.sha256);
    assert.equal(bytes.toString('ascii', 8, 12), 'WEBP');
    assert.equal(new URL(LCB_SPRITES[sinner.key].src).pathname.split('/').at(-1), asset.file);
    assert.ok(figure(sinner.look, sinner.key).includes(`data-identity="${asset.identity}"`));
  }
});

test('all twelve sinners have unique identities, numbers, artwork, and usable skills', () => {
  assert.deepEqual(SINNERS.map(s => s.name), ['이상', '파우스트', '돈키호테', '료슈', '뫼르소', '홍루', '히스클리프', '이스마엘', '로쟈', '싱클레어', '오티스', '그레고르']);
  assert.equal(new Set(SINNERS.map(s => s.key)).size, 12);
  assert.equal(new Set(SINNERS.map(s => s.number)).size, 12);
  for (const s of SINNERS) {
    assert.equal(s.skills.length, 4);
    assert.equal(new Set(s.skills).size, 4);
    assert.equal(new Set(s.skills.map(id => getSkill(id, s).name)).size, 4);
    assert.equal('quote' in s, false);
    assert.ok(s.skills.every(id => getSkill(id, s)));
    const svg = figure(s.look, `test-${s.key}`);
    assert.ok(svg.includes(`data-sinner-art="${s.key}"`));
    assert.ok(svg.includes('data-model-style="lcb-original-idle"'));
    assert.ok(svg.includes('data-original-sprite="'));
    assert.ok(svg.includes('_sprite_idle.webp'));
    assert.ok(!svg.includes('class="rig-weapon"'));
    assert.ok(!svg.includes('undefined'));
  }
});

test('default roster preserves tactical slots while replacing all original characters', () => {
  const s = createBattle();
  assert.deepEqual(s.order.hero.map(id => s.units[id].key), DEFAULT_PARTY);
  assert.deepEqual(s.order.hero.map(id => s.units[id].name), ['돈키호테', '료슈', '이상', '파우스트']);
  assert.equal(getSkill('shot', s.units.h3).name, '비상하는 칼날');
  assert.equal(getSkill('mend', s.units.h4).name, '응급 조율');
});

test('custom parties keep slot IDs, reject duplicates/unknowns, and own their arrays', () => {
  const party = ['ishmael', 'sinclair', 'outis', 'gregor'];
  const a = createBattle(9, party), b = createBattle(9, party);
  assert.equal(a.units.h1.name, '이스마엘');
  assert.equal(a.units.h4.name, '그레고르');
  a.units.h1.skills.push('wait');
  assert.ok(!b.units.h1.skills.includes('wait'));
  assert.ok(!SINNERS.find(s => s.key === 'ishmael').skills.includes('wait'));
  for (const invalid of [[], ['don', 'don', 'yisang', 'faust'], ['don', 'ryoshu', 'yisang', 'unknown'], null]) {
    assert.throws(() => createParty(invalid));
  }
  for (const sinner of SINNERS) {
    const keys = [sinner.key, ...SINNERS.filter(s => s.key !== sinner.key).slice(0, 3).map(s => s.key)];
    assert.equal(createBattle(1, keys).units.h1.name, sinner.name);
  }
});

function perform(actorId, skill, target, party = DEFAULT_PARTY) {
  const state = createBattle(1, party);
  state.active = actorId; state.queue = ['h4']; state.seed = 1;
  assert.equal(act(state, skill, target).ok, true);
  return state;
}

test('each attack type and each faction gets the appropriate action presentation', () => {
  const cases = [
    ['h1', 'cleave', 'e1', 'thrust'], ['h2', 'cut', 'e1', 'slash'],
    ['h3', 'shot', 'e3', 'thrust'], ['h4', 'mend', 'h1', 'support'],
    ['e1', 'hit', 'h1', 'strike'], ['e2', 'hook', 'h2', 'slash'],
    ['e3', 'harass', 'h3', 'shoot'], ['e4', 'dread', 'h1', 'dread'],
    ['h1', 'cover', 'h2', 'guard'], ['h3', 'mark', 'e4', 'mark'],
    ['h1', 'move', 'h2', 'move'], ['h3', 'wait', 'h3', 'support'],
  ];
  for (const [actor, skill, target, pose] of cases) {
    const state = perform(actor, skill, target), before = structuredClone(state);
    const shot = describeAction(state);
    assert.equal(shot.pose, pose, `${actor}/${skill}`);
    assert.equal(shot.actor.id, actor);
    assert.equal(shot.target.id, target);
    assert.equal(shot.serial, 1);
    assert.deepEqual(state, before, 'presentation must not resolve another action or consume RNG');
  }
});

test('healing, guard, self actions, and misses are not presented as damaging hits', () => {
  const heal = describeAction(perform('h4', 'mend', 'h1'));
  assert.equal(heal.friendly, true);
  assert.equal(heal.reaction, 'receive');
  assert.equal(describeAction(perform('h1', 'brace', 'h1')).self, true);
  const miss = createBattle(); miss.active = 'h3'; miss.queue = ['h4']; miss.seed = 1800;
  act(miss, 'shot', 'e4');
  assert.equal(describeAction(miss).reaction, 'dodge');
});

test('guard close-up shows the actual protector and lethal hits keep the defeated target', () => {
  const s = perform('h1', 'cover', 'h2');
  s.active = 'e1'; s.queue = ['h4']; s.seed = 1;
  act(s, 'hit', 'h2');
  assert.equal(describeAction(s).target.id, 'h1');
  const lethal = createBattle();
  ['e1', 'e2', 'e3'].forEach(id => { lethal.units[id].dead = true; });
  lethal.units.e4.hp = 1; lethal.active = 'h1'; lethal.queue = ['h4']; lethal.seed = 1;
  act(lethal, 'cleave', 'e4');
  assert.equal(lethal.result, 'victory');
  assert.equal(describeAction(lethal).target.id, 'e4');
  assert.equal(describeAction(lethal).target.dead, true);
});

test('fast mode and reduced motion shorten presentation without changing outcomes', () => {
  const s = perform('h2', 'cut', 'e1');
  assert.equal(describeAction(s).duration, SHOT_DURATION.normal);
  assert.equal(describeAction(s, { fast: true }).duration, SHOT_DURATION.fast);
  assert.equal(describeAction(s, { fast: true, reduced: true }).duration, SHOT_DURATION.reduced);
  assert.equal(describeAction(s, { reduced: true }).reduced, true);
  assert.equal(describeAction(createBattle()), null);
});

test('UI, package manifest, and lockfile agree on v0.5', () => {
  const info = JSON.parse(readFileSync(new URL('../package.json', import.meta.url)));
  const lock = JSON.parse(readFileSync(new URL('../package-lock.json', import.meta.url)));
  assert.equal(VERSION, info.version.replace(/\.0$/, ''));
  assert.equal(lock.version, info.version);
  assert.equal(lock.packages[''].version, info.version);
});

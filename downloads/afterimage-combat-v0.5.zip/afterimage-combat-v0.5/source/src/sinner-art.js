import { SINNERS } from './sinners.js';
import { LCB_SPRITES } from './lcb-sprites.js';

// Original idle images, without repainting or artificial skeletal deformation.
// Whole-sprite movement and camera effects are this prototype's presentation.
export function sinnerFigure(key, id) {
  const sprite = LCB_SPRITES[key];
  if (!sprite) return null;
  const sinner = SINNERS.find(s => s.key === key);
  const portrait = id.startsWith('portrait-');
  return `<svg class="figure sinner-figure original-sprite figure-${key}" data-sinner-art="${key}" data-model-style="lcb-original-idle" data-identity="${sprite.identity}" viewBox="${portrait ? '60 25 105 125' : '0 0 225 360'}" role="img" aria-label="${sinner.name} LCB 수감자 기본 인격"><image data-original-sprite="${sprite.identity}" href="${sprite.src}" x="${sprite.x}" y="${sprite.y}" width="${sprite.width}" height="${sprite.height}"/></svg>`;
}

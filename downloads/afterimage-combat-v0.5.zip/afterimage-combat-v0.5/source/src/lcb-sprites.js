// Community-extracted original LCB idle sprites. Provenance: assets/lcb/manifest.json.
// Explicit static URLs let Vite embed every image in the standalone offline build.
export const LCB_SPRITES = {
  yisang: { identity: '10101', src: new URL('./assets/lcb/10101_sprite_idle.webp', import.meta.url).href, x: 52.500, y: 40.000, width: 119.250, height: 300.000 },
  faust: { identity: '10201', src: new URL('./assets/lcb/10201_sprite_idle.webp', import.meta.url).href, x: -176.591, y: 40.000, width: 363.636, height: 351.818 },
  don: { identity: '10301', src: new URL('./assets/lcb/10301_sprite_idle.webp', import.meta.url).href, x: 50.903, y: -110.570, width: 148.289, height: 456.274 },
  ryoshu: { identity: '10401', src: new URL('./assets/lcb/10401_sprite_idle.webp', import.meta.url).href, x: 26.250, y: 40.000, width: 219.750, height: 300.000 },
  meursault: { identity: '10501', src: new URL('./assets/lcb/10501_sprite_idle.webp', import.meta.url).href, x: 61.500, y: 40.000, width: 102.000, height: 300.000 },
  honglu: { identity: '10601', src: new URL('./assets/lcb/10601_sprite_idle.webp', import.meta.url).href, x: -99.265, y: 40.000, width: 352.941, height: 342.353 },
  heathcliff: { identity: '10701', src: new URL('./assets/lcb/10701_sprite_idle.webp', import.meta.url).href, x: 12.000, y: 40.000, width: 218.250, height: 300.000 },
  ishmael: { identity: '10801', src: new URL('./assets/lcb/10801_sprite_idle.webp', import.meta.url).href, x: -10.500, y: 40.000, width: 256.500, height: 300.000 },
  rodion: { identity: '10901', src: new URL('./assets/lcb/10901_sprite_idle.webp', import.meta.url).href, x: 18.750, y: 40.000, width: 210.000, height: 300.000 },
  sinclair: { identity: '11001', src: new URL('./assets/lcb/11001_sprite_idle.webp', import.meta.url).href, x: -51.064, y: 40.000, width: 319.149, height: 300.000 },
  outis: { identity: '11101', src: new URL('./assets/lcb/11101_sprite_idle.webp', import.meta.url).href, x: 41.250, y: 40.000, width: 198.000, height: 300.000 },
  gregor: { identity: '11201', src: new URL('./assets/lcb/11201_sprite_idle.webp', import.meta.url).href, x: 34.305, y: 40.000, width: 146.617, height: 300.752 },
};

import { LCB_NATIVE_MOTIONS } from './lcb-native-motions.js';
import { LCB_SPRITES } from './lcb-sprites.js';
import { getSkill } from './combat.js';

// These are presentation mappings for our four prototype skills. They do not
// replace the original game's skill rules or add extra damage/coin rolls.
export function motionsForShot(shot) {
  if (!shot || shot.reduced) return { actor: null, target: null };
  const id = LCB_SPRITES[shot.actor.key]?.identity;
  const skill = getSkill(shot.skill, shot.actor);
  let kind = null;
  if (id) {
    if (skill.damage) {
      kind = ({ cleave: 's1', push: 's2', reach_strike: 's3', cut: 's1', pierce: 's2', expose: 's3', shot: 's1', knife: 's2', bleed_strike: 's3' })[shot.skill];
      // Support roles have only one damaging command. Cycle their three real
      // base attacks across uses, deterministically, without consuming RNG.
      if (shot.actor.skills.includes('mend')) kind = `s${(shot.serial - 1) % 3 + 1}`;
    } else kind = shot.skill === 'move' ? 'move' : 'guard';
  }
  const targetID = LCB_SPRITES[shot.target.key]?.identity;
  const reaction = !shot.friendly && targetID && ['hurt', 'dodge'].includes(shot.reaction)
    ? LCB_NATIVE_MOTIONS[`${targetID}-${shot.reaction === 'dodge' ? 'evade' : 'damaged'}`] : null;
  return { actor: id && kind ? LCB_NATIVE_MOTIONS[`${id}-${kind}`] : null, target: reaction };
}

export function motionImpact(motion) {
  const frames = motion.clip.frames;
  const total = frames.at(-1).f + frames.at(-1).d;
  // The first change after the windup is the presentation's first hit cue.
  // This cue is cosmetic: clip data has no combat events or damage authority.
  return Math.max(.12, Math.min(.85, (frames[1]?.f ?? total * .4) / total));
}

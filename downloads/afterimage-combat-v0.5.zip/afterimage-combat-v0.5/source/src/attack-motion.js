// Replays native sprite draw lists exported by limbus-archive, without RNG or
// battle mutations. f/d are source-frame indices and hold durations, not poses
// to interpolate: swapping the actual sprite is what produces an attack.
export function validateMotion(motion) {
  const clip = motion?.clip;
  if (!(clip?.fps > 0) || !Number.isFinite(clip.fps) || !clip.frames?.length || !(motion.scale > 0) || !Number.isFinite(motion.scale)) throw new Error('Invalid motion timing or scale');
  let end = 0;
  for (const frame of clip.frames) {
    if (!Number.isInteger(frame.f) || !Number.isInteger(frame.d) || frame.d < 1 || frame.f !== end || !Array.isArray(frame.ops)) throw new Error('Motion frames must be contiguous with positive holds');
    end = frame.f + frame.d;
    for (const op of frame.ops) {
      const [id, x, y, flip, alpha, sx, sy] = op;
      const sprite = clip.sprites[id];
      if (op.length !== 7 || !sprite || !motion.images[id] || ![x, y, alpha, sx, sy, sprite.w, sprite.h, sprite.px, sprite.py].every(Number.isFinite) || ![0, 1].includes(flip) || alpha < 0 || alpha > 1 || sx <= 0 || sy <= 0 || sprite.w <= 0 || sprite.h <= 0) throw new Error('Invalid motion sprite reference or transform');
    }
  }
  return end / clip.fps * 1000;
}

export function motionFrameAt(motion, progress) {
  const frames = motion.clip.frames;
  const end = frames.at(-1).f + frames.at(-1).d;
  const sample = Math.min(end - 1, Math.floor(Math.max(0, Math.min(1, progress)) * end));
  return frames.findLast(frame => frame.f <= sample);
}

export function motionLayers(motion, frame) {
  return frame.ops.map(([id, x, y, flip, alpha, sx, sy]) => {
    const sprite = motion.clip.sprites[id], scale = motion.scale;
    const rect = motion.imageRects?.[id] || { width: sprite.w, height: sprite.h, offsetX: 0, offsetY: 0 };
    const px = sprite.px - rect.offsetX, py = sprite.py - rect.offsetY;
    const width = rect.width * sx * scale, height = rect.height * sy * scale;
    // clip JSON pivots use top-left coordinates (unlike _frames.json exports).
    const left = 112.5 + (x - (flip ? rect.width - px : px) * sx) * scale;
    const top = 340 + (y - py * sy) * scale;
    return { id, href: motion.images[id], x: flip ? -left - width : left, y: top, width, height, opacity: alpha, transform: flip ? 'scale(-1 1)' : '' };
  });
}

export function paintMotion(svg, motion, frame) {
  const group = svg.ownerDocument.createElementNS('http://www.w3.org/2000/svg', 'g');
  for (const layer of motionLayers(motion, frame)) {
    const image = svg.ownerDocument.createElementNS('http://www.w3.org/2000/svg', 'image');
    for (const name of ['href', 'x', 'y', 'width', 'height', 'opacity', 'transform']) image.setAttribute(name, String(layer[name]));
    image.dataset.motionSprite = layer.id;
    group.append(image);
  }
  svg.replaceChildren(group);
  svg.dataset.motionFrame = String(frame.f);
}

// Returns an idempotent cancellation function. Reduced motion keeps the idle
// sprite. Missing/broken image files keep the existing portrait instead of a
// blank character; no game timer is owned or modified by this player.
export function playAttackMotion(svg, motion, duration, { reduced = false, delay = 0, onTick = () => {}, clock = window } = {}) {
  if (!svg || !motion || reduced) return () => {};
  validateMotion(motion);
  if (!Number.isFinite(duration) || duration <= 0) throw new Error('Invalid playback duration');
  let cancelled = false, handle = null, started = null, lastFrame = null;
  const originals = [...svg.childNodes];
  const restore = () => { svg.replaceChildren(...originals); delete svg.dataset.motionFrame; delete svg.dataset.originalMotion; };
  const cancel = () => { if (cancelled) return; cancelled = true; if (handle !== null) clock.cancelAnimationFrame(handle); restore(); };
  preloadMotion(motion, clock).then(() => {
    if (cancelled || !svg.isConnected) return;
    const tick = time => {
      if (cancelled || !svg.isConnected) return;
      started ??= time;
      const elapsed = time - started;
      onTick(Math.min(duration, elapsed));
      if (elapsed < delay) { handle = clock.requestAnimationFrame(tick); return; }
      const progress = Math.min(1, (elapsed - delay) / Math.max(1, duration - delay));
      const frame = motionFrameAt(motion, progress);
      if (frame !== lastFrame) { paintMotion(svg, motion, frame); lastFrame = frame; }
      svg.dataset.originalMotion = 'true';
      if (progress < 1) handle = clock.requestAnimationFrame(tick);
    };
    if (!delay) { onTick(0); paintMotion(svg, motion, motion.clip.frames[0]); svg.dataset.originalMotion = 'true'; lastFrame = motion.clip.frames[0]; }
    handle = clock.requestAnimationFrame(tick);
  }).catch(() => { if (!cancelled) restore(); });
  return cancel;
}

// Reuse decoded local images across skills. The presentation timer starts only
// after decoding, so the first attack cannot lose frames while loading assets.
const decodedImages = new Map();
export function preloadMotion(motion, clock = window) {
  if (!motion) return Promise.resolve();
  return Promise.all(Object.values(motion.images).map(src => {
    if (!decodedImages.has(src)) {
      const image = new clock.Image(); image.src = src;
      const pending = image.decode().then(() => image).catch(error => { decodedImages.delete(src); throw error; });
      decodedImages.set(src, pending);
    }
    return decodedImages.get(src);
  }));
}

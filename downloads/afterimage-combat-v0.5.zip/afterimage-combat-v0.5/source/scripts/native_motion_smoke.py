"""Decode all original motion images and exercise all 36 real attack timelines.

Reads actual runtime modules from the development server without exposing test
APIs in the shipped game. The offline game is checked by browser_smoke.py and
package.mjs verifies every embedded source-image hash. Synthetic fixtures live
separately in motion_player_smoke.py.
"""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'.artifacts/v0.5'; OUT.mkdir(parents=True, exist_ok=True)
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1600, 'height': 1200})
    errors = []; page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto('http://127.0.0.1:5173', wait_until='networkidle')
    result = page.evaluate('''async () => {
      const { LCB_NATIVE_MOTIONS } = await import('/src/lcb-native-motions.js');
      const { paintMotion, motionFrameAt, preloadMotion, playAttackMotion } = await import('/src/attack-motion.js');
      const all = Object.values(LCB_NATIVE_MOTIONS);
      await Promise.all(all.map(m => preloadMotion(m)));
      const sources = new Map();
      for (const motion of all) for (const [id, src] of Object.entries(motion.images)) {
        if (sources.has(src)) continue;
        const image = new Image(); image.src = src; await image.decode();
        const rect = motion.imageRects[id];
        if (image.naturalWidth !== rect.width || image.naturalHeight !== rect.height) throw new Error('Decoded dimensions disagree with placement metadata');
        sources.set(src, true);
      }
      document.querySelector('#app').style.display = 'none';
      const board = document.createElement('main');
      board.id = 'native-qa'; board.style.cssText='display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:12px;background:#25312d;color:#eee;width:1580px;margin:0';
      document.body.append(board);
      const attacks = Object.entries(LCB_NATIVE_MOTIONS).filter(([id]) => /-s[123]$/.test(id));
      for (const [id, motion] of attacks) {
        const item = document.createElement('article'); item.style.cssText='height:360px;overflow:hidden;border:1px solid #7c8160';
        const label = document.createElement('p'); label.textContent=id+' / '+motion.sourceName; label.style.cssText='font:12px monospace;text-align:center'; item.append(label);
        const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
        svg.setAttribute('viewBox','-75 -50 375 430'); svg.style.cssText='width:100%;height:320px'; item.append(svg); board.append(item);
        const unique = new Set();
        for (const frame of motion.clip.frames) {
          paintMotion(svg, motion, frame);
          unique.add([...svg.querySelectorAll('image')].map(e=>e.getAttribute('href')).join('|'));
        }
        if (unique.size < 2) throw new Error(id+' never changes its actual sprite');
        paintMotion(svg, motion, motion.clip.frames[Math.min(1,motion.clip.frames.length-1)]);
      }
      const test = attacks.find(([id]) => id === '10101-s3')[1];
      const svg = board.querySelector('svg'); const original = svg.innerHTML;
      const cancel = playAttackMotion(svg, test, 900);
      await new Promise(r=>setTimeout(r,400));
      if (!svg.dataset.originalMotion || svg.dataset.motionFrame === '0') throw new Error('Actual attack animation did not advance');
      cancel();
      if (svg.innerHTML !== original) throw new Error('Skipping did not restore original contents');
      return {attacks:attacks.length, clips:all.length, decoded_images:sources.size, actual_frame_change:true, cancellation:true};
    }''')
    page.set_viewport_size({'width':1600, 'height':3400})
    for index in range(3):
        page.screenshot(path=str(OUT/f'native-attacks-{index+1}.png'), clip={'x':0,'y':index*1110,'width':1600,'height':1110})
    assert not errors, errors
    print(json.dumps({'status':'passed', **result, 'browser_errors':errors}))
    browser.close()

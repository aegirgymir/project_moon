"""Acquire 12 base identities' three real attacks and five poses from the archive.
Requires Pillow. Run from the repository root. Keeps source bytes/hash provenance.
"""
import io, json, hashlib
from pathlib import Path
from PIL import Image
from limbus_archive import BASE, index, key, lookup, fetch, data
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'src/assets/lcb-motion';OUT.mkdir(parents=True,exist_ok=True)
SPRITES=OUT/'sprites';SPRITES.mkdir(exist_ok=True)
KEYS=['yisang','faust','don','ryoshu','meursault','honglu','heathcliff','ishmael','rodion','sinclair','outis','gregor']
# The default Don sprite includes a tall lance above her head.
HEAD_TOP={'don':208}
records=[];sprite_records={};motions={};url_lines=[]
for i,sinner in enumerate(KEYS):
 identity=f'{101+i}01';rows=data('/api/owner_clips',id=identity)
 folder=OUT/identity;folder.mkdir(exist_ok=True)
 (folder/'list.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 selected=[]
 for row in rows:
  if '_CP9' in row.get('animator','') or '_C6' in row.get('animator',''):continue
  if row['kind']=='skill' or row['kind']=='pose' and row['label'] in ['Default','Guard','Evade','Damaged','Move']:
   name='s'+str(row['n']) if row['kind']=='skill' else row['label'].lower()
   request=key('/api/clip',bundle=row['bundle'],clip=row['clip'],go=row['animator_go'],all=1)
   original=fetch(request);clip=json.loads(original)
   if not clip.get('sprites') or not any(f['ops'] for f in clip['frames']):raise ValueError(f'Empty clip {identity}/{name}')
   (folder/(name+'.json')).write_bytes(original)
   image_refs={};image_rects={}
   for sid,sp in clip['sprites'].items():
    if sid not in sprite_records:
     skey=key('/api/object',bundle=sp['bundle'],pid=sp['pid']);b=fetch(skey);im=Image.open(io.BytesIO(b));sha=hashlib.sha256(b).hexdigest();filename=sha+'.'+im.format.lower()
     (SPRITES/filename).write_bytes(b)
     sprite_records[sid]=dict(file=filename,sha256=sha,bytes=len(b),width=im.width,height=im.height,key=skey,storage=lookup(skey))
    rec=sprite_records[sid];image_refs[sid]=rec['file']
    # Packed Sprite images can omit transparent rectangle margins. Preserve
    # their actual pixels, centre the texture in the exported logical canvas.
    dx=sp['w']-rec['width'];dy=sp['h']-rec['height']
    if dx<0 or dy<0:raise ValueError('Image larger than exported sprite rectangle')
    image_rects[sid]=dict(width=rec['width'],height=rec['height'],offsetX=dx/2,offsetY=dy/2)
   rec=dict(identity=identity,sinner=sinner,name=name,row=row,clip=clip,images=image_refs,imageRects=image_rects,key=request,sha256=hashlib.sha256(original).hexdigest(),file=f'{identity}/{name}.json',storage=lookup(request))
   selected.append(rec)
  
 default=next(r for r in selected if r['name']=='default');op=default['clip']['frames'][0]['ops'][0];sp=default['clip']['sprites'][op[0]];sr=default['imageRects'][op[0]]
 im=Image.open(SPRITES/default['images'][op[0]])
 top=HEAD_TOP.get(sinner,sr['offsetY']+im.getbbox()[1])
 body_height=(sp['py']-top)*op[6]
 scale=300/body_height
 for rec in selected:
  rec['scale']=scale;records.append(rec)
  # Store original JSON separately; rendering registration only references it.
  motion_id=f"{identity}-{rec['name']}"
  motions[motion_id]=dict(scale=scale,sourceName=rec['row']['name'],identity=identity,kind=rec['name'],imageRects=rec['imageRects'])
 print(identity,sinner,'clips',len(selected),'scale',round(scale,4),flush=True)
manifest=dict(source='https://limbus-archive.com',build=index['build'],stamp=index['stamp'],rights='Project Moon',readerReference='https://github.com/Schirke/limbus-archive/blob/faaed5791403526abcace1ac9e1859af9d0aade1/ui/site/sw.js',sprites=sprite_records,clips=[{k:v for k,v in r.items() if k not in ['clip','images','imageRects']} for r in records],placement='Actual image pixels retained; omitted transparent margins are centred in the logical sprite rectangle; per-character scale calibrated on idle head-to-pivot height. Don head top is below lance.')
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
unique_files=sorted({r['file'] for r in sprite_records.values()})
for i,name in enumerate(unique_files):url_lines.append(f"  {json.dumps(name)}: new URL('./assets/lcb-motion/sprites/{name}', import.meta.url).href,")
(ROOT/'src/lcb-motion-images.js').write_text('// Original archived image bytes, deduplicated for offline embedding.\nexport const MOTION_IMAGES = {\n'+'\n'.join(url_lines)+'\n};\n')
imports=["import { MOTION_IMAGES } from './lcb-motion-images.js';"]
registrations=[]
for i,r in enumerate(records):
 motion_id=f"{r['identity']}-{r['name']}";imports.append(f"import clip{i} from './assets/lcb-motion/{r['file']}' with {{ type: 'json' }};")
 refs='{'+','.join(json.dumps(k)+': MOTION_IMAGES['+json.dumps(v)+']' for k,v in r['images'].items())+'}'
 registrations.append(f"  {json.dumps(motion_id)}: {{...{json.dumps(motions[motion_id])}, clip: clip{i}, images: {refs}}},")
(ROOT/'src/lcb-native-motions.js').write_text('// Original base-identity clips; see assets/lcb-motion/manifest.json.\n'+'\n'.join(imports)+'\nexport const LCB_NATIVE_MOTIONS = {\n'+'\n'.join(registrations)+'\n};\n')
print('Stored',len(records),'clips;',len(sprite_records),'sprite references;',len(unique_files),'unique images')

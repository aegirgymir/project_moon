"""Exercise sprite playback/cancellation using synthetic test images, not game art."""
import json
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page()
    page.goto('http://127.0.0.1:5173', wait_until='networkidle')
    result = page.evaluate('''async () => {
      const {playAttackMotion} = await import('/src/attack-motion.js');
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      const idle = document.createElementNS(svg.namespaceURI, 'g');
      idle.setAttribute('data-fixture-idle', 'true'); svg.append(idle); document.body.append(svg);
      const source = color => 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="30"><rect width="20" height="30" fill="${color}"/></svg>`);
      const motion = {scale: 1, images: {a: source('blue'), b: source('red')}, clip: {fps: 10,
        sprites: {a: {w:20,h:30,px:10,py:30}, b: {w:20,h:30,px:10,py:30}},
        frames: [{f:0,d:2,ops:[['a',0,0,0,1,1,1]]}, {f:2,d:1,ops:[['b',15,-5,1,.5,1,1]]}, {f:3,d:3,ops:[['a',0,0,0,1,1,1]]}]}};
      let next = 0; const pending = new Map();
      const clock = {Image: window.Image, requestAnimationFrame: f => {pending.set(++next, f); return next;}, cancelAnimationFrame: id => pending.delete(id)};
      const check = (value, message) => {if (!value) throw new Error(message);};
      const ready = async () => {for(let i=0; i<100 && !pending.size; i++) await new Promise(r => setTimeout(r, 5)); check(pending.size > 0, 'images must decode before playing');};
      const tick = time => {const [id, callback] = pending.entries().next().value; pending.delete(id); callback(time);};
      const cancel = playAttackMotion(svg, motion, 600, {clock}); await ready();
      tick(0); check(svg.dataset.motionFrame === '0', 'windup frame');
      tick(199); check(svg.dataset.motionFrame === '0', 'windup hold');
      tick(200); check(svg.dataset.motionFrame === '2', 'attack image must replace the idle pose');
      check(svg.querySelector('image').getAttribute('href') === motion.images.b, 'real image node replacement');
      check(svg.querySelector('image').getAttribute('transform') === 'scale(-1 1)', 'flipped attack sprite');
      tick(300); check(svg.dataset.motionFrame === '3', 'recovery frame');
      cancel(); cancel(); check(pending.size === 0 && svg.firstChild === idle, 'skip/restart restore idle and cancel callbacks');
      const cancelLoading = playAttackMotion(svg, motion, 600, {clock}); cancelLoading();
      await new Promise(r => setTimeout(r, 25)); check(pending.size === 0 && svg.firstChild === idle, 'cancel during decoding');
      playAttackMotion(svg, motion, 140, {clock, reduced: true});
      check(pending.size === 0 && svg.firstChild === idle, 'reduced motion preserves idle');
      playAttackMotion(svg, {...motion, images: {a:'data:image/png;base64,invalid', b:motion.images.b}}, 600, {clock});
      await new Promise(r => setTimeout(r, 25)); check(pending.size === 0 && svg.firstChild === idle, 'broken assets preserve idle');
      svg.remove();
      return {status: 'passed', fixture: 'synthetic only', timing: true, image_swap: true, flip: true, cancel: true, reduced_motion: true, asset_failure: true};
    }''')
    print(json.dumps(result))
    browser.close()

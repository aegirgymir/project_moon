"""Download a selected native attack clip after network access is enabled.

List: python scripts/fetch-lcb-motion.py --identity 10101
Fetch: append --index N --sinner yisang --skill shot --scale S --output DIR
Use the clip list to select an actual attack; never infer timing from PNG names.
"""
import argparse
import json
from pathlib import Path
from urllib.parse import urlencode
from limbus_archive import fetch, key

BASE = 'https://limbus-archive.com'
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--identity', required=True, choices=[f'{i}01' for i in range(101, 113)])
p.add_argument('--index', type=int)
p.add_argument('--sinner')
p.add_argument('--skill')
p.add_argument('--scale', type=float)
p.add_argument('--output', type=Path)
a = p.parse_args()

def request(route, **query):
    # The public website is a static copy. Resolve the same keys as its service
    # worker rather than calling a non-existent live /api endpoint.
    request_key = key(route, **query)
    return fetch(request_key), BASE + request_key

rows_bytes, list_url = request('/api/owner_clips', id=a.identity)
rows = json.loads(rows_bytes)
if not isinstance(rows, list):
    raise SystemExit('Expected a native clip list; inspect the source response before continuing')
if a.index is None:
    print(json.dumps(list(enumerate(rows)), ensure_ascii=False, indent=2))
    raise SystemExit(0)
if not all([a.sinner, a.skill, a.scale, a.output]) or a.scale <= 0:
    p.error('--index requires --sinner, --skill, positive --scale and --output')
if not 0 <= a.index < len(rows):
    p.error('--index is outside the clip list')
row = rows[a.index]
clip_bytes, clip_url = request('/api/clip', bundle=row['bundle'], clip=row['clip'], go=row['animator_go'], all=1)
clip = json.loads(clip_bytes)
if not clip.get('frames') or not clip.get('sprites'):
    raise SystemExit('Selected clip contains no drawable frames')
# Download fully before making an import directory, and never overwrite exports.
images = {}
image_sources = {}
for i, (key, sprite) in enumerate(clip['sprites'].items()):
    data, url = request('/api/object', bundle=sprite['bundle'], pid=sprite['pid'])
    extension = 'png' if data.startswith(b'\x89PNG\r\n\x1a\n') else 'webp' if data[:4] == b'RIFF' and data[8:12] == b'WEBP' else None
    if not extension:
        raise SystemExit(f'{key}: expected original PNG or WebP response')
    name = f'sprite-{i}.{extension}'
    images[key] = (name, data)
    image_sources[key] = url
a.output.mkdir(parents=True, exist_ok=False)
(a.output / 'clip.json').write_bytes(clip_bytes)
(a.output / 'clips.json').write_bytes(rows_bytes)
for name, data in images.values():
    (a.output / name).write_bytes(data)
manifest = dict(sinner=a.sinner, identity=a.identity, skill=a.skill, scale=a.scale, clipFile='clip.json',
                images={key: item[0] for key, item in images.items()},
                source=dict(clip=clip_url, list=list_url, sprites=image_sources))
(a.output / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print('Downloaded original clip and PNGs:', a.output / 'manifest.json')

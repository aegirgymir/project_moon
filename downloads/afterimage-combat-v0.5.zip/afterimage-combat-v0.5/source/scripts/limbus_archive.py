"""Read the archive's public static web copy using the same lookup as ui/site/sw.js.
No API server runs on the public site; its service worker maps requests to packs.
TLS verification remains enabled. Cached responses are research artifacts only.
"""
import urllib.request,urllib.parse,json,gzip,hashlib
from pathlib import Path
BASE='https://limbus-archive.com/d/'
CACHE=Path(__file__).resolve().parents[1]/'.artifacts/research/limbus-archive';CACHE.mkdir(exist_ok=True, parents=True)
def get(path):
 p=CACHE/hashlib.sha256(path.encode()).hexdigest()
 if not p.exists():
  req=urllib.request.Request(BASE+path,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=45) as r:
   b=r.read()
   if r.headers.get('Content-Encoding')=='gzip':b=gzip.decompress(b)
  p.write_bytes(b)
 return p.read_bytes()
def fnv(s):
 h=0x811c9dc5
 for b in s.encode():h=((h^b)*0x01000193)&0xffffffff
 return h
index=json.loads(get('index.json'))
def key(route,**params):return route+('?'+'&'.join(f'{k}={v}' for k,v in sorted(params.items())) if params else '')
def lookup(k):
 if k in index['inline']:return index['inline'][k]
 path,_,qs=k.partition('?');q=dict(p.split('=',1) for p in qs.split('&') if '=' in p)
 group=path
 if path.startswith('/spine/'):group='/spine/'+path.split('/')[2]
 else:
  for n in ['bundle','id']:
   if n in q:group=f'{path}?{n}={q[n]}';break
 n=index['keys']['split'].get(group)
 if n:group+=f'#{fnv(k)%n}'
 shard=index['keys']['f'][fnv(group)%len(index['keys']['f'])]
 mapping=json.loads(gzip.decompress(get('k/'+shard)))
 if k not in mapping:raise KeyError(k)
 return mapping[k]
def fetch(k):
 rec=lookup(k)
 if isinstance(rec,list):
  pack,off,size,ext=rec;b=get('p/'+pack)[off:off+size]
 elif isinstance(rec,str):ext=rec.split('.')[-1];b=get(rec)
 else:raise ValueError(rec)
 if ext.endswith('gz') or (isinstance(rec,str) and rec.endswith('.gz')):b=gzip.decompress(b)
 return b
def data(route,**params):return json.loads(fetch(key(route,**params)))

// Import a native /api/clip JSON plus its sprite PNG/WebP files from an explicit local
// directory. Timing and transforms come from the clip, never file-name order.
// Usage: node scripts/import-lcb-motion.mjs manifest.json
import { readFile, writeFile, mkdir, access } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { validateMotion } from '../src/attack-motion.js';
import { SINNERS } from '../src/sinners.js';

const root = fileURLToPath(new URL('../', import.meta.url));
if (!process.argv[2]) throw new Error('Provide a motion import manifest; see docs/ATTACK-MOTION.md');
const file = path.resolve(process.argv[2]);
const input = JSON.parse(await readFile(file, 'utf8'));
const index = SINNERS.findIndex(s => s.key === input.sinner);
if (index < 0 || input.identity !== `${101 + index}01` || !SINNERS[index].skills.includes(input.skill)) throw new Error('Unknown sinner, default identity, or prototype skill');
if (!input.source || !input.clipFile || !input.images) throw new Error('Source, clipFile and images are required');
const base = path.dirname(file);
const clipBytes = await readFile(path.resolve(base, input.clipFile));
const clip = JSON.parse(clipBytes);
const images = {};
const originals = {};
for (const id of Object.keys(clip.sprites)) {
  if (typeof input.images[id] !== 'string') throw new Error(`Missing sprite file: ${id}`);
  const bytes = await readFile(path.resolve(base, input.images[id]));
  const extension = bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) ? 'png'
    : bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP' ? 'webp' : null;
  if (!extension) throw new Error('Expected original exported PNG/WebP sprites');
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  images[id] = `${sha256}.${extension}`; originals[images[id]] = bytes;
}
validateMotion({ clip, images, scale: input.scale });
const folderName = `${input.identity}-${input.skill}`;
const folder = path.join(root, 'src/assets/lcb-motion', folderName);
try { await access(folder); throw new Error('This clip already exists; preserve it or remove it explicitly before replacing it'); }
catch (error) { if (error.code !== 'ENOENT') throw error; }
await mkdir(folder, { recursive: true });
for (const [name, bytes] of Object.entries(originals)) await writeFile(path.join(folder, name), bytes);
await writeFile(path.join(folder, 'clip.json'), clipBytes);
await writeFile(path.join(folder, 'source.json'), JSON.stringify({ ...input, images, clipSHA256: createHash('sha256').update(clipBytes).digest('hex') }, null, 2) + '\n');
const assetURLs = Object.entries(images).map(([id, name]) => `${JSON.stringify(id)}: new URL(${JSON.stringify(`./${name}`)}, import.meta.url).href`).join(',\n');
await writeFile(path.join(folder, 'motion.js'), `// Original clip and PNGs; provenance in source.json.\nconst motion = ${JSON.stringify({ clip, scale: input.scale })};\nmotion.images = {${assetURLs}};\nexport default motion;\n`);
console.log(`Imported local clip ${folderName}; register explicitly or use sync-lcb-motions.py for the canonical base-identity registry.`);

import { build } from 'vite';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = fileURLToPath(new URL('../', import.meta.url));
const packageInfo = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
const version = packageInfo.version.replace(/\.0$/, '');
const releaseName = `afterimage-combat-v${version}`;
const output = path.join(root, '.artifacts', 'downloads', `v${version}`);
await mkdir(output, { recursive: true });

// Bundle as a classic script so the downloaded HTML also works via file://.
// Keep this separate from Vite's normal production build.
const result = await build({
  root,
  configFile: false,
  logLevel: 'warn',
  // Every asset is embedded in library mode. Use a valid inert base for
  // URL(dataURI, import.meta.url), including offline about:blank rendering.
  plugins: [{ name: 'standalone-asset-base', resolveImportMeta(property) {
    return property === 'url' ? JSON.stringify('file:///game.html') : null;
  } }],
  build: {
    write: false,
    minify: true,
    cssCodeSplit: false,
    lib: { entry: path.join(root, 'src', 'main.js'), name: 'AfterimageGame', formats: ['iife'] },
  },
});
const files = (Array.isArray(result) ? result : [result]).flatMap(r => r.output);
const js = files.filter(f => f.type === 'chunk').map(f => f.code).join('\n');
const css = files.filter(f => f.type === 'asset' && f.fileName.endsWith('.css')).map(f => String(f.source)).join('\n');
if (!js || !css) throw new Error('Standalone bundle must contain both JavaScript and CSS.');
const favicon = await readFile(path.join(root, 'public', 'favicon.svg'), 'utf8');
let html = await readFile(path.join(root, 'index.html'), 'utf8');
html = html.replace('href="/favicon.svg"', `href="data:image/svg+xml,${encodeURIComponent(favicon)}"`);
html = html.replace('</head>', `<style>${css}</style>\n  </head>`);
html = html.replace('<script type="module" src="/src/main.js"></script>', `<script>${js.replace(/<\/script/gi, '<\\/script')}</script>`);
await writeFile(path.join(output, 'game.html'), html, 'utf8');
await writeFile(path.join(output, `${releaseName}.html`), html, 'utf8');

const instructions = `골목의 잔향 — 수감자 전투 프로토타입 v${version}

1. ZIP을 먼저 압축 해제하세요.
2. play 폴더의 game.html을 Chrome, Edge, Firefox 또는 Safari로 여세요.
3. 별도 설치나 인터넷 연결 없이 플레이할 수 있습니다.

기술 카드 → 빛나는 대상 → 금색 실행 버튼
1~4: 기술 / 좌우 방향키: 대상 / Enter: 실행 / M: 이동 / G: 방어 / W: 대기

브라우저 새로고침 시 전투가 처음부터 시작됩니다.
진행 상태 저장과 탐험·사무소 운영은 아직 구현하지 않았습니다.

source/에는 수정 가능한 소스와 개발용 README가 있습니다.
source/docs/RESEARCH.md: 세계관·출처·검증 한계
source/docs/COMBAT.md: 실제 전투 규칙

수감자 편성 메뉴에서 12명 중 4명을 골라 새 전투를 시작할 수 있습니다.
각 수감자는 고유 기술 4개를 사용합니다. LCB 기본 인격의 인게임 대기 스프라이트와 행동 클로즈업이 적용됩니다.
공격·지원마다 동작과 카메라 클로즈업이 재생됩니다.
Space 또는 연출 건너뛰기로 넘기고, 상단 카메라 버튼으로 끌 수 있습니다.

Project Moon 세계관을 바탕으로 한 비공식 팬 프로토타입입니다.
수감자의 이름과 기본 인격 대기 스프라이트는 림버스 컴퍼니를 따릅니다.
스프라이트 권리: Project Moon. 공개 커뮤니티 추출본의 WebP를 변경 없이 포함했습니다.
원작의 공격 애니메이션·골격·전체 프레임은 포함하지 않으며, 돌진·피격·카메라는 자체 연출입니다.
정확한 출처와 파일별 SHA-256: source/docs/ASSETS.md 및 source/src/assets/lcb/manifest.json.
능력치·전술 역할·기술은 각색이며 원작의 정식 기술을 재현한 것이 아닙니다.
`;
await writeFile(path.join(output, 'START-HERE.txt'), instructions, 'utf8');

// Use Python's standard library for portable ZIP generation; do not ship caches,
// Git metadata, installed dependencies, or environment-specific credentials.
execFileSync('python', ['-c', `
import pathlib, sys, zipfile
root, output = map(pathlib.Path, sys.argv[1:3])
release_name = sys.argv[3]
root_files = {'.gitignore', 'AGENTS.md', 'README.md', 'index.html', 'package.json', 'package-lock.json'}
source_dirs = {'src', 'public', 'docs', 'scripts', 'tests'}
with zipfile.ZipFile(output / (release_name + '.zip'), 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(output / 'game.html', release_name + '/play/game.html')
    archive.write(output / 'START-HERE.txt', release_name + '/START-HERE.txt')
    candidates = [root / name for name in root_files]
    for name in source_dirs:
        candidates.extend((root / name).rglob('*'))
    for file in sorted(candidates):
        rel = file.relative_to(root)
        if '__pycache__' in rel.parts or not file.is_file() or file.is_symlink():
            continue
        archive.write(file, release_name + '/source/' + rel.as_posix())
with zipfile.ZipFile(output / (release_name + '.zip')) as archive:
    error = archive.testzip()
    if error:
        raise RuntimeError('ZIP integrity check failed: ' + error)
    print('ZIP integrity: passed (' + str(len(archive.namelist())) + ' files)')
`, root, output, releaseName], { stdio: 'inherit' });
console.log(`Standalone game and ZIP written to ${output}`);

# LCB 기본 인격 스프라이트 — v0.4

사용자가 기본 인격의 실제 인게임 외형 사용을 요청하여, v0.3의 독자 SVG 팬 모델을 12명의 **실제 인게임 대기 스프라이트**로 교체했다. 자산의 권리는 Project Moon에 있다. 공식 배포본이나 공식 승인 작품으로 표시하지 않는다.

## 확보한 자료

- 보관본: [eldritchtools/limbus-assets](https://github.com/eldritchtools/limbus-assets)
- 고정 커밋: [`4b6cb07b3a2608a2f4c59dfe08ce1a41bc16d7c0`](https://github.com/eldritchtools/limbus-assets/tree/4b6cb07b3a2608a2f4c59dfe08ce1a41bc16d7c0/assets/identities)
- 경로: `assets/identities/<identity>_sprite_idle.webp`
- README의 권리 표시: “All rights reserved to Project Moon.” 이는 자산에 대한 공개 라이선스나 별도의 사용 허락을 의미하지 않는다.
- 확인일: 2026-10-18. 위 저장소의 커밋과 실제 파일을 읽었다. 12명 접촉 시트 및 실제 게임 화면에서 외형을 육안 확인했다.

| 수감자 | 기본 인격 ID | 포함 파일 |
|---|---|---|
| 이상 | 10101 | `10101_sprite_idle.webp` |
| 파우스트 | 10201 | `10201_sprite_idle.webp` |
| 돈키호테 | 10301 | `10301_sprite_idle.webp` |
| 료슈 | 10401 | `10401_sprite_idle.webp` |
| 뫼르소 | 10501 | `10501_sprite_idle.webp` |
| 홍루 | 10601 | `10601_sprite_idle.webp` |
| 히스클리프 | 10701 | `10701_sprite_idle.webp` |
| 이스마엘 | 10801 | `10801_sprite_idle.webp` |
| 로쟈 | 10901 | `10901_sprite_idle.webp` |
| 싱클레어 | 11001 | `11001_sprite_idle.webp` |
| 오티스 | 11101 | `11101_sprite_idle.webp` |
| 그레고르 | 11201 | `11201_sprite_idle.webp` |

에셋 ID는 인격 데이터의 ID다. 싱클레어·오티스·그레고르의 표시 수감자 번호 11·12·13과 에셋 순서 110·111·112를 혼동하지 않는다.

## 적용 범위와 한계

보관본의 WebP 파일을 **다시 그리거나 재인코딩하지 않고** 그대로 `src/assets/lcb/`에 포함했다. 파일별 SHA-256·크기·해상도·투명 영역 경계는 `src/assets/lcb/manifest.json`에 기록했다. 이는 보관본과의 바이트 일치를 확인하는 것이며, 게임 설치본의 압축 텍스처 바이트와 같다는 주장은 아니다. 보관본은 커뮤니티 추출·변환본이고 공식 제공 API가 아니다.

전장·초상화·편성 카드·클로즈업에서 같은 파일을 사용한다. 원래 비율을 유지한 균일 확대/축소와 위치 이동으로 머리·발을 맞추고 초상화 영역만 화면에서 잘라 보여준다. 원본 이미지에 색칠하거나 기존 팬 모델의 가짜 관절을 적용하지 않는다.

현재 확보한 파일은 **정지 대기 자세 1장씩**이다. 원작의 공격·피격·가드·이동 전체 프레임, AnimationClip, Spine 골격 또는 Unity 모델 데이터는 확보하지 않았다. 돌진·후퇴·반동·타격 궤적·카메라 확대는 프로토타입 자체 연출이다. 따라서 원작의 전체 애니메이션까지 그대로 이식했다고 설명하지 않는다.

추가 조사한 [Schirke/limbus-archive](https://github.com/Schirke/limbus-archive)는 로컬 게임 자산의 애니메이션 클립·프레임을 읽고 내보내는 도구이며, 원작 자산은 저장소에 포함하지 않는다고 명시한다. 해당 소스의 `limbusdm/frames.py`, `site.py`, `webcopy.py`는 읽었으나 웹 보관 사이트 `limbus-archive.com`과 공식 사이트는 이 환경의 네트워크 제한으로 읽지 못했다. 실제 설치본이나 독립된 공식 이미지 자료와의 교차검증은 완료하지 않았다.

## 오프라인 배포

Vite의 일반 빌드는 WebP 파일을 별도 자산으로 출력한다. `npm run package`의 독립 실행 빌드는 12장을 모두 HTML 안의 WebP data URI로 포함한다. 인터넷 없이도 편성창의 12장과 전장·클로즈업이 표시되어야 한다. 원본 보관본 URL에 런타임 요청을 보내지 않는다. ZIP에는 실행 HTML과 이미지·출처 문서를 포함한 수정 가능한 소스가 함께 들어간다.

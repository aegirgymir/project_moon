# 골목의 잔향 v0.4

Project Moon의 도시를 배경으로, 다키스트 던전 **1편**의 위치 기반 전투에서 착안한 한국어 팬 프로토타입입니다. 《림버스 컴퍼니》 수감자 12명 중 4명을 골라 조직원과 싸우는 한 판 전투를 구현했습니다.

실제 설정 조사와 검증 한계는 [조사 기록](docs/RESEARCH.md), 독자 전투 규칙과 구현 범위는 [전투 명세](docs/COMBAT.md)에 있습니다. 수감자 이름과 LCB 기본 인격의 실제 인게임 대기 스프라이트를 사용하며, 기술·역할·능력치·장소·행동 연출은 각색입니다. 출처와 사용 범위는 [이미지 출처](docs/ASSETS.md)에 기록했습니다. 공식 작품이 아닙니다.

## v0.4 변경 사항

- 수감자 12명의 팬 모델을 **LCB 기본 인격의 실제 인게임 대기 스프라이트**로 교체했습니다.
- 전장·초상화·편성 카드·클로즈업에 적용하고, 파일마다 다른 몸 크기와 발 위치를 맞췄습니다.
- 보관본 WebP를 수정 없이 포함하고 출처·고정 커밋·파일별 SHA-256을 기록했습니다.
- 원작의 전체 공격 애니메이션은 포함하지 않습니다. 기존 돌진·피격·카메라 연출과 연결했습니다.
- 고유 기술 4개와 대사 제거를 유지하며, 이전 버전 다운로드 파일을 보존합니다.
- 12개 이미지를 단일 HTML에 내장해 인터넷 없이 실행합니다.

## 설치 없이 플레이

다운로드한 `afterimage-combat-v0.4.zip`을 압축 해제하고 `play/game.html`을 브라우저로 열면 됩니다. `game.html` 하나만 받아도 실행할 수 있습니다. 서버·Node.js·인터넷 연결이 필요하지 않습니다.

개발 소스에서 이 배포 파일을 다시 만들려면 의존성 설치 후 `npm run package`를 실행하세요. `.artifacts/downloads/v0.4/`에 단일 HTML과 소스·문서 포함 ZIP이 생성됩니다. 패키징 명령에는 Python도 필요합니다.

## 실행

Node.js 24 권장. Vite 7의 요구 조건인 Node 20.19+ 또는 22.12+를 충족해야 합니다.

```sh
cd /workspace/project_moon
npm ci --cache /workspace/.npm-cache
npm run dev -- --port 5173 --strictPort
```

일반 로컬 환경에서는 저장소 디렉터리에서 `npm ci` 후 `npm run dev`를 실행하면 됩니다. API 키, 계정, 데이터베이스는 필요하지 않습니다. 게임 실행 중 외부 사이트나 이미지 서버에 접속하지 않습니다.

## 플레이

기술 카드를 누르고 빛나는 대상 중 하나를 선택한 뒤 금색 버튼으로 실행하세요. 적은 자동으로 행동합니다. 화면 위 ‘전투 지침’에서 위치·출혈·스트레스·죽음의 문턱을 확인할 수 있습니다.

`1`~`4` 기술 / `←`·`→` 대상 / `Enter` 실행 / `M` 이동 / `G` 방어 / `W` 대기.

## 검증

```sh
npm test
npm run build
```

실제 브라우저 검증은 개발 서버 실행 후 다음 명령을 사용합니다. Python `playwright` 패키지와 Chromium이 별도로 필요하며, 이 클라우드 환경에는 둘 다 준비되어 있습니다.

```sh
python scripts/browser_smoke.py
```

`CHROMIUM_PATH`, `GAME_URL`로 브라우저 경로와 테스트 서버 주소를 바꿀 수 있습니다. `GAME_HTML_PATH=.artifacts/downloads/v0.4/game.html python scripts/browser_smoke.py`는 네트워크를 끄고 단일 HTML을 직접 렌더링해 검증합니다. 클라우드 Chromium은 file:// 탐색을 제한하므로 이 검증은 실제 파일 URL 탐색과 구분합니다. 스크린샷은 Git에서 제외되는 `.artifacts/`에 생성됩니다.

자동 테스트는 전투 규칙·12명 편성·고유 스킬 4개와 스프라이트 파일의 해시·인격 연결을 검증합니다. 실제 Chromium에서 12장 이미지의 디코딩, 전투 클로즈업, 반응형 화면과 모션 감소를 확인합니다. 네트워크를 끈 단일 HTML 검사도 포함합니다. 공식 설치본과의 직접 교차검증 한계는 [이미지 출처](docs/ASSETS.md)에 기록했습니다.

## 파일

| 경로 | 역할 |
|---|---|
| `src/combat.js` | 재현 가능한 난수와 전투 규칙 |
| `src/main.js` | 인터랙션과 한국어 화면 |
| `src/art.js`, `src/sinner-art.js` | 실제 수감자 스프라이트 표시·SVG 적·배경·아이콘 |
| `src/assets/lcb/`, `src/lcb-sprites.js` | 기본 인격 WebP 12장·출처·표시 좌표 |
| `src/sinners.js` | 12명 정보와 편성 검증 |
| `src/cinematic.js`, `src/cinematic.css` | 동작과 카메라 연출 |
| `src/style.css` | 반응형 전투 UI |
| `docs/RESEARCH.md` | 출처·세계관 용어·교차검증과 보류 사항 |
| `docs/COMBAT.md` | 실제 규칙·단축키·미구현 범위 |

v0.4는 Project Moon에 권리가 있는 기본 인격 스프라이트 12장을 포함합니다. 자세한 확보 범위와 출처는 `docs/ASSETS.md`를 확인하세요. 원작 음원·음성·전체 애니메이션은 포함하지 않습니다. 의존성 설치 결과는 잠금 파일로 고정했습니다.

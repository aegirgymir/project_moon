// Prototype effects drawn as vectors; all timing comes from the shot plan.
const forms={
 slash:'<path class="fx-arc" d="M310 85Q540 130 385 244Q510 148 310 85Z"/>',
 cleave:'<path class="fx-arc" d="M360 48Q550 160 342 254Q490 152 360 48Z"/><path class="fx-line" d="m385 94 80 125"/>',
 sweep:'<path class="fx-arc" d="M235 190Q460 60 550 185Q458 111 235 204Z"/>',
 pierce:'<path d="m202 163 285-13-69 22-216 4Z"/><path class="fx-line" d="M260 155h259m-50-25 29 26-31 28"/>',
 knives:'<path d="m255 124 204 26-32 8-174-29Zm-30 37 263-1-49 11-212-5Zm18 40 213-27-33 17-179 16Z"/>',
 smash:'<path class="fx-line" d="m440 101-8 33 30-19-13 31 42-5-32 22 26 29-37-13 2 37-21-29-26 27 12-38-37 4 33-21-26-28 37 15Z"/><circle class="fx-ring" cx="435" cy="163" r="47"/>',
 push:'<path class="fx-line" d="m342 115 39 49-39 47m55-96 39 49-39 47m55-96 39 49-39 47"/><circle class="fx-ring" cx="435" cy="163" r="55"/>',
 wave:'<path class="fx-line" d="M275 190q40-100 90-28t90-17 78 15M300 214q45-64 87-14t99-6"/>',
 bleed:'<path class="fx-line" d="m394 111 82 104m-64-117 40 131m-75-65 110-10"/><path d="m402 134-6-17-6 17a6 6 0 0 0 12 0m71 65-7-22-7 22a7 7 0 0 0 14 0m-42 34-5-15-5 15a5 5 0 0 0 10 0"/>',
 fracture:'<path class="fx-line" d="m435 95 48 22-7 63-41 51-40-51-8-63Zm0 0-12 56 24 10-22 70m22-70 30 19"/>',
 claw:'<path class="fx-line" d="m394 109 64 108m-44-116 62 105m-80-79 44 94"/><path d="m468 137-8 22 23-10Z"/>',
 mark:'<circle class="fx-ring" cx="435" cy="163" r="54"/><circle class="fx-ring" cx="435" cy="163" r="30"/><path class="fx-line" d="M435 83v48m0 64v48m-80-80h48m64 0h48"/>',
 guard:'<path class="fx-line" d="m435 87 58 25-9 76-49 49-48-49-10-76Z"/><path class="fx-line" d="M435 108v97m-28-57h56"/>',
 heal:'<circle class="fx-ring" cx="435" cy="163" r="61"/><path class="fx-line" d="M435 126v74m-37-37h74m-71-71 11 11m47 120 11 11m-71 0 11-11m49-120 11-11"/><path d="M428 141h14v15h15v14h-15v15h-14v-15h-15v-14h15Z"/>',
 calm:'<circle class="fx-ring" cx="435" cy="163" r="50"/><circle class="fx-ring" cx="435" cy="163" r="69"/><path class="fx-line" d="M381 164q28-28 54 0t54 0m-87 29q33-25 66 0"/>',
 move:'<path class="fx-line" d="M369 142h127m-24-24 24 24-24 24m29 25H374m24-24-24 24 24 24"/>',
 dread:'<path class="fx-line" d="M365 163q70-80 140 0-70 80-140 0Z"/><circle class="fx-ring" cx="435" cy="163" r="24"/><path class="fx-line" d="m401 113-14-27m82 27 14-27m-48 128v31"/>',
 shot:'<path class="fx-line" d="M230 160h235m-35-16 43 16-43 16"/><circle class="fx-ring" cx="435" cy="163" r="28"/>',
 evade:'<path class="fx-line" stroke-dasharray="9 12" d="M275 161h160"/><path class="fx-line" d="m473 119-16 40 21-8-20 47"/>',
};
export function effectMarkup(shot,plan){
 const effect=plan.effect;
 const color=effect==='bleed'?'#df665d':effect==='heal'?'#a5df9f':effect==='calm'?'#94cddc':effect==='guard'?'#91badf':effect==='dread'?'#b493d4':shot.actor.color||'#d5b57b';
 const times=shot.reduced?[]:plan.cues;
 const pulses=times.map((cue,i)=>`<g class="concept-pulse fx-${effect}" data-fx-cue="${cue.frame??'utility'}" style="--fx-delay:${cue.time}ms;--fx-life:${300*plan.factor}ms">${forms[effect]||forms.slash}</g>`).join('');
 const extra=!shot.reduced && effect==='fracture'?`<g class="concept-pulse fx-mark" style="--fx-delay:${plan.resultAt}ms;--fx-life:${350*plan.factor}ms">${forms.mark}</g>`:'';
 return `<svg class="concept-effects ${shot.self?'fx-self':''} ${shot.actor.side==='enemy'&&!shot.friendly?'fx-enemy':''}" data-skill-fx="${effect}" viewBox="0 0 600 300" aria-hidden="true" style="--fx-color:${color}">${shot.actor.side==='enemy'&&!shot.friendly?'<g transform="translate(870 0) scale(-1 1)">':''}${pulses}${extra}${shot.actor.side==='enemy'&&!shot.friendly?'</g>':''}</svg>`;
}

import {paintMotion} from './attack-motion.js';
import {timelineFrameAt} from './skill-presentation.js';

// A single RAF drives sprite selection, camera, VFX, defender pose, audio cues
// and completion. No separate frame clocks or duration timeout can drift apart.
export function playShotPresentation(root, shot, motions, plan, {onCue=()=>{},onResult=()=>{},onComplete=()=>{},clock=window}={}) {
  const actor=root.querySelector('.duel-attacker .original-sprite');
  const target=root.querySelector('.duel-defender .original-sprite');
  const camera=root.querySelector('.duel-camera');
  const defender=root.querySelector('.duel-defender .duel-sprite');
  const originals=[actor,target].filter(Boolean).map(svg=>[svg,[...svg.childNodes]]);
  const feedback=root.getAnimations({subtree:true});
  feedback.forEach(a=>{a.pause();a.currentTime=0;});
  let cancelled=false,handle=null,start=null,lastFrame=null,nextCue=0,result=false;
  const paint=elapsed=>{
    root.dataset.elapsed=String(Math.round(elapsed));
    feedback.forEach(a=>{a.currentTime=elapsed;});
    if (!shot.reduced && motions.actor && actor) {
      const frame=timelineFrameAt(plan,elapsed)||motions.actor.clip.frames[0];
      if(frame!==lastFrame){paintMotion(actor,motions.actor,frame);lastFrame=frame;actor.dataset.originalMotion='true';}
    }
    while(nextCue<plan.cues.length && elapsed>=plan.cues[nextCue].time){
      root.dataset.impactCount=String(++nextCue);
      if(!shot.reduced && target && motions.target) {paintMotion(target,motions.target,motions.target.clip.frames[0]);target.dataset.originalMotion='true';}
      onCue(nextCue);
    }
    if(!result && elapsed>=plan.resultAt){result=true;root.dataset.resultVisible='true';onResult();}
    if(shot.reduced){camera.style.transform='none';return;}
    const recent=plan.cues[nextCue-1],age=recent?elapsed-recent.time:Infinity;
    const pulse=Math.max(0,1-age/(240*plan.factor));
    if(target && motions.target && age>220*plan.factor && target.dataset.originalMotion){
      const saved=originals.find(([svg])=>svg===target);target.replaceChildren(...saved[1]);delete target.dataset.originalMotion;delete target.dataset.motionFrame;
    }
    const intro=Math.min(1,elapsed/(180*plan.factor));
    const physical=['damage','critical'].includes(shot.kind);
    const shake=physical?Math.sin(age/18)*pulse*(shot.kind==='critical'?4:2):0;
    camera.style.transform=`translate(${Number.isFinite(shake)?shake:0}px,0) scale(${1+.055*intro+(physical ? .04 : .018)*pulse})`;
    if(defender && !shot.friendly && ['hurt','dodge'].includes(shot.reaction)){
      const direction=defender.parentElement.classList.contains('at-left')?-1:1;
      const distance=shot.kind==='miss'?32:14;
      defender.style.transform=`translateX(${direction*distance*pulse}px)`;
      defender.style.filter=shot.kind==='miss'?`opacity(${1-.25*pulse})`:`brightness(${1+.5*pulse})`;
    }
  };
  paint(0);
  const tick=time=>{
    if(cancelled || !root.isConnected)return;
    start??=time;const elapsed=Math.min(plan.duration,time-start);paint(elapsed);
    if(elapsed>=plan.duration){onComplete();return;}
    handle=clock.requestAnimationFrame(tick);
  };
  handle=clock.requestAnimationFrame(tick);
  return ()=>{if(cancelled)return;cancelled=true;clock.cancelAnimationFrame(handle);feedback.forEach(a=>a.cancel());for(const [svg,nodes] of originals){svg.replaceChildren(...nodes);delete svg.dataset.originalMotion;delete svg.dataset.motionFrame;}};
}

import { LCB_NATIVE_MOTIONS } from './lcb-native-motions.js';
import { LCB_SPRITES } from './lcb-sprites.js';
import { skillVisual, ATTACK_CUES } from './skill-presentation.js';

export function motionsForShot(shot) {
  if (!shot || shot.reduced) return {actor:null,target:null};
  const id=LCB_SPRITES[shot.actor.key]?.identity, visual=skillVisual(shot);
  const targetID=LCB_SPRITES[shot.target.key]?.identity;
  const reaction=!shot.friendly && targetID && ['hurt','dodge'].includes(shot.reaction)
    ? LCB_NATIVE_MOTIONS[`${targetID}-${shot.reaction==='dodge'?'evade':'damaged'}`] : null;
  return {actor:id && visual.clip?LCB_NATIVE_MOTIONS[`${id}-${visual.clip}`]:null,target:reaction};
}
// Kept for source inspection tools; gameplay uses the reviewed, retimed plan.
export function motionImpact(motion) {
  const keys=['yisang','faust','don','ryoshu','meursault','honglu','heathcliff','ishmael','rodion','sinclair','outis','gregor'];
  const key=keys[Number(motion.identity.slice(0,3))-101];
  const cue=ATTACK_CUES[key]?.[motion.kind]?.at(-1);
  return (cue??0)/(motion.clip.frames.at(-1).f+motion.clip.frames.at(-1).d);
}

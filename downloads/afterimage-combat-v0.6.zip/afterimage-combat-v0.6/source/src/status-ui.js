import {icon} from './art.js';
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function unitStatuses(u,state){
 if(!u || u.dead)return [];
 const result=[],add=(key,label,type,symbol,summary,detail)=>result.push({key,label,type,symbol,summary,detail});
 if(u.bleed.length){
  const amount=u.bleed.reduce((n,b)=>n+b.amount,0);
  add('bleed',`출혈 ${amount}`,'debuff','drop',`자기 차례 시작에 피해 ${amount}`,u.bleed.map((b,i)=>`${u.bleed.length>1?`${i+1}중첩: `:''}${b.amount} 피해 × 남은 ${b.turns}회`).join(' · ')+'\n중첩별 남은 횟수가 다릅니다. 보호·피해 감소를 무시하며, 출혈을 제거하는 치료로 해제합니다.');
 }
 if(u.marked)add('mark',`표식 ${u.marked}`,'debuff','crosshair','받는 공격 피해 +40%',`앞으로 명중하는 공격 ${u.marked}회에 적용됩니다. 빗나간 공격은 횟수를 소모하지 않습니다.`);
 const guardian=state.units[u.guardedBy];
 if(guardian&&!guardian.dead){
  const self=guardian.id===u.id;
  add('guard',self?'방어':'보호','buff','shield',self?`직접 피해 ${Math.round(u.protection*100)}% 감소`:`보호자 · ${guardian.name}`,`${guardian.name}의 다음 차례가 시작될 때 해제됩니다. ${self?'출혈에는 적용되지 않습니다.':'보호자가 직접 피해를 대신 받고 피해 감소가 적용됩니다. 출혈에는 적용되지 않습니다.'}`);
 }
 const protectedAllies=Object.values(state.units).filter(x=>!x.dead&&x.id!==u.id&&x.guardedBy===u.id);
 if(protectedAllies.length)add('cover','엄호 중','buff','people',protectedAllies.map(x=>x.name).join(' · ')+' 보호',`${u.name}의 다음 차례 시작까지 대상의 직접 피해를 대신 받습니다.`);
 if(u.deathsDoor)add('door','빈사','danger','skull','죽음의 문턱', '추가 피해를 받을 때마다 33% 확률로 사망합니다. 출혈도 판정합니다. 체력을 1 이상 치료하면 벗어납니다.');
 if(u.stress>=100)add('pressure','동요','debuff','eye','명중 −10 · 속도 −2',`현재 스트레스 ${u.stress}/200. 100 미만으로 회복하면 해제됩니다. 속도는 다음 라운드 순서 계산에 반영됩니다.`);
 return result;
}
export function statusMarkup(u,state,{focusable=false,compact=false}={}){
 return unitStatuses(u,state).map(s=>`<span class="status-chip ${s.type}" data-status="${s.key}" data-status-unit="${u.id}" ${focusable?'tabindex="0"':''} role="img" aria-label="${esc(s.label+' · '+s.summary)}">${icon(s.symbol,12)}<span>${esc(compact?(s.key==='bleed'?u.bleed.reduce((n,b)=>n+b.amount,0):s.key==='mark'?u.marked:''):s.label)}</span></span>`).join('');
}
export function installStatusTooltips(app,getState){
 const tooltip=document.createElement('div');tooltip.id='status-tooltip';tooltip.className='status-tooltip';tooltip.role='tooltip';tooltip.hidden=true;document.body.append(tooltip);
 let anchor=null,pinned=false;
 const hide=()=>{anchor?.removeAttribute('aria-describedby');anchor=null;pinned=false;tooltip.hidden=true;};
 const show=el=>{
  const state=getState(),u=state.units[el.dataset.statusUnit],s=unitStatuses(u,state).find(x=>x.key===el.dataset.status);
  if(!s){hide();return;}
  if(anchor!==el)hide();anchor=el;el.setAttribute('aria-describedby',tooltip.id);
  tooltip.innerHTML=`<strong>${esc(u.name)} · ${esc(s.label)}</strong><b class="${s.type}">${esc(s.summary)}</b><p>${esc(s.detail).replaceAll('\n','<br>')}</p>`;
  tooltip.hidden=false;
  const rect=el.getBoundingClientRect(),box=tooltip.getBoundingClientRect();
  const x=Math.max(8,Math.min(innerWidth-box.width-8,rect.left+rect.width/2-box.width/2));
  const above=rect.top-box.height-9;const y=above>=8?above:Math.min(innerHeight-box.height-8,rect.bottom+9);
  tooltip.style.left=`${x}px`;tooltip.style.top=`${Math.max(8,y)}px`;
 };
 app.addEventListener('pointerover',e=>{const el=e.target.closest('[data-status]');if(el&&e.pointerType==='mouse')show(el);});
 app.addEventListener('pointerout',e=>{if(anchor&&!pinned&&!anchor.contains(e.relatedTarget))hide();});
 app.addEventListener('focusin',e=>{const el=e.target.closest('[data-status]');if(el)show(el);});
 app.addEventListener('focusout',hide);
 app.addEventListener('keydown',e=>{const el=e.target.closest('[data-status]');if(el&&['Enter',' '].includes(e.key)){e.preventDefault();e.stopPropagation();show(el);pinned=true;}});
 app.addEventListener('click',e=>{const el=e.target.closest('[data-status]');if(el){e.preventDefault();e.stopImmediatePropagation();if(anchor===el&&pinned)hide();else {show(el);pinned=true;}}},true);
 document.addEventListener('keydown',e=>{if(e.key==='Escape')hide();});
 document.addEventListener('pointerdown',e=>{if(!e.target.closest('[data-status]'))hide();},true);
 window.addEventListener('resize',hide);window.addEventListener('scroll',hide,true);
 return {hide};
}

// Reviewed against the archived frame contact sheets. These are this game's
// presentation cues, not original combat events. Source clip JSON stays intact.
export const ATTACK_CUES = {
  yisang: { s1:[20], s2:[20,50], s3:[20,50,76,84] },
  faust: { s1:[20], s2:[19,92], s3:[35,132,266] },
  don: { s1:[20], s2:[25], s3:[23,72] },
  ryoshu: { s1:[20], s2:[20,50], s3:[3,9,15,24,50] },
  meursault: { s1:[20], s2:[40], s3:[12,28,48,63,83,97,146] },
  honglu: { s1:[20], s2:[20,44], s3:[17,84,119] },
  heathcliff: { s1:[20], s2:[20], s3:[10,20,32,42,85] },
  ishmael: { s1:[20], s2:[10], s3:[47] },
  rodion: { s1:[8], s2:[23,55,98], s3:[16,30,95] },
  sinclair: { s1:[15], s2:[18,46,81], s3:[24,54,92] },
  outis: { s1:[20,50,80], s2:[20,50,80], s3:[39] },
  gregor: { s1:[22], s2:[25,45], s3:[16,46] },
};
const move = (clip, effect, from = 0, to = Infinity) => ({ clip, effect, from, to });
// Choose by character/skill concept, never serial, role index, or RNG.
export const SKILL_MOTION_MAP = {
  yisang:{shot:move('s2','knives',26),knife:move('s1','slash'),bleed_strike:move('s3','bleed')},
  faust:{knife:move('s1','cleave')},
  don:{cleave:move('s1','pierce'),push:move('s2','push'),reach_strike:move('s3','pierce',55)},
  ryoshu:{cut:move('s1','bleed'),pierce:move('s2','slash'),expose:move('s3','fracture')},
  meursault:{cleave:move('s1','smash'),push:move('s2','push'),reach_strike:move('s3','smash',0,33)},
  honglu:{shot:move('s1','sweep'),knife:move('s2','slash'),bleed_strike:move('s3','bleed')},
  heathcliff:{cleave:move('s2','smash'),push:move('s3','push'),reach_strike:move('s1','smash')},
  ishmael:{cleave:move('s1','smash'),push:move('s2','wave'),reach_strike:move('s3','smash')},
  rodion:{cut:move('s1','bleed'),pierce:move('s3','sweep',0,35),expose:move('s2','fracture')},
  sinclair:{cut:move('s1','bleed'),pierce:move('s3','pierce',0,30),expose:move('s2','fracture')},
  outis:{shot:move('s3','pierce'),knife:move('s1','slash'),bleed_strike:move('s2','bleed')},
  gregor:{knife:move('s1','claw')},
};

export function skillVisual(shot) {
  const named = SKILL_MOTION_MAP[shot.actor.key]?.[shot.skill];
  if (named) return named;
  return { clip: shot.skill === 'move' ? 'move' : ['cover','brace'].includes(shot.skill) ? 'guard' : null,
    effect: ({mend:'heal',stabilize:'heal',solace:'calm',steady:'calm',wait:'calm',cover:'guard',brace:'guard',mark:'mark',move:'move',dread:'dread',hit:'smash',hook:'bleed',harass:'shot'})[shot.skill] || 'slash', from:0,to:Infinity };
}

export function buildShotTimeline(shot, motion, {fast=false}={}) {
  const visual = skillVisual(shot), factor=fast ? .5 : 1;
  if (shot.reduced) return {duration:140,segments:[],cues:[],resultAt:0,visual,effect:visual.effect,factor:1};
  const segments=[];let end=120;
  if (motion && /^s\d$/.test(motion.kind)) {
    const frames=motion.clip.frames.filter(f=>f.f>=visual.from && f.f<visual.to);
    for (const [i,frame] of frames.entries()) {
      const hold=Math.round(i===0?240:i===frames.length-1?150:Math.min(170,Math.max(65,frame.d/motion.clip.fps*1000)));
      segments.push({frame,start:end,end:end+hold});end+=hold;
    }
  }
  const reviewed=ATTACK_CUES[shot.actor.key]?.[visual.clip] || [];
  const cues=segments.filter(s=>reviewed.includes(s.frame.f)).map(s=>({time:s.start,frame:s.frame.f}));
  if (!cues.length) cues.push({time:segments.length?segments[Math.min(1,segments.length-1)].start:(["damage","critical","miss"].includes(shot.kind)?387:440),frame:segments[1]?.frame.f ?? segments[0]?.frame.f ?? null});
  const resultAt=cues.at(-1).time;
  const duration=Math.max(900,end+160,resultAt+420);
  return {duration:duration*factor,segments:segments.map(s=>({...s,start:s.start*factor,end:s.end*factor})),cues:cues.map(c=>({...c,time:c.time*factor})),resultAt:resultAt*factor,visual,effect:shot.kind==='miss'?'evade':visual.effect,factor};
}

export function timelineFrameAt(plan, elapsed) {
  return plan.segments.findLast(s=>s.start<=elapsed)?.frame || plan.segments[0]?.frame || null;
}

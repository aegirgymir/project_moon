// Names and sinner numbers belong to Limbus Company. These tactical roles,
// skill labels and stats are original adaptations for this game.
const guard = { role: '전열 · 돌파', hp: 38, speed: 3, dodge: 3, skills: ['cleave', 'cover', 'push', 'reach_strike'], ranks: [1, 2] };
const blade = { role: '근접 · 출혈', hp: 30, speed: 6, dodge: 7, skills: ['cut', 'pierce', 'steady', 'expose'], ranks: [1, 2, 3] };
const reach = { role: '중후열 · 정밀', hp: 27, speed: 8, dodge: 5, skills: ['shot', 'mark', 'knife', 'bleed_strike'], ranks: [2, 3, 4] };
const support = { role: '후열 · 지원', hp: 29, speed: 5, dodge: 4, skills: ['mend', 'solace', 'knife', 'stabilize'], ranks: [3, 4] };

// Descriptions follow each displayed weapon/action; ranges and numbers still
// come from combat.js. These lines do not change the combat rules.
const WEAPON_DESCRIPTIONS = {
  yisang: {shot:'칼날을 날려 후열을 견제한다. 표식 대상에게 피해 +40%.',knife:'가까운 적을 단검으로 벤다. 어느 위치에서도 사용할 수 있다.'},
  faust: {knife:'대검으로 전열의 적을 짧게 베어 견제한다. 어느 위치에서도 사용 가능.'},
  don: {cleave:'랜스로 돌진해 전열의 적을 강하게 찌른다.',push:'랜스로 적을 밀어붙여 한 칸 뒤로 보낸다.',reach_strike:'길게 돌진해 2·3열을 관통한다. 1·2·3열에서 사용 가능.'},
  meursault: {cleave:'정면의 적에게 무거운 주먹을 꽂는다.',push:'팔꿈치로 적을 제압하고 한 칸 뒤로 밀어낸다.',reach_strike:'전진하며 주먹을 뻗어 2·3열을 견제한다.'},
  heathcliff: {cleave:'배트를 내려쳐 전열의 적을 강타한다.',push:'배트로 몰아쳐 적을 한 칸 뒤로 밀어낸다.',reach_strike:'배트를 거칠게 휘둘러 2·3열을 견제한다.'},
  ishmael: {cleave:'둔기로 전열의 적을 강타한다.',push:'방패를 앞세워 돌진하고 적을 한 칸 뒤로 밀어낸다.',reach_strike:'방패로 강하게 밀어쳐 2·3열을 견제한다.'},
  rodion: {pierce:'도끼를 길게 휘둘러 2·3·4열을 공격한다.',expose:'도끼로 방어를 쪼갠다. 명중한 대상에게 표식 2회 부여.'},
  honglu: {shot:'월도로 넓게 휩쓸어 후열을 견제한다. 표식 대상에게 피해 +40%.',knife:'월도를 돌려 가까운 적을 벤다. 어느 위치에서도 사용 가능.'},
  outis: {shot:'도검으로 정밀하게 찔러 후열을 견제한다. 표식 대상에게 피해 +40%.'},
  gregor: {knife:'변이한 팔로 가까운 적을 베어낸다. 어느 위치에서도 사용 가능.'},
};

export const SINNERS = [
  { ...reach, key: 'yisang', name: '이상', english: 'YI SANG', number: '01', title: 'LCB 수감자 · 단검', look: 'yisang', weapon: 'dagger', color: '#c7bc9b', skillNames: { shot: '비상하는 칼날', mark: '균열 관찰', knife: '단검 베기', bleed_strike: '잔상 베기' } },
  { ...support, key: 'faust', name: '파우스트', english: 'FAUST', number: '02', title: 'LCB 수감자 · 대검', look: 'faust', weapon: 'greatsword', color: '#b9d8d4', skillNames: { mend: '응급 조율', solace: '상황 분석', knife: '대검 견제', stabilize: '자가 처치' } },
  { ...guard, key: 'don', name: '돈키호테', english: 'DON QUIXOTE', number: '03', title: 'LCB 수감자 · 랜스', look: 'don', weapon: 'lance', color: '#e5bd58', skillNames: { cleave: '정의의 돌격', cover: '동료 수호', push: '랜스 돌파', reach_strike: '정면 관통' } },
  { ...blade, key: 'ryoshu', name: '료슈', english: 'RYŌSHŪ', number: '04', title: 'LCB 수감자 · 도검', look: 'ryoshu', weapon: 'katana', color: '#c95d52', skillNames: { cut: '붉은 궤적', pierce: '틈새 발도', steady: '정적', expose: '칼끝의 흠집' } },
  { ...guard, key: 'meursault', name: '뫼르소', english: 'MEURSAULT', number: '05', title: 'LCB 수감자 · 건틀릿', look: 'meursault', weapon: 'fist', color: '#839dbb', skillNames: { cleave: '정면 강타', cover: '방어 대행', push: '제압 전진', reach_strike: '전진 정타' } },
  { ...reach, key: 'honglu', name: '홍루', english: 'HONG LU', number: '06', title: 'LCB 수감자 · 월도', look: 'honglu', weapon: 'glaive', color: '#71b7ac', skillNames: { shot: '월도 휩쓸기', mark: '옥빛 시선', knife: '근접 베기', bleed_strike: '흐르는 칼끝' } },
  { ...guard, key: 'heathcliff', name: '히스클리프', english: 'HEATHCLIFF', number: '07', title: 'LCB 수감자 · 배트', look: 'heathcliff', weapon: 'bat', color: '#b49ac6', skillNames: { cleave: '분노의 강타', cover: '이를 악물고', push: '몰아치기', reach_strike: '거친 견제' } },
  { ...guard, key: 'ishmael', name: '이스마엘', english: 'ISHMAEL', number: '08', title: 'LCB 수감자 · 방패와 둔기', look: 'ishmael', weapon: 'mace', color: '#cf915b', skillNames: { cleave: '둔기 강타', cover: '방패 엄호', push: '파도 가르기', reach_strike: '견제 강타' } },
  { ...blade, key: 'rodion', name: '로쟈', english: 'RODION', number: '09', title: 'LCB 수감자 · 도끼', look: 'rodion', weapon: 'axe', color: '#c88f86', skillNames: { cut: '도끼 내려찍기', pierce: '길게 휘두르기', steady: '여유 한 조각', expose: '방어 쪼개기' } },
  { ...blade, key: 'sinclair', name: '싱클레어', english: 'SINCLAIR', number: '11', title: 'LCB 수감자 · 할버드', look: 'sinclair', weapon: 'halberd', color: '#bed288', skillNames: { cut: '결의의 일격', pierce: '할버드 찌르기', steady: '숨 고르기', expose: '빈틈 찌르기' } },
  { ...reach, key: 'outis', name: '오티스', english: 'OUTIS', number: '12', title: 'LCB 수감자 · 도검', look: 'outis', weapon: 'sabre', color: '#a6b67c', skillNames: { shot: '전술 찌르기', mark: '표적 지정', knife: '근접 제압', bleed_strike: '측면 절개' } },
  { ...support, key: 'gregor', name: '그레고르', english: 'GREGOR', number: '13', title: 'LCB 수감자 · 변이한 팔', look: 'gregor', weapon: 'insect', color: '#b6ab79', skillNames: { mend: '응급 지원', solace: '잠깐의 대화', knife: '변이한 팔', stabilize: '손상 수습' } },
].map(sinner => ({...sinner, skillDescriptions: WEAPON_DESCRIPTIONS[sinner.key] || {}}));

export const DEFAULT_PARTY = ['don', 'ryoshu', 'yisang', 'faust'];
export const VERSION = '0.6';

export function createParty(keys = DEFAULT_PARTY) {
  if (!Array.isArray(keys) || keys.length !== 4 || new Set(keys).size !== 4) throw new Error('서로 다른 수감자 4명을 선택하세요.');
  return keys.map((key, index) => {
    const sinner = SINNERS.find(s => s.key === key);
    if (!sinner) throw new Error(`알 수 없는 수감자: ${key}`);
    return { ...sinner, id: `h${index + 1}`, skills: [...sinner.skills], skillNames: { ...sinner.skillNames }, skillDescriptions: { ...sinner.skillDescriptions }, ranks: [...sinner.ranks] };
  });
}

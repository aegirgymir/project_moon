"""Check authored skill cues against actual frames/VFX and real status tooltips."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'.artifacts/v0.6';OUT.mkdir(parents=True,exist_ok=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:5173',wait_until='networkidle')
 result=page.evaluate('''async()=>{
  const {SINNERS}=await import('/src/sinners.js');
  const {getSkill}=await import('/src/combat.js');
  const {figure}=await import('/src/art.js');
  const {motionsForShot}=await import('/src/lcb-motions.js');
  const {buildShotTimeline}=await import('/src/skill-presentation.js');
  const {effectMarkup}=await import('/src/skill-effects.js');
  const {playShotPresentation}=await import('/src/shot-player.js');
  const {preloadMotion}=await import('/src/attack-motion.js');
  let checked=0,cues=0;
  for(const sinner of SINNERS)for(const skill of sinner.skills)for(const fast of [false,true]){
   const sk=getSkill(skill,sinner),friendly=Boolean(sk.side),self=sk.side==='self';
   const shot={actor:{...sinner,side:'hero'},target:{id:'qa-target',side:friendly?'hero':'enemy'},skill,serial:1,kind:sk.damage?'damage':'support',friendly,self,reaction:sk.damage?'hurt':'receive'};
   const motions=motionsForShot(shot),plan=buildShotTimeline(shot,motions.actor,{fast});
   await Promise.all([preloadMotion(motions.actor),preloadMotion(motions.target)]);
   const root=document.createElement('div');root.className='cinematic-layer skill-cinematic native-motion';
   root.style.cssText=`position:relative;width:600px;height:320px;--shot-duration:${plan.duration}ms;--result-delay:${plan.resultAt}ms`;
   root.innerHTML=`<div class="duel-camera"><div class="duel-person duel-attacker at-left"><div class="duel-sprite">${figure(sinner.look,'qa')}</div></div><div class="duel-person duel-defender at-right"><div class="duel-sprite"></div><span class="duel-result">7</span></div>${effectMarkup(shot,plan)}</div>`;
   document.body.append(root);
   let handle=0,pending=new Map(),sounds=0,done=0,results=0;
   const clock={requestAnimationFrame:callback=>{pending.set(++handle,callback);return handle;},cancelAnimationFrame:id=>pending.delete(id)};
   const cancel=playShotPresentation(root,shot,motions,plan,{clock,onCue:()=>sounds++,onResult:()=>results++,onComplete:()=>done++});
   const tick=t=>{const [id,fn]=pending.entries().next().value;pending.delete(id);fn(t);};
   tick(0);
   if(root.dataset.resultVisible)throw new Error('Result shown during windup');
   for(const cue of plan.cues){
    tick(cue.time);
    const sprite=root.querySelector('.duel-attacker .original-sprite');
    if(cue.frame!==null && Number(sprite.dataset.motionFrame)!==cue.frame)throw new Error(sinner.key+'/'+skill+' wrong strike frame');
    const effect=[...root.querySelectorAll('[data-fx-cue]')].find(el=>el.dataset.fxCue===String(cue.frame??'utility'));
    if(!effect || Number(getComputedStyle(effect).opacity)<.5)throw new Error(sinner.key+'/'+skill+' effect lags behind strike');
    if(cue.time===plan.resultAt && (results!==1 || Number(getComputedStyle(root.querySelector('.duel-result')).opacity)<.5))throw new Error('Result not synchronized');
    cues++;
   }
   tick(plan.duration);if(done!==1 || sounds!==plan.cues.length || results!==1)throw new Error('Repeated result/completion or missing cue');
   cancel();cancel();if(pending.size)throw new Error('RAF leaked after skip');root.remove();checked++;
  }
  return {skill_speed_cases:checked,cues_checked:cues};
 }''')
 # Real battle UI: apply bleed, inspect remaining turns, and avoid consuming an action by tapping an icon.
 page.keyboard.press('4');page.locator('[data-unit="e3"]').click()
 before_hp=page.locator('.target-stats b').first.inner_text()
 page.locator('[data-action="execute"]').click()
 assert page.locator('.target-stats b').first.inner_text()==before_hp
 page.wait_for_function("document.querySelector('[data-cinematic]')?.dataset.resultVisible==='true'")
 assert page.locator('.target-stats b').first.inner_text()!=before_hp
 page.screenshot(path=str(OUT/'bleed-effect.png'),full_page=True)
 page.wait_for_function("!document.querySelector('[data-cinematic]')")
 chip=page.locator('[data-unit="e3"] [data-status="bleed"]');chip.hover()
 tip=page.locator('#status-tooltip');assert tip.is_visible();assert '남은 3회' in tip.inner_text();assert '자기 차례 시작' in tip.inner_text()
 page.screenshot(path=str(OUT/'bleed-tooltip.png'))
 actions=page.locator('.log-entry.action').count();chip.click();assert page.locator('.log-entry.action').count()==actions
 page.locator('[data-skill="mend"]').click();page.locator('[data-unit="h1"]').click();page.locator('[data-action="execute"]').click()
 page.wait_for_function("document.querySelector('[data-cinematic]')?.dataset.resultVisible==='true'")
 assert page.locator('[data-skill-fx="heal"]').count()==1
 assert page.locator('[data-cinematic]').get_attribute('data-motion')=='none'
 page.screenshot(path=str(OUT/'heal-effect.png'),full_page=True)
 page.wait_for_function("!document.querySelector('[data-cinematic]')")
 page.locator('[data-action="restart"]').click();page.locator('[data-action="confirm-restart"]').click()
 assert tip.is_hidden()
 page.locator('[data-skill="mark"]').click();page.locator('[data-unit="e4"]').click();page.locator('[data-action="execute"]').click()
 page.wait_for_function("document.querySelector('[data-cinematic]')?.dataset.resultVisible==='true'")
 assert page.locator('[data-skill-fx="mark"]').count()==1
 page.screenshot(path=str(OUT/'mark-effect.png'),full_page=True)
 page.wait_for_function("!document.querySelector('[data-cinematic]')");page.locator('[data-unit="e4"] [data-status="mark"]').hover()
 assert '공격 피해 +40%' in tip.inner_text();assert '2회' in tip.inner_text();assert '빗나간 공격' in tip.inner_text()
 page.set_viewport_size({'width':390,'height':844});page.locator('[data-unit="e4"] [data-status="mark"]').click()
 assert tip.is_visible()
 rect=tip.bounding_box();assert rect['x']>=0 and rect['x']+rect['width']<=390
 page.screenshot(path=str(OUT/'mobile-status.png'))
 # Reach Don through public controls, then inspect an actual protective buff.
 page.set_viewport_size({'width':1440,'height':1000})
 page.locator('[data-action="restart"]').click();page.locator('[data-action="confirm-restart"]').click()
 page.locator('[data-action="fast"]').click();page.locator('[data-action="cinematics"]').click()
 for _ in range(100):
  if page.locator('[data-skill="cover"]').count():break
  if page.locator('.skill-list').count():
   page.keyboard.press('w');page.locator('[data-action="execute"]').click()
  else:page.wait_for_timeout(80)
 assert page.locator('[data-skill="cover"]').count()==1
 page.locator('[data-action="cinematics"]').click();page.locator('[data-skill="cover"]').click();page.locator('[data-unit="h2"]').click();page.locator('[data-action="execute"]').click()
 page.wait_for_function("!document.querySelector('[data-cinematic]')")
 page.locator('[data-action="fast"]').click()
 page.locator('[data-unit="h2"] [data-status="guard"]').hover()
 assert tip.is_visible() and '돈키호테' in tip.inner_text() and '다음 차례가 시작' in tip.inner_text()
 page.screenshot(path=str(OUT/'guard-tooltip.png'))
 assert not errors,errors
 print(json.dumps({'status':'passed',**result,'real_bleed_hover':True,'real_mark_hover':True,'mobile_tooltip':True,'real_guard_hover':True,'hp_revealed_at_result':True,'browser_errors':errors}))
 browser.close()

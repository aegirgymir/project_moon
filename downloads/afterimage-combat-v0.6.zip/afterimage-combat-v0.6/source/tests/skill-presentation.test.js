import test from 'node:test';
import assert from 'node:assert/strict';
import {SINNERS} from '../src/sinners.js';
import {getSkill,createBattle,act} from '../src/combat.js';
import {describeAction} from '../src/cinematic.js';
import {motionsForShot} from '../src/lcb-motions.js';
import {buildShotTimeline,timelineFrameAt,SKILL_MOTION_MAP} from '../src/skill-presentation.js';
import {unitStatuses} from '../src/status-ui.js';
import {effectMarkup} from '../src/skill-effects.js';

test('every character skill has fixed appropriate motion and an authored effect',()=>{
 for(const actor of SINNERS)for(const skill of actor.skills){
  const shot={actor,target:{side:'enemy'},skill,serial:1,reaction:'hurt'};
  const first=motionsForShot(shot),later=motionsForShot({...shot,serial:83});
  assert.equal(first.actor,later.actor,'serial must never change the chosen attack');
  const plan=buildShotTimeline(shot,first.actor);
  assert.ok(effectMarkup(shot,plan).includes(`data-skill-fx="${plan.effect}"`));
  if(getSkill(skill,actor).damage){
   assert.ok(SKILL_MOTION_MAP[actor.key][skill]);
   assert.ok(plan.segments.length>1);
   for(const cue of plan.cues)assert.equal(timelineFrameAt(plan,cue.time).f,cue.frame);
   assert.ok(plan.duration-plan.resultAt>=420);
   assert.ok(plan.segments.every(s=>s.end-s.start<=240),'no long coin/script freeze');
  }
 }
 const outis=SINNERS.find(s=>s.key==='outis'),faust=SINNERS.find(s=>s.key==='faust');
 assert.equal(motionsForShot({actor:outis,target:{},skill:'shot',serial:1}).actor.kind,'s3','Outis uses the actual thrust');
 assert.equal(motionsForShot({actor:faust,target:{},skill:'knife',serial:9}).actor.kind,'s1','Faust uses a consistent greatsword cut');
 assert.match(getSkill('knife',faust).desc,/대검/);
 assert.match(getSkill('cleave',SINNERS.find(s=>s.key==='meursault')).desc,/주먹/);
});

test('retimed cues, camera/result times and actual strike frames agree in both speeds',()=>{
 const actor=SINNERS[0],shot={actor,target:{},skill:'shot',serial:1};
 const motion=motionsForShot(shot).actor;
 const a=buildShotTimeline(shot,motion),b=buildShotTimeline(shot,motion,{fast:true});
 assert.equal(timelineFrameAt(a,a.resultAt).f,50,'result belongs to the stab, not the initial slash/rush');
 assert.equal(a.segments[0].frame.f,26,'omit unrelated initial slash');
 assert.equal(b.duration,a.duration/2);assert.equal(b.resultAt,a.resultAt/2);
 for(let i=0;i<a.cues.length;i++){
  assert.equal(b.cues[i].time,a.cues[i].time/2);
  assert.equal(timelineFrameAt(b,b.cues[i].time).f,a.cues[i].frame);
 }
 const reduced=buildShotTimeline({...shot,reduced:true},null);
 assert.equal(reduced.duration,140);assert.deepEqual(reduced.cues,[]);assert.deepEqual(reduced.segments,[]);
 const miss=buildShotTimeline({...shot,kind:'miss'},motion);
 assert.equal(miss.effect,'evade');assert.ok(!effectMarkup({...shot,kind:'miss'},miss).includes('fx-knives'));
});

test('status descriptions reflect separate bleed holds, successful-hit marks and guard expiry',()=>{
 const state=createBattle(),u=state.units.h1;
 u.bleed=[{amount:2,turns:1},{amount:1,turns:3}];u.marked=2;u.stress=120;u.deathsDoor=true;
 const before=structuredClone(state),list=unitStatuses(u,state);
 assert.equal(list.find(s=>s.key==='bleed').label,'출혈 3');
 assert.match(list.find(s=>s.key==='bleed').detail,/2 피해 × 남은 1회/);
 assert.match(list.find(s=>s.key==='bleed').detail,/1 피해 × 남은 3회/);
 assert.match(list.find(s=>s.key==='mark').detail,/빗나간 공격은 횟수를 소모하지/);
 assert.match(list.find(s=>s.key==='pressure').summary,/명중 −10/);
 assert.match(list.find(s=>s.key==='door').detail,/33%/);
 assert.deepEqual(state,before);
 state.active='h1';state.queue=['h4'];assert.ok(act(state,'cover','h2').ok);
 const protectedStatus=unitStatuses(state.units.h2,state).find(s=>s.key==='guard');
 assert.match(protectedStatus.summary,/돈키호테/);assert.match(protectedStatus.detail,/다음 차례가 시작/);
 assert.ok(unitStatuses(state.units.h1,state).some(s=>s.key==='cover'));
 state.units.h1.dead=true;
 assert.ok(!unitStatuses(state.units.h2,state).some(s=>s.key==='guard'));
});

# Project context

- This repository is a Korean browser combat prototype, “골목의 잔향”. It uses the City setting from Project Moon and takes rank-based tactical inspiration from Darkest Dungeon **1**, not 2.
- Before adding lore, read `docs/RESEARCH.md`. It records what was actually read, source confidence, Korean/English wording differences, and blocked sources. Do not turn a community mirror into an official source, count two translations of the same original as independent confirmation, or claim unvisited websites were verified.
- Persist new research findings and corrections in `docs/RESEARCH.md`; conversation memory alone is insufficient.
- `docs/COMBAT.md` documents the prototype’s own rules. Its stress thresholds do not cause canonical Distortion or E.G.O. Since v0.4, the game uses actual LCB default-identity idle sprites from a community archive, at the user’s explicit request. See docs/ASSETS.md and src/assets/lcb/manifest.json; abilities, tactical roles, stats, passage, and enemies remain adaptations. Official character names must not be described as original inventions.
- Keep combat rules in `src/combat.js` independent of the DOM, timers, and browser APIs. Game randomness must use the seeded random function. UI code and enemy scheduling live in `src/main.js`.
- Run `npm test` and `npm run build` for combat changes. `python scripts/browser_smoke.py` runs an optional real Chromium interaction test against the running server; it requires Python Playwright and Chromium.
- Node 24 is available. Use `npm ci --cache /workspace/.npm-cache` in this cloud machine to avoid writing package caches outside writable roots.
- The cloud task is already isolated. Work in the existing `/workspace/project_moon` checkout; do not create another Git worktree unless the user requests one.
- Do not commit generated `node_modules`, `dist`, screenshots, research clones, or unrelated downloaded game assets. The requested LCB idle sprites and attack/pose assets, including their provenance in src/assets/lcb and src/assets/lcb-motion, are intentional source assets. Keep temporary research outside the checkout. Do not overwrite unrelated user work.

- Current version is 0.6.0 (UI/release label v0.6). `npm run package` creates versioned standalone HTML and a source/documentation ZIP under `.artifacts/downloads/v0.6/`; preserve all previous artifacts.
- Cinematics only present an already-resolved action. Never apply damage, spend an extra turn, or draw RNG while playing/skipping a shot. Input and enemy scheduling must wait until the shot ends. Restart must cancel both timers. Respect reduced motion.
- Download links through `sandbox:` do not work in this chat. The user authorized publishing versioned downloads to the existing GitHub repository. Use a separate `downloads/combat-v0.6` branch and verify remote bytes. Keep the development checkout/index and previous release branches unchanged when publishing.

- Every playable Sinner has exactly four unique character skills, separate from the common move/guard/wait actions. Use keys 1–4. The fourth skills have distinct reach, on-hit mark, bleed, or self-treatment roles.
- v0.4 uses unchanged community-extracted WebP idle sprites, uniformly positioned/scaled. Do not reintroduce fan SVG models or claim full original animation/Spine data is included. Keep image hashes and offline embedding verified. Do not reintroduce the removed quote row or quote data fields unless requested.

- v0.5 resolves the attack motion request: 36 real base-identity attacks, 60 poses, 367 source images in src/assets/lcb-motion. See docs/ATTACK-MOTION.md and manifest.json. Native clips use static public web packs, not a live /api server. Runtime game and offline bundle must never depend on that site.
- Frame clocks start after image decode. Skipping/restarting during decode must prevent stale promises restarting a shot. Native source multi-hit frames are cosmetic; never add damage/RNG for them. Preserve all previous release bytes and refs.

- v0.6 uses explicit per-character skill mappings/clip ranges and reviewed source-frame cues in src/skill-presentation.js. Do not restore serial-based attack cycling or infer a hit from the first frame change. Source bytes remain unchanged; display timing is intentionally retimed.
- src/shot-player.js owns ONE RAF for actor, reaction, camera, VFX, result, audio cues and completion. Never add an independent cinematic end timeout or defender frame loop. UI panels show pre-action snapshots until the final result cue; combat.js still resolves once. Status tooltip clicks must not target a unit or spend an action.
- Check npm test/build and scripts/presentation_smoke.py for changes to mappings/timing/effects/statuses. Keep hover, keyboard, mobile tap, viewport clamping, fast mode, reduced motion, cancellation during loading and offline embedding working.
